export const imports = {
  'doc.mdx': () =>
    import(/* webpackPrefetch: true, webpackChunkName: "doc" */ 'doc.mdx'),
  'packages/h5-uploader/doc.mdx': () =>
    import(
      /* webpackPrefetch: true, webpackChunkName: "packages-h5-uploader-doc" */ 'packages/h5-uploader/doc.mdx'
    ),
  'packages/http-proxy/doc.mdx': () =>
    import(
      /* webpackPrefetch: true, webpackChunkName: "packages-http-proxy-doc" */ 'packages/http-proxy/doc.mdx'
    ),
  'packages/img-compress/doc.mdx': () =>
    import(
      /* webpackPrefetch: true, webpackChunkName: "packages-img-compress-doc" */ 'packages/img-compress/doc.mdx'
    ),
  'packages/img-prev/doc.mdx': () =>
    import(
      /* webpackPrefetch: true, webpackChunkName: "packages-img-prev-doc" */ 'packages/img-prev/doc.mdx'
    ),
  'packages/request/doc.mdx': () =>
    import(
      /* webpackPrefetch: true, webpackChunkName: "packages-request-doc" */ 'packages/request/doc.mdx'
    ),
  'packages/taro-uploader/doc.mdx': () =>
    import(
      /* webpackPrefetch: true, webpackChunkName: "packages-taro-uploader-doc" */ 'packages/taro-uploader/doc.mdx'
    ),
  'packages/vue-no-repeat-hoc/doc.mdx': () =>
    import(
      /* webpackPrefetch: true, webpackChunkName: "packages-vue-no-repeat-hoc-doc" */ 'packages/vue-no-repeat-hoc/doc.mdx'
    ),
  'packages/react-no-repeat-hoc/doc.mdx': () =>
    import(
      /* webpackPrefetch: true, webpackChunkName: "packages-react-no-repeat-hoc-doc" */ 'packages/react-no-repeat-hoc/doc.mdx'
    ),
  'packages/wechat-robot-webpack-plugin/doc.mdx': () =>
    import(
      /* webpackPrefetch: true, webpackChunkName: "packages-wechat-robot-webpack-plugin-doc" */ 'packages/wechat-robot-webpack-plugin/doc.mdx'
    ),
  'packages/helper/src/doc.mdx': () =>
    import(
      /* webpackPrefetch: true, webpackChunkName: "packages-helper-src-doc" */ 'packages/helper/src/doc.mdx'
    ),
  'packages/qc-menber/src/doc.mdx': () =>
    import(
      /* webpackPrefetch: true, webpackChunkName: "packages-qc-menber-src-doc" */ 'packages/qc-menber/src/doc.mdx'
    ),
}
