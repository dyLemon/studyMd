const base = require('./build.base');
export default base;
