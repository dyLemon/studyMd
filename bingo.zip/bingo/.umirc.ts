import { defineConfig } from 'dumi';

const title = 'bingo';
const prodEnv = process.env.NODE_ENV === 'production'; 

export default defineConfig({
  title,
  favicon:
    'https://wxapptop.oss-cn-beijing.aliyuncs.com/upload_pic/z19122001/12718_ico.jpg',
  logo:
    'https://wxapptop.oss-cn-beijing.aliyuncs.com/upload_pic/z19122001/12718_ico.jpg',
  outputPath: 'docs-dist',
  mode: 'doc',
  hash: true,
  cssLoader: {
    localsConvention: 'camelCase',
  },
  // Because of using GitHub Pages
  base: prodEnv ? '/frontend-doc/index.html' : '/',
  publicPath: prodEnv ? 'https://h5.biaoguoworks.com/frontend-doc/' : '/',
  // navs: [
  //   null,
  //   {
  //     title: 'GitHub',
  //     path: 'https://github.com/umijs/dumi-template',
  //   },
  // ],
  // more config: https://d.umijs.org/config
  extraBabelPlugins: [
    [
      'import',
      {
        libraryName: 'antd',
        libraryDirectory: 'lib',
        style: 'css'
      },
      'lean',
    ],
  ]
});
