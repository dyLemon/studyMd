const path = require('path');
const cssnano = require('cssnano');
const vue = require('rollup-plugin-vue');

// 是否开启runtimeHelpers, 及使用transform-runtime
const runtimeHelper = () => {
  try {
    const pkgFile = require(path.resolve(__dirname, 'packages', process.env.PACKAGE, 'package.json'));
    if (pkgFile.dependencies['@babel/runtime']) {
      return {
        // vue组件中使用了async/await语法导致错误可以开启此项
        // 是否把 helper 方法提取到 @babel/runtime 里, 只对 esm 有效, cjs 下无效, 需要组件下package.json dependencies中包含@babel/runtime
        runtimeHelpers: true,
        extraBabelPlugins: [
          '@babel/plugin-transform-runtime'
        ],
      }
    }
    return {};
  } catch(e) {
    return {};
  }
}

module.exports = {
  entry: './src/index',
  // 使用rollup打包成ES6标准模块输出
  esm: {
    type: 'rollup',
    importLibToEs: true,
    minify: true,
    file: 'es/index.min',
  },
  // 使用rollup打包成commonjs标准模块输出
  // cjs: {
  //   type: 'rollup',
  //   minify: true,
  //   file: 'cjs/index.min',
  // },
  umd: {
    minFile: true,
    file: 'umd/index',
    globals: {
      react: 'React',
      vue: 'Vue'
    }
  },
  extractCSS: false, // 分离css, not in js
  cssModules: {
    generateScopedName: 'bingo__[name][hash:base64:5]',
    camelCase: true,
  },
  extraPostCSSPlugins: [
    cssnano(), // css压缩
  ],
  extraRollupPlugins: [
    vue(),
  ],
  autoprefixer: {
    overrideBrowserslist: [
      '> 1%',
      'last 2 versions',
      'not ie <= 8',
    ],
  },
  ...runtimeHelper(),
}


// 多文件导出用法
// export default {
//   entry: ['./src/react/index.js', './src/vue/index.vue'],
//   file: '',
//   overridesByEntry: { 
//     './src/react/index.js': {
//       esm: {
//         file: 'es/react/index'
//       }
//     },
//     './src/vue/index.vue': {
//       esm: {
//         file: 'es/vue/index'
//       }
//     },
//   },
//   umd: false,
// }

