# LoadingView

loading 视图，可在需要等待接口返回渲染显示的场景下使用，同时兼具处理请求 error 以及对报错接口进行重试
- 支持自定义 loading 界面
- 支持自定义 error 界面
- 支持自定义 retry 界面
- 无需自行处理 retry 逻辑，存在 retry 界面时组件会自动处理重试逻辑

<br/>  

安装方式
```zsh
yarn add @bingo/ammo
或
npm install @bingo/ammo
```   

<br/>

```jsx
import React, { Fragment, useState } from 'react';
import { LoadingView } from '@bingo/ammo';

let times = 0;
const promise = () => new Promise((resolve, reject) => {
  setTimeout(() => {
    times % 2 ? resolve() : reject();
    times += 1;
  }, 3000);
});

export default function demo() {
  return (
    <Fragment>
      <div>等待 3s</div>
      <div style={{ marginTop: 20, textAlign: 'center', padding: 20, background: 'lightBlue' }}>
        <LoadingView
          promiseFuns={[promise]}
          loadingView={<div>loadding...</div>} // 可以传入 functiond
          errorView={<div>出错啦～</div>} // 可以传入 functiond
          retryView={<div>点我重试</div>} // 可以传入 functiond
        >
          加载好了
        </LoadingView>
      </div>
    </Fragment>
  )
}
```

<br/>

|props|类型|说明|
|---|---|---|
|loadingView|`() => ReactNode｜ReactNode`|自定义loading视图|
|errorView|`() => ReactNode｜ReactNode`|自定义error视图|
|retryView|`() => ReactNode｜ReactNode`|自定义retry视图|
|promiseFuns|`() => promise｜[() => promise]`|需要等待完成的promise方法|
