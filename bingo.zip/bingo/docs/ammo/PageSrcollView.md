# PageSrcollView

分页组件

- 常见分页需求
- 支持大数据量时 时间分片
- 支持虚拟列表

```zsh
yarn add @bingo/ammo
yarn add babel-plugin-import -D
```

```js
// 配置babel-import-plugin插件 babel.config.js
module.exports = {
  ...
  plugins: [
    [
      'import',
      {
        libraryName: '@bingo/ammo',
        libraryDirectory: 'es',
        style: true,
        camel2DashComponentName: false,
      },
    ],
  ],
};
```

```jsx | pure
import { PageSrcollView } from "@bingo/ammo";
```

<div>
  <img src="https://static.biaoguoworks.com/peachcompdocs/PageWithScroll.jpg" />
</div>

### 代码演示:

```jsx | pure
<PageSrcollView
  scrollListStyle={{ paddingBottom: Taro.pxTransform(88) }}
  ref={(ref) => (this.refPageWithScroll = ref)}
  extraAsyncRequestParams={{
    requireDate: dayjs(date).format("YYYY-MM-DD 00:00:00"),
    supplierId: supplierId !== "ALL" ? supplierId : "",
    statusList: this.getStatusList(),
  }}
  asyncRequest={getPassthroughList}
  onGetList={(list, pageParams) => {}}
  renderStickyHeader={
    <View className="search-wrapper" style={{ backgroundColor: "white" }}>
      <View className="search-wrapper-inner">
        <View className="search-date">
          <View>供货日期</View>
          <DatePicker
            style={{ paddingLeft: Taro.pxTransform(20) }}
            date={date}
            onChange={this.onDateChange}
          />
        </View>

        <View>
          <PickerSelector
            style={{ borderBottom: "0" }}
            textStyle={{ textAlign: "right" }}
            placeholder="全部供应商"
            selector={provideList}
            value={supplierId}
            onChange={(value) => this.onProviderChange(value)}
          />
        </View>
      </View>

      <View className="after-sale-logic">
        <View className="after-sale-logic-item">
          <Text className="total">{afterSaleOrderCount}</Text>
          <Text className="title">售后单数</Text>
        </View>
        <View className="after-sale-logic-item">
          <Text className="total">{afterSaleOrderAmountSum}</Text>
          <Text className="title">赔付金额(元)</Text>
        </View>
      </View>
      <View className="tab-wrapper">
        <Tabs
          style={{ position: "static" }}
          defaultActiveKey=""
          tabs={tabs}
          onChange={this.tabChange}
        />
      </View>
    </View>
  }
  renderList={(data, rows, wrapperIndex) => {
    return data.map((i, index) => (
      <View
        key={i.key}
        style={{
          height: "200px",
          ...commonStyle,
          borderBottom: "1px solid #ddd",
        }}
      >
        {`这是第${i.key}条数据`}
        <View
          style={{ padding: "10rpx", backgroundColor: "#999" }}
          onClick={() => this.handleClick(i, wrapperIndex, index)}
        >
          点击{+i.status}
        </View>
      </View>
    ));
  }}
  emptyImage="http://static.biaoguoworks.com/no-order.png"
  emptyText="还没有售后申请订单哦~"
/>
```

### 注意事项:

一、在采用 ref 的方式调用组件内部的方法的场景时：

- handleRequest(params,options) 有两个参数：

  params 额外的请求

  options.isReset 是否重置分页 默认：false

  options.stayStricky 是否停留在吸顶的原位置 否则滚动到顶部 默认：false

- updateItemData(wrapperIndex, index, detail) 有 3 个参数：

  wrapperIndex 对应 renderList 回调函数第三个参数

  index 对应 renderList 回调函数中 map 方法的循环下标

  detail 对应具体需求更新的数据

- UNRECOMMEND_reFreshData 全量更新列表已有数据（不推荐）

- refreshPageData(wrapperIndex, index) 刷新任一页码数据 参数同 updateItemData 方法

- destoryItem(wrapperIndex, index) 删除某一条数据 参数同 updateItemData 方法

二、组件内部会默认根据 extraAsyncRequestParams 参数的变化自动请求接口 如果需禁用 autoReload 传 false

三、不支持在 Taro 自定义组件 CustomWrapper 中使用该组件

四、openVirtualList = true 开启虚拟列表后 列表循环项 组件不能有内部状态，因为组件会随滚动加载和卸载 不能保持状态，请酌情使用。

egg: 一个列表循环项组件有展开收起的功能，默认收起，当展开后如果状态设置在组件内部，那么开启虚拟列表功能后，滑动屏幕，当触发组件再次加载时 组件的展开状态将不被保持。

五、renderList 为 jsx 时（即渲染完全由外部控制），不支持时间分片、虚拟列表功能。

### API

| 参数                    | 说明                                                    | 类型             | 默认值    |
| ----------------------- | ------------------------------------------------------- | ---------------- | --------- |
| renderHeader            | 头部常用在吸顶业务场景中 跟随滚动                       |                  | -         |
| renderStickyHeader      | 头部 跟随滚动，吸顶                                     |                  | -         |
| renderList              | 页面列表组件                                            |                  | -         |
| emptyImage              | 空数据图片                                              | string           | -         |
| emptyText               | 空数据文本内容(如有 renderEmpty 优先取 renderEmpty)     | string           | ''        |
| refresherEnabled        | 开启自定义下拉刷新                                      | boolean          | false     |
| containerStyle          | 组件样式                                                | object           | {}        |
| contentStyle            | 内容区域样式                                            | object           | {}        |
| scrollViewStyle         | 滚动盒子样式                                            | object           | {}        |
| extraBottomDisTance     | 滚动区域取掉的底部高度                                  | number           | 0         |
| size                    | 分页大小                                                | number           | 10        |
| extraAsyncRequestParams | 请求参数(自动响应参数变化，如需关闭 autoReload = false) | object           | {}        |
| autoReload              | 是否开启自动刷新                                        | bool             | true      |
| onGetList               | 分页数据回调方法                                        | function         | -         |
| renderFooter            | 页面底部                                                | jsx              | -         |
| showLoading             | 是否显示 loading                                        | bool             | false     |
| initialLoad             | 是否初始化加载                                          | bool             | true      |
| asyncRequest            | 请求方法                                                | promise function | -         |
| segmentSize             | 时间分片数据量大小                                      | number           | -         |
| children                | 插槽                                                    | jsx              | -         |
| openVirtualList         | 是否开启虚拟列表                                        | bool             | false     |
| scrollViewProps         | 原生 ScrollView props                                   | object           | {}        |
| renderEmpty             | 空数据时显示内容                                        | jsx              | undefined |
| renderLoadingStyle      | 自定义加载中样式                                        | jsx              | undefined |
| openTimeSlice           | 是否开启时间分片                                        | bool             | true      |
