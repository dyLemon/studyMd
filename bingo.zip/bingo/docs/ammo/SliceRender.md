# SliceRender

切片渲染组件，可以对大量数据进行选择性切片，用于解决大量数据一次渲染造成的卡顿与长时间白屏
- 支持配置单次渲染切片数量
- 支持配置切片渲染间隔时长

安装方式
```zsh
yarn add @bingo/ammo
或
npm install @bingo/ammo
```   

使用方式
```jsx
import React, { Fragment } from 'react';
import { SliceRender } from '@bingo/ammo';

export default function Demo() {
  
  return (
    <Fragment>
      <div>每1s会新增10条数据，直到完成100条</div>
      <div style={{ marginTop: 20, height: 300, overflowY: 'scroll' }}>
        <SliceRender
          sliceRange={10}
          interval={1000}
        >
          {Array.from(Array(100), (v, i) => i).map((v) => {
            return <div>我是第{v}条数据</div>
          })}
        </SliceRender>
      </div>
    </Fragment>
  )
}
```
