# 快速开始

ammo(弹药库)
<br/>

适用于基于 Taro3.x + React(> 16.8) 设计的组件库

安装方式

```zsh
yarn add @bingo/ammo
```
或
```zsh
npm install @bingo/ammo
```

配置按需加载
使用 `babel-import-plugin` 进行如下配置

```json
"plugins": [
  [
    "import", {
      "libraryName": "@bingo/ammo",
      "libraryDirectory": "es",
      "style": true
    }
  ],
  ...
]
```


