# bingo-cli

一键生产 web 端、小程序、h5 项目模板

##### 安装

```javascript
yarn global add @bingo/bingo-cli
或
npm install @bingo/bingo-cli -g
```

<br/>

##### 使用方式

```javascript
bingo-cli init
```

<br/>
<br/>
