# h5-uploader

h5项目上传七牛发布

<font color="red">注意：该npm包是为h5项目发布服务，其他项目慎重使用</font>


##### 安装

```javascript
yarn add @bingo/h5-uploader -D
或
npm install @bingo/h5-uploader -D
```
<br/>


##### 使用方式

安装完成后在项目根目录下使用
```javascript
node_modules/.bin/h5Uploader -s ./dist -t xxx/xxx -b h5
或
yarn h5Uploader -s ./dist -t xxx/xxx -b h5
```

<br/>
<br/>

|       参数     |   类型   |       默认        |   必填  |         备注         |
|----------------|----------|------------------|---------|----------------------|
|  -s / --source |  string  |       dist       |    否   |      待上传目录       |
|  -t / --target |  string  |        无        |    是   | 上传目标目录(七牛目录) |
|  -b / --bucket |  string  |        H5        |    否   |       七牛bucket      |       |
