# http-proxy

一款轻型的http代理服务脚本，只需简单配置相应的配置文件就可以启用（与webpack-dev-server配置几乎相同），支持配置文件随时修改，无需手动重启服务。

### 安装

建议全局安装，<a href="#用法">配置文件</a>丢自己喜欢的地方就行了

```
yarn global add @bingo/http-proxy
或
npm install @bingo/http-proxy -g
```

----

### mock支持

**relese 0.0.4新增**
  - 支持数据mock
  - 支持js配置文件，方便书写
  - 优化控制台打印

数据mock (基于mockjs)
  - mock时无需target
  - mock时无需changeOrigin 
  - mock时无需secure
  - 需要mock字段

普通构造方式:
```json
{
  "mock": {
    "id": 1213,
    "name": "张山"
  }
}

// 生成
{
  "id": 1213,
  "name": "张山"
}
```

随机范围:
```json
{
  "mock": {
    "id": {
      "$type": "number",
      "$range": [1, 20],
      "$value": 1
    },
    "name": {
      "$type": "string",
      "$range": [1, 3],
      "$value": "张山"
    },
    "price": {
      "$type": "number",
      "$range": [1, 20],
      "$dRange": [1, 4],
      "$value": 1.1
    }
  }
}

// 生成
{
  "id": "1 ~ 20 随机",
  "name": "张山 (重复 1～3 次)",
  "price": "1 ~ 20 随机整数 + 1 ~ 4 位随机小数"
}
```

mockjs占位快速生成 (具体类型可参考)

| Type | Method |
| -- | -- |
| __Basic__ | boolean, natural, integer, float, character, string, range, date, time, datetime, now |
| __Image__ | image, dataImage |
| __Color__ | color |
| __Text__ | paragraph, sentence, word, title, cparagraph, csentence, cword, ctitle |
| __Name__ | first, last, name, cfirst, clast, cname |
| __Web__ | url, domain, email, ip, tld |
| __Address__ | area, region |
| __Miscellaneous__ | guid, id |

<br/>

```json
{
  "mock": {
    "id": "@id",
    "address": "@regin",
    "name": {
      "$type": "@name",
      "$range": [2, 20], // 同样可设置范围
      "$value": "1"
    }
  }
}
```

构建复杂mock数据

```json
{
  "mock": {
    "errorCode": "",
    "content": {
      "reocrds": {            
        "$type": [],
        "$range": [10, 20],
        "$value": [{
          "aidd": {
            "$type": "@integer",
            "$range": [1, 20]
          },
          "address": "@region",
          "cityId": "@id",
          "cityName": "@area",
          "companyId": "@id",
          "consigneeRealname": {
            "$type": "@word",
            "$range": [3, 20]
          },
          "consigneeTelphone": "@integer",
          "countyName": "@region",
          "createTime": "@datetime",
          "customerId": "@id",
          "customerMobile": "@integer",
          "customerName": "@ctitle",
          "customerStoreId": "@id",
          "customerStoreLinkMan": "@ctitle",
          "customerStoreLinkPhone": "@integer",
          "orderItems": {
            "$type": [],
            "$range": [10, 20],
            "$value": [{
              "activityPrice": "@float",
              "afterSaleOrderId": "@id",
              "afterSaleOrderStatus": {
                "$type": "@enum",
                "$value": ["BUSINESS", "CATTY"]
              },
              "attachUrl": "@image",
              "attachUrlWithoutHost": "@image",
              "companyId": "@id",
              "customerRemarks": "@cword",
              "discountRate": "@float",
              "estimateAmount": "@float",
              "estimateDeliverDate": "@datetime",
              "estimateWeight": "@integer",
              "feeMoney": "",
              "fileHost": "@url",
              "goodsCount": {
                "$type": "@int",
                "$range": [1, 30]
              },
              "goodsId": "@id",
              "goodsName": "@ctitle"
            }]
          }
        }]
      },
      "total": {
        "$type": "@integer",
        "$range": [1, 10]
      }
    }
  }
}
```

------

### 用法
任意目录下新建 `json / js` 文件，如下：

```json
{
  "port": 3031, // 
  "proxy": [
    {
      "context": ["/comm", "/web", "/data", "/h5"],   // 代理请求pathname
      "target": "https://dev.biaoguoworks.com",       // 代理目标地址
      "changeOrigin": true,                           // 请求头（request header）的中的host变成target MDN: (请求头指定服务器的域名(用于虚拟主机))
      "secure": false                                 // 是否启用ssl
    },
    {
      "context": "/web/ep",
      "target": "https://dev.biaoguoworks.com",
      "changeOrigin": true,   
      "pathRewrite": {
        "/app": "/mook/123/app"                       // 地址改写，支持正则
      }
    },
    {
      "context": "/web/ep/store/list",
      "mock": {}                                      // 0.0.4新增
    }
  ]
}
```

控制台运行

```javascript
// -c参数用于指定配置文件地址，相对当前执行命令的目录
http-proxy -c 'xxx'
```

[更多mock占位符](http://mockjs.com/examples.html#Random\.province\(\))
