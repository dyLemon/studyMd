# miniprogram-ci

<p style="color: red">该工具仅仅用于jenkins上对小程序自动上传使用</p>

### 安装
```javascript
npm install @bingo/miniprogram-ci -D;
或
yarn add @bingo/miniprogram-ci -D;
```

### 使用
```javascript
node_modules/.bin/@bingo/miniprogramCI -t xxx -s xxx -k xxx -n xxx -d xxx --robotUrl xxx
或
yarn @bingo/miniprogramCI -t xxx -s xxx -k xxx -n xxx -d xxx --robotUrl xxx
```

### 参数
|参数名|描述|类型|默认值|
|---|---|---|---|
|-t|发布模式，preview(预览)，experience(体验)，release(发布)|string|`null`|
|-s|小程序项目路径|string|`null`|
|-k|小程序上传私钥文件路径|string|`null`|
|-n|版本号|string|`null`|
|-d|发布描述|string|`null`|
|--robotUrl|获取发布机器人接口地址（运维提供）|string|`null`|
