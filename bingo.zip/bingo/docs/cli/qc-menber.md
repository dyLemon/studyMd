# qc-member

质检员

### 关于 qc-menber
原意为 qc-member，创建时拼写错了

这个cli是干什么的，质检员cli适用于统一全成员代码风格的一套规则配置

包含：
- qc-member init 根据引导生成的eslint规则
- qc-member fix 集成lint-staged，即使在老旧项目依然可以放心使用（只验证修改文件，对未修改文件不做验证）
- qc-member commit-check 统一的commit msg规范（validate-commit-msg）
- qc-menber husky-init 初始化及默认commit检查配置 (1.0.0新增)


### 安装
```javascript
yarn add @bingo/qc-menber -D
或
npm install @bingo/qc-menber -D
```   

<br />

------ 

### 1.x版本新增

不再使用魔改项目 package.json

相比旧版本，简洁了配置，共3个选项
 - react / vue (会安装团队规范 eslint-config-bingo-react / eslint-config-bingo-vue)
 - 是否启用 prettier (会安装团队规范 eslint-config-bingo-prettier，回依据上面选择框架类型自动区分)
 - 是否启用 husky 检查

husky配置可以单独启用，不必担心需要在次初始化
```javascript
yarn qc-menber husky-init
```

工具与规范脱离，更加轻量化，团队规范升级无需重新安装/初始化 qc-menber，更新项目下对应的 eslint-config 即可

<br/> 

------

 
### 使用方式
```javascript
node_modules/.bin/qc-menber init
或
yarn qc-menber init
```


### 0.x版本


首次使用请执行 `qc-member init` 生成eslint配置

qc-menber可以生成针对纯js，react，vue(未自测，问题应该不大)项目的规则

![img](http://h5.biaoguoworks.com/frontend-doc/imgs/qc-menber01.png)

![img](http://h5.biaoguoworks.com/frontend-doc/imgs/qc-menber02.png)

![img](http://h5.biaoguoworks.com/frontend-doc/imgs/qc-menber03.png)

![img](http://h5.biaoguoworks.com/frontend-doc/imgs/qc-menber04.png)

选择完成后cli会将对应的依赖包写入package.json中的devDependencies（按需手动npm i / yarn安装）

之后会在项目中生成.eslintrc.js

<br/>

**关于prettire：**

如果启用prettier，会安装prettier，eslint-config-prettier，eslint-plugin-prettier并且在项目根目录下创建.prettier.js文件

> 为什么eslint.js中的prettier与.prettier.js中的配置一样，prettier.js不会多余么

> 如果你的vscode中安装了prettier插件，插件会默认读取.prettier.js配置，没有此文件插件会用默认配置，可能存在配置项冲突


**开启自动修复：**

在vscode配置中开启
```json
"editor.codeActionsOnSave": {
  "source.fixAll.eslint": true
},
```

当保存时eslint就会结合prettier(需要开启prettier)自动规整代码


**结合husky在commit前验证代码规范及commit msg规范**

安装 husky
```
yarn add husky
或
npm install husky
```   

在package.json中写入如下配置
```json
"husky": {
  "hooks": {
    "commit-msg": "@bingo/eslint-config-qc-menber commit-check",  // 对本次commit检查
    "pre-commit": "@bingo/eslint-config-qc-menber fix"  // 提交前会运行eslint --fix修复需要提交文件的代码
  }
},
```