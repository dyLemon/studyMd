# taro2-to-taro3

taro2.x 一键升级至 taro3.x


### 使用方式
```javascript
yarn global add @bingo/taro2-to-taro3
或
npm install @bingo/taro2-to-taro3 -g

// 至项目根目录
taro2-to-taro3
```

---

注意点：

1. 只支持 taro2.x 升级，如果是 taro1.x 请先升级至 taro2.x;
2. 项目的依赖项仍然需要手动安装：

```javascript
# 更新 CLI
$ npm i -g @tarojs/cli@next
# 自动更新package.json 升级完成后 删除node_modules 重新安装
```
