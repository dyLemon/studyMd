# eslint-config-bingo-prettier


##### 标果团队统一代码风格 eslint-config

含两种规范
 - 对应react的prettier
 - 对应vue的prettier

带有安装钩子，在安装完成后会寻找二级目录（../../）写入 `.prettier.js` 文件，避免与编辑器插件的冲突

##### 安装

```javascript
npm install eslint-config-bingo-prettier -D
或
yarn add eslint-config-bingo-prettier -D
```

##### 使用

```javascript
// .eslintrc文件中添加
extends: [
  'bingo-prettier/dist/react' 或 'bingo-prettier/dist/vue'
]
```
