---
name: eslint-config-bingo-react
menu: eslint-config
route: /eslint-config/eslint-config-bingo-react
---

# eslint-config-bingo-react

##### 标果团队 react eslint 规范

##### 安装

```javascript
npm install eslint-config-bingo-react -D
或
yarn add eslint-config-bingo-react -D
```

##### 使用

```javascript
// .eslintrc文件中添加
extends: [
  'bingo-react'
]
```
