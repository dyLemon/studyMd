---
name: eslint-config-bingo-vue
menu: eslint-config
route: /eslint-config/eslint-config-bingo-vue
---

# eslint-config-bingo-vue

##### 标果团队 vue eslint 规范（适用于vue2.x）

##### 安装

```javascript
npm install eslint-config-bingo-vue -D
或
yarn add eslint-config-bingo-vue -D
```

##### 使用

```javascript
// .eslintrc文件中添加
extends: [
  'bingo-vue'
]
```
