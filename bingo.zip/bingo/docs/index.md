# 快速开始


## 关于组件库
该文档为 `标果工厂组件库` 文档中心，文档里归纳了已有组件的用法文档，组件参数等

组件请放在 `packages` 目录中，文档请放入 `docs` 目录中

组件库采用 `father-build` 进行构建，详见 [father.js官方文档](https://github.com/umijs/father)（docz文档模式已被放弃）

本文档采用 `dumi`，查阅 [dumi官方文档](https://d.umijs.org/zh-CN/guide)，解锁更多高级姿势


## 操作指南

**如何使用组件库**

组件库的组件会发布到 https://npm.biaoguoworks.com/ 仓库中

项目拉下来后运行 `lerna bootstrap` 安装所有依赖，包含packages下的所有组件依赖

通过`yarn doc:dev`可以启动文档，本地访问 http://127.0.0.1:8000/ 可以看到组件使用文档

<br />
<br />

**如何进行组件开发**

运行 `yarn new | npm run new [name]` 会初始化一个新的文件夹在./packages目录中   
根据提示走完后找到目录下的package.json
```json
"publishConfig": {
  "registry": "https://npm.biaoguoworks.com/"
}
```
修改 `registry` 为自己的仓库地址     

如果开发的组件有依赖其他框架，如 `react, antd` 等，又不希望在组件在打包时带上这些，请修改组件目录下package.json中的peerDependencies
```json
"peerDependencies": {
  "react": ">=16.3"
}
```

组件打包默认会以umd，和esm(es module)两种方式进行，会在组件当前目录下生成如下目录
```
component
  - dist
    - umd
    - es
```
为了在项目中能够更好的发挥tree-shaking功能，在组件目录package.json中请加上
```json
"module": "dist/es/index.min.js"
```

<br />
<br />

**如何调试我的组件**

详见 [dumi文档](https://d.umijs.org/zh-CN/guide/basic#%E5%86%99%E7%BB%84%E4%BB%B6-demo)

如果需要组件demo过于复杂，或是开发非react组件，如vue，请使用外部链接demo，如 [codesandbox](https://codesandbox.io/)（推荐） 或 [codeopen](https://codepen.io/) 

node cli 请使用 `yarn link | npm link` 来进行调试，参考[随便找的介绍](https://juejin.im/entry/5b33305be51d4558d43fddfd)



<br />
<br />

**如何打包我的组件**

不建议一次打包所有的组件，使用命令`yarn build [name]`可以打包组件，name为自己组件文件夹名子   

如果要打包多个组件，使用`yarn build [name,name,name...]`逗号之间不要留空，否则无法识别

<br />
<br />

**如何发布我的组件**

1. 如果没有注册，请使用 `npm adduser –registry https://npm.biaoguoworks.com/` 注册成为私库用户
2. 确定组件package.json中的发布地址为目标仓库 https://npm.biaoguoworks.com/
3. 运行 `yarn publish [name,name,name]` 参数与打包参数相同 

