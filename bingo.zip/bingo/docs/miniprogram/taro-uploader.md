# taro-uploader

微信小程序taro框架 上传图片 库


### 安装
```javascript
yarn add @bingo/taroUploader 或者 npm install @bingo/taroUploader --save
```


### 使用方法
```javascript
import { createUploader } from '@bingo/taroUploader';
const onProgress = (info) => {
    const { index, total, progress, totalBytesSent, totalBytesExpectedToSend } = info;
    // Taro.showLoading({ title: `已上传${parseInt((progress / totalProgress) * 100)}%` });
    // index 当前上传文件的索引 0 起始
    // progress 当前文件上传进度 0 - 100
    // total 总文件数
    // totalBytesSent 已上传的数据长度
    // totalBytesExpectedToSend 预期需要上传的数据长度
}

const onChoose = (choosed) => {
    const { type, res } = choosed;
}

const onUploadSequence = (currentFile, index, uploadStatus, uploadFiles) => {
    console.log(currentFile) // currentFile 当前已上传的文件 { path, urlFilePath, url, ...others };
    console.log(index) // index 当前文件在数组中的索引 index === uploadFiles.length - 1
    console.log(uploadStatus) // uploadStatus 'done'所有文件已上传完毕 'next'还有未上传完成的图片
    console.log(uploadFiles) // uploadFiles 已上传完成的数组 [{ path, urlFilePath, url, ...others }]
}

const getToken = async () => ({token: 123, host: 'http://localhost:123'});
// 可全局创建一个实例
const uploader = createUploader({ Taro, token: getToken, onChoose, onProgress, onUploadSequence, });

/**
     uploadType // 必须 image | video | messageFile
    ...rest // 选择图片、视频、会话文件相关参数 @see https://developers.weixin.qq.com/miniprogram/dev/api/media/image/wx.chooseImage.html
*/
try {
    const params = {}
    const response  = await uploader.upload({ uploadType, params })
    console.log(response) // [{ url, urlFilePath, path, ...rest }] 
} catch(error) {
    // 取消图片、视频、会话选择时会走catch块
    console.log(error)
}

// 手动上传
try {
    const params = {} // @see https://developers.weixin.qq.com/miniprogram/dev/api/media/image/wx.chooseImage.html
    const handleResponse = (p) => {};

    const response = await upload.getFiles({ type: 'image', ...params });
    const tempFilePaths = handleResponse(response);
    const res = await upload.startUpload(tempFilePaths);
} catch (error) {
    console.log(error)
}
```