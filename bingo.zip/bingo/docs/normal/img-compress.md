# img-compress
图片压缩库(基于canvas)

<br/>  

使用方式
```javascript
yarn add @bingo/img-compress
或
npm install @bingo/img-compress
```   

<br/>


## Demo
```jsx
import React, { useState } from 'react';
import { imgCompress } from '@bingo/img-compress';

export default function ImgCompressDemo() {
  const [imgs, setImgs] = useState([]);
  const [originImgs, setOriginImgs] = useState([]);

  const compress = (e) => {
    const files = [...e.target.files];
    if (files.length) {
      setOriginImgs(files);
      imgCompress()(files)
        .then(res => {
          setImgs(res);
        });
    }
  };

  return (
    <>
      <input
        multiple
        type="file"
        onChange={compress}
      />
      {
        imgs.map((img, index) => {
          const originSize = originImgs[index] ? originImgs[index].size : 0;
          const compressSize = img.size;
          return (
            <div>
              <img src={window.URL.createObjectURL(img)} />
              <p>原图：{(originSize / 1024).toFixed(2)}kb</p>
              <p>压缩后：{(compressSize / 1024).toFixed(2)}kb</p>
              <p>压缩比：{((originSize - compressSize) / originSize).toFixed(2)}</p>
            </div>
          )
        })
      }
    </>
  )
}
```

<!-- <Playground>
  <ImgCompressDemo />
</Playground>   -->

## API
**imgCompress**

参数为 object 类型  
<font color="red">返回真正压缩方法compress</font>  
<br />
<br />

|    参数    |  类型   |       默认       |                 备注                 |
|------------|--------|------------------|--------------------------------------|
|  maxWidth  | number |        1080      |      图片最大宽度，超过缩小到该值      |
|  maxHeight | number |        1080      |      图片最大高度，超过缩小到该值      |
|   quality  | number |         .7       |          压缩质量，范围0 - 1          |
|   maxSize  | number | 10 x 1024 x 1024 |   图片最大小，超过返回maxSizeErr错误   |
|   iosRotateFix  |  boolean  |   false  |     是否修复ios旋转问题，默认不修复    |
| returnType | string |        blob      | 返回图片类型，blob，base64两种类型可选 |

**compress**

|    参数    |      类型     |       默认       |                 备注                 |
|------------|---------------|-----------------|--------------------------------------|
|    blobs   | blob / blob[] |        无       |               图片blob                |



**错误类型**

|     类型    |       说明      |
|-------------|-----------------|
|  maxSizeErr | 图片超过最大大小 |
|    typeErr  |   图片类型无效   |
|   emptyErr  |  compress无参数  |
