# request

通用请求处理库

<font color="red">注意：该请求库不会真正发起请求，而是对真正发起请求的方法的包装</font>

### 安装方式
```javascript
yarn add @bingo/request
或
npm install @bingo/request
```

<br/>

### 使用方式

reqeust库是对请求库的再封装，它不会主动发起http请求，需要其它能够发起http请求的方法支持

再new Request时第一个参数 (requestCore) 即为发起http的方法  

request库提供中间件设置，辅助处理各阶段的数据

```javascript
import { Request } from '@bingo/request'
import requestCore from 'xxx';  // 真正发起请求的方法
const http = new Request(requestCore);

export default http;
```


**统一的request header设置**
```javascript
...
http.setRequestHeaders({
  'content-type': 'application/json',
  ...
});
```

**中间件使用**
  - request中间件
  - response中间件
  - catch中间件

Request在调用中间件方法时会传递2个参数
 - 第一个为当前参数，发起请求阶段为request body，接受请求返回为response body，请求报错时为err
 - 第二个参数为next，意为调用下一个中间件，直到中间件全部完成，next需要接受一个参数（request body / response body / err），后面中间件的第一个参数来自于该参数，
 <font color="red">最后一个中间件返回的值会用于发起请求使用 / 接受数据用 / 处理错误用，请保持参数的数据格式，不要修改参数类型</font>


```javascript
...
const addToken = (req, next) => {
  const newReq = doSomething(req);
  next(newReq);
}
const filterData = (res, next) => {
  const newRes = res.body;
  next(newRes);
}
const catchErr = (e, next) => {
  console.log('日哦，接口又挂了');
  next(e);
}

// 添加公共request中间件
http.useRequestMiddleware([addToken]);

// 添加公共response中间件
http.useResponseMiddleware([filterData]);

// 添加公共错误捕获中间件
http.useCatchMiddleware([catchErr]);
```

**发起请求 (通过requestCore)**
```javascript
...
http.get('xxxx', { status: 1, ... }).then(res => ...);
http.post('xxxx', { status: 1, ... }).then(res => ...);
http.put('xxxx', { status: 1, ... }).then(res => ...);
http.delete('xxxx', { status: 1, ... }).then(res => ...);

// request一次性中间件 (在所有requestMiddleware执行完后执行，同requestMiddleware一样，最终返回值将作为请求的request body)
http.get('xxxx', { status: 1, ... }, (req) => {
  return doSomething(req);
});

// 本次请求禁止使用中间件
http.get('xxxx', {}, () => {...}, {
  noUseRequestMiddleware: true, // 禁止使用request中间件
  noUseResponseMiddleware: true, // 禁止使用response中间件
  noUseCatchMiddleware: true, // 禁止使用catch中间件
  /* 快速修改contentType，目前只支持三种
    'json' -> 'application/json;charset=utf-8'
    'form' -> 'application/x-www-form-urlencoded;charset=UTF-8'
    'formData' -> 'formData'
  */
  contentType: 'form',
})
// 或
http.get('xxxx', {}, {
  noUseRequestMiddleware: true, // 禁止使用request中间件
  noUseResponseMiddleware: true, // 禁止使用response中间件
  noUseCatchMiddleware: true, // 禁止使用catch中间件
  contentType: 'form', // 快速修改contentType
})
```

### Q&A

Q: 为什么设计成不主动发起请求呢

A: 由于很多业务再不同的平台，如小程序有自己的请求方法，web有fetch，axios等，
resquest库的设计初衷是为了各平台都能统一对请求的处理，无论在哪个平台上开发以及使用了什么请求库
