# img-prev

图片捕获预览组件

<br/>  

使用方式
```javascrip
yarn add @bingo/img-prev
或
npm install @bingo/img-prev
```   

<br/>


### Demo
```jsx
import React from 'react';
import ImgsPreview from '@bingo/img-prev'; 

export default () => {
  return (
    <ImgsPreview
      ignoreAttrName="data-ignore"
      style={{
        display: 'flex',
        alignItems: 'flex-start',
      }}
    >
      <div style={{display: 'inline-block'}}>
        <img
          width="300"
          height="200"
          src="http://t9.baidu.com/it/u=583874135,70653437&fm=79&app=86&f=JPEG?w=3607&h=2408"
          data-ignore="1"
        />
        <p>我是带有ignoreAttrName标识，无法预览</p>
      </div>
      <div style={{display: 'inline-block'}}>
        <img
          width="300"
          height="200"
          src="http://attach.bbs.miui.com/forum/201304/25/195151szk8umd8or8fmfa5.jpg"
        />
      </div>
      <div style={{display: 'inline-block'}}>
        <img
          width="300"
          height="200"
          src="https://t7.baidu.com/it/u=2621658848,3952322712&fm=193&f=GIF"
        />
      </div>
    </ImgsPreview>
  )
}
```


### Props

|props name|描述|类型|默认值|
|---|---|---|---|
|gnoreAttrName|设置img标签attrName禁止组件捕获|string|''|
|children|子组件|React Element|null|
|className|拓展样式名称|string|''|
|style|拓展样式|object|{}|
|maskClassName|拓展遮罩样式名称|string|''|
|maskStyle|拓展遮罩样式|object|{}|
|allowMaskClose|允许点击遮罩关闭|boolean|true|
|showControllBar|显示controller栏目|boolean|true|
