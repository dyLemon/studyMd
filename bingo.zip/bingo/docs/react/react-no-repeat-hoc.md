# react-no-repeat-hoc

防重提交 HOC

### 使用方式
```javascript
yarn add @bingo/react-no-repeat-hoc
或
npm install @bingo/react-no-repeat-hoc
```

### Demo
```jsx
import React, {useState} from 'react';
import NoRepeatHOC from '@bingo/react-no-repeat-hoc';
import { Button } from 'antd';

const Hoc = NoRepeatHOC({}); // 可传参数
const style = { color: '#fff', background: '#4569d4', border: 'none', padding: '10px 15px', borderRadius: 4 };

export default function(props) {
  const [count, setCount] = useState(0);
  const waitFun = () => {
    return new Promise((resolve, reject) => {
      setCount(count + 1);
      setTimeout(() => {
        resolve();
      }, 2000);
    })
  }

  return (
    <>
      <div>
        <Hoc>
          <Button
            onClick={waitFun}
            style={style}
          >
            按一下 {count}
          </Button>
        </Hoc>
      </div>
    </>
  )
}
```


### 用法(基于hoc)
react提供的用法为hoc，直接调用 `NoRepeatHOC` 方法，再返回function中传入组件即可

注意：

hoc用法会对原有组件进行修改

1. 组件父会增加 `position: relative` 样式
2. 组件父节点onClick会被劫持，非父节点的onClick无法做到防重复，需要放重复的事件一定要写在父节点上(目前仅支持onClick)
3. 组件父节点onClick需要返回一个promise function否则无法看到loading效果
4. 组件中会增加一个loading用的children


### 参数
|参数名|描述|类型|默认值|
|---|---|---|---|
|loadingSize|loading尺寸|int|`20`|
|loadingColor|loading颜色|string|`#fff`|
