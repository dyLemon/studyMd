const path = require('path');

module.exports = {
  setupFiles: ['./tests/setup.js'],
  testEnvironment: 'jest-environment-jsdom',
  moduleFileExtensions: ['js', 'jsx', 'ts', 'tsx'],
  moduleNameMapper: {
    '^.+\\.(css|less|sass)$': '<rootDir>/tests/styleSupport.js',
  },
  collectCoverage: true,
  // collectCoverageFrom: [                                                                                                                                                                                                                                                                                                                                          
  //   './packages/**/*.js',
  //   '!/node_modules/**'
  // ],
  coverageReporters: ['text'],
  testPathIgnorePatterns: ['/node_modules/'],
  transform: {
    '^.+\\.(js|jsx)': ['babel-jest', { configFile: path.resolve(__dirname, 'tests/babel.config.js') }] ,
  },
};
