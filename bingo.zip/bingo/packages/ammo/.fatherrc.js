module.exports = {
  entry: './src/index.ts',
  cjs: {
    type: 'babel',
    minify: true,
  },
  esm: {
    type: 'babel',
    minify: true,
  },
  umd: false,
  runtimeHelpers: true,
}
