# `ammo`

> TODO: description

## Usage

```
const ammo = require('ammo');

// TODO: DEMONSTRATE API
```
