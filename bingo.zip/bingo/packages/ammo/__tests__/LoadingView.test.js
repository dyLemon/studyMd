'use strict';
import { mount } from 'enzyme';
import { act } from 'react-dom/test-utils';
import LoadingView from '../src/LoadingView';

let promiseTimes = 0;

describe('component should right render', () => {
  const loadingTxt = 'I am loading';
  const errorTxt = 'I am error';
  const retryView = <div id="retry">I am retry</div>;
  let promiseSuccess = null;
  let promiseError = null;
  let promiseRetry = null;

  beforeEach(() => {
    promiseSuccess = () => new Promise((resolve) => {
      setTimeout(resolve, 500);
    });
    promiseError = () => new Promise((resolve, reject) => {
      setTimeout(reject, 500);
    });
    promiseRetry = () => new Promise((resolve, reject) => {
      setTimeout(() => {
        promiseTimes % 2 ? resolve() : reject();
        promiseTimes += 1;
      }, 500);
    });
  })

  it ('should render none when no promise', () => {
    const res = mount(<LoadingView></LoadingView>);
    expect(res.text()).toBe('');
  })

  it ('should show loading view when promise pendding', async () => {
    const res = mount(<LoadingView promiseFuns={promiseSuccess} loadingView={loadingTxt} />);
    expect(res.text()).toBe(loadingTxt);
    await act(() => {
      return new Promise((resolve) => {
        setTimeout(() => {
          res.update();
          resolve();
        }, 700);
      })
    });
    expect(res.text()).toBe('');
  })

  it ('should show error view when promise reject', async () => {
    const res = mount(<LoadingView promiseFuns={promiseError} errorView={errorTxt} />);
    await act(() => {
      return new Promise((resolve) => {
        setTimeout(() => {
          res.update();
          resolve();
        }, 700);
      })
    });
    expect(res.text()).toBe(errorTxt);
  })

  it ('should retry view render and retrying when promise error', async () => {
    const res = mount(<LoadingView promiseFuns={[promiseSuccess, promiseRetry]} errorView={errorTxt} retryView={retryView} />);
    await act(() => {
      return new Promise((resolve) => {
        setTimeout(() => {
          res.update();
          resolve();
        }, 700);
      })
    });
    expect(res.text().includes(errorTxt)).toBeTruthy();
    const retry = res.find('#retry');
    expect(retry).toHaveLength(1);
    retry.invoke('onClick')();
    await act(() => {
      return new Promise((resolve) => {
        setTimeout(() => {
          res.update();
          resolve();
        }, 700);
      })
    });
    expect(res.text()).toBe('');
  })
});
