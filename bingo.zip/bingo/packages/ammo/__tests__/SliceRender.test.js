'use strict';
import { mount } from 'enzyme';
import { act } from 'react-dom/test-utils';
import SliceRender from '../src/SliceRender';


describe('component should right render', () => {

	it ('should render single children when component render', () => {
		const withChildrenComp = mount(
			<SliceRender>
				<div id="ch">
					123
				</div>
			</SliceRender>
		);
		expect(withChildrenComp.find('#ch')).toHaveLength(1);
		expect(withChildrenComp.find('#ch').text()).toEqual('123');
	})

	it ('should render multiple children when component render', () => {
		const withChildrenComp = mount(
			<SliceRender>
				<div className="ch">123</div>
				<div className="ch">234</div>
				<div className="ch">345</div>
			</SliceRender>
		);
		expect(withChildrenComp.find('.ch')).toHaveLength(3);
	})

	it ('should slice render when children more than sliceRange', async () => {
		const children = Array(20).fill().map((ept, index) => <div key={index}>{index}</div>);
		const withChildrenComp = mount(
			<SliceRender sliceRange={5} interval={100}>
				{children}
			</SliceRender>
		);
		expect(withChildrenComp.find('div')).toHaveLength(5);
		await act(async () => {
			await new Promise(resolve => setTimeout(resolve, children.length / 5 * 100));
			withChildrenComp.update();
		});
		expect(withChildrenComp.find('div')).toHaveLength(children.length);
	})
});
