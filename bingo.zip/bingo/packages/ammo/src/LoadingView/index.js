import React, { Fragment, useState, useMemo, useCallback, useEffect } from 'react';

const isFunc = (func) => typeof func === 'function';
const renderProps = (propsVal) => isFunc(propsVal) ? propsVal() : propsVal;

const PENDDING = 0;
const FAIL = 1;
const SUCCESS = 2;

export default function LoadingView(props) {
  const { loadingView, errorView, retryView, promiseFuns, children } = props;
  const [promisesState, setPromisesState] = useState(Array(isFunc(promiseFuns) ? 1 : promiseFuns.length).fill(PENDDING));
  // 重试点击
  const handleClickRetry = useCallback((sourceOnClick, e) => {
    const copyState = promisesState.map(state => state === FAIL ? PENDDING : state);
    setPromisesState(copyState);
    sourceOnClick?.(e);
  }, [promisesState]);
  const retryRender = useMemo(() => {
    if (retryView) {
      const retryRenderRes = renderProps(retryView);
      return React.cloneElement(retryRenderRes, {
        onClick: handleClickRetry.bind(null, retryRenderRes.props.onClick)
      });
    }
    return null;
  }, [retryView]);

  // 执行未完成的 promise
  useEffect(() => {
    const copyState = [...promisesState];
    let promises = [];
    if (isFunc(promiseFuns)) {
      promises.push(promiseFuns);
    } else {
      promises = [...promiseFuns];
    }
    promises.forEach((promise, index) => {
      if (copyState[index] === 0) {
        promise().then(() => {
          copyState[index] = SUCCESS;
        }, () => {
          copyState[index] = FAIL;
        }).then(() => {
          copyState.every(state => state !== PENDDING) && setPromisesState(copyState);
        });
      }
    });
  }, [promisesState]);

  const allFinished = promisesState.filter(state => state !== PENDDING).length === promisesState.length;
  const hasError = promisesState.filter(state => state === FAIL).length > 0;

  return (
    <Fragment>
      {!allFinished ? renderProps(loadingView) : null}
      {allFinished && hasError ? (
        <Fragment>
          {renderProps(errorView)}
          {retryRender}
        </Fragment>
      ) : null}
      {allFinished && !hasError ? children : null}
    </Fragment>
  )
}

LoadingView.defaultProps = {
  promiseFuns: [],
};
