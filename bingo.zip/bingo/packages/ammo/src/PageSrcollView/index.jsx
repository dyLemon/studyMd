/* eslint-disable react/no-direct-mutation-state */
/* eslint-disable import/no-extraneous-dependencies */
/* eslint-disable react/no-array-index-key */
/* eslint-disable consistent-return */
/* eslint-disable no-param-reassign */
/* eslint-disable no-lonely-if */
/* eslint-disable camelcase */
/* eslint-disable no-underscore-dangle */
/* eslint-disable react/sort-comp */
/* eslint-disable react/no-unsafe */
import React, { PureComponent, Fragment } from "react";
import Taro from "@tarojs/taro";
import { ScrollView, View, Image } from "@tarojs/components";
import PropTypes from "prop-types";
import isEqual from "lodash/isEqual";
import { raf, sizeofByte, noop, cancelRaf } from "./utils";

// setState的阀值 1048576
// 经测试，当一次性setState的数据超过 60000 出现明显卡顿
const BYTE_COUNT_LIMIT = 60000;

// 安全值-用于时间分片-每次setState的数据量-也可支持外部传入
const CATON_SAFE_LIMIT = Math.ceil(BYTE_COUNT_LIMIT / 3);

// const bottomStaticText = '上拉加载更多';
const bottomLoadText = "加载中...";
const bottomLoadedText = "暂无更多数据";

class PageSrcollView extends PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      // 列表数据
      list: [],
      // 是否吸顶
      isCeiled: false,

      // 是否触发了自定义刷新
      refreshTrigger: false,

      // 滚动距离
      scrollTopValue: -1,

      // 不可见的列表
      noVisibleList: [],

      // 列表滚动区域距离顶部的距离
      scrollViewDistanceToTop: 0,

      // 滚动区域的footer高度 适用于footer为底部固定的场景
      scrollViewFooterHeight: 0,

      // 是否首次加载
      firstInitialLoaded: false,
    };

    PageSrcollView.INSTANCE_COUNTER += 1;

    // 是否加载完所有分页
    this.isLoaded = false;
    // 列表数据总数
    this.total = 0;

    // scrollView id
    this.scrollViewId = `ammo-scrollView-${PageSrcollView.INSTANCE_COUNTER}`;
    // stickyHeader id
    this.stickyHeaderId = `ammo-stickyHeader-${PageSrcollView.INSTANCE_COUNTER}`;
    // footer id
    this.footerId = `ammo-footer-${PageSrcollView.INSTANCE_COUNTER}`;
    // headerId id
    this.headerId = `ammo-header-${PageSrcollView.INSTANCE_COUNTER}`;
    // wrapper id前缀
    this.wrapperIdPreFix = `ammo-list-wrapper-${PageSrcollView.INSTANCE_COUNTER}-`;

    this.windowHeight = Taro.getSystemInfoSync().windowHeight;

    this.pageParams = {
      current: 1,
      size: props.size || 10,
    };

    // 可吸顶头部距离顶部的距离
    this.stickyHeaderDistanceToTop = 0;

    // 可吸顶头部的高度
    this.stickyHeaderHeight = -1;

    // header头部的高度
    this.headerHeight = 0;

    // 分页原始数据
    this.originData = [];

    // 用来装每一个wrapper的高度
    this.listWrapperHeights = [];

    // wrapper监控集合
    this.observers = [];

    // 滚动的距离
    this.scrollTop = 0;

    // 滚动加载中 主要解决ios回弹上拉加载触发多次
    this.isScrolling = false;

    // requestAnimationFrame id
    this.rafId = null;

    // 二维数组中一组几条数据
    this.groupCount = this.pageParams.size;
  }

  static INSTANCE_COUNTER = 0;

  componentDidMount() {
    const { initialLoad } = this.props;
    initialLoad && this.handleRequest();
    this.calcLayout();
  }

  // 检测到extraAsyncRequestParams有变化自动刷新
  componentDidUpdate(prevProps) {
    if (
      !isEqual(
        prevProps.extraAsyncRequestParams,
        this.props.extraAsyncRequestParams
      ) &&
      this.props.autoReload
    ) {
      this.handleRequest({}, { isReset: true });
    }
  }

  componentWillUnmount() {
    // 注销observer 否则会导致内存泄漏
    if (this.observers.length > 0) {
      this.observers.forEach((observer) => {
        observer?.disconnect?.();
      });
    }
    this.rafId && cancelRaf(this.rafId);
  }

  // 获取dom信息
  getDomInfo = (callback) => {
    Taro.nextTick(() => {
      setTimeout(callback, 10);
    });
  };

  // 是否开启了虚拟列表
  isOpenVirtualList = () => {
    const { openVirtualList, renderList } = this.props;
    return openVirtualList && typeof renderList === "function";
  };

  calcLayout = () => {
    this.getDomInfo(() => {
      const query = Taro.createSelectorQuery();
      query.select(`#${this.stickyHeaderId}`).boundingClientRect();
      query.select(`#${this.scrollViewId}`).boundingClientRect();
      query.select(`#${this.footerId}`).boundingClientRect();
      query.select(`#${this.headerId}`).boundingClientRect();
      query.exec(([stickyInfo, scrollViewInfo, footerInfo, headerInfo]) => {
        this.stickyHeaderDistanceToTop = stickyInfo?.top || 0;
        this.stickyHeaderHeight = stickyInfo?.height || 0;
        this.headerHeight = headerInfo?.height || 0;
        this.setState({
          isCeiled: (stickyInfo?.top || 0) === 0,
          scrollViewDistanceToTop: scrollViewInfo?.top || 0,
          scrollViewFooterHeight: footerInfo?.height || 0,
        });
      });
    });
  };

  // 包装 request 主要处理请求前、错误、请求完成 通用逻辑
  requestWrapper = async (params = {}) => {
    if (this.isScrolling) return Promise.reject();

    this.taroLoading();

    this.isScrolling = true;

    const { extraAsyncRequestParams, asyncRequest } = this.props;

    const requestParams = {
      ...this.pageParams,
      ...extraAsyncRequestParams,
      ...params,
    };

    try {
      const response = (await asyncRequest(requestParams)) ?? {};
      const { pages = 0, total = 0 } = response;
      this.isLoaded = requestParams.current >= pages;
      this.total = total;
      return response;
    } finally {
      this.setState({
        firstInitialLoaded: true,
        refreshTrigger: false,
      });
      this.isScrolling = false;
      this.taroLoading(false);
    }
  };

  /**
   * 外部通过 ref 直接调用该方法
   * @param {Object} params 额外参数， 覆盖 extraAsyncRequestParams
   * @param {Object} config 对列表的副作用操作
   * @param {Boolean} config.isReset 是否重置分页数据
   * @param {Boolean} config.stayStricky 是否停留在吸顶的原位置 否则滚动到顶部
   */
  handleRequest = (params = {}, options) => {
    const { isReset = false, stayStricky = false } = options || {};

    const { renderStickyHeader } = this.props;

    const { scrollTopValue } = this.state;

    if (isReset) {
      const setParams = {
        noVisibleList: [],
      };
      this.isLoaded = false;
      this.pageParams.current = 1;
      this.originData = [];
      this.listWrapperHeights = [];
      // 不存在吸顶或调用方不需要保持吸顶位置 需要清空list并设置滚动位置
      if (!renderStickyHeader || !stayStricky) {
        setParams.list = [];
        setParams.scrollTopValue =
          (scrollTopValue > 0 ? 0 : scrollTopValue) - 0.01;
      }
      this.setState(
        setParams,
        this.fetchDataAndDeal.bind(this, params, options)
      );
    } else {
      this.fetchDataAndDeal(params, options);
    }
  };

  fetchDataAndDeal = async (params = {}, options) => {
    const { stayStricky = false } = options || {};
    const { renderStickyHeader } = this.props;

    const result = (await this.requestWrapper(params)) || {};

    this.setOriginData((this.originData || []).concat(result.records || []));

    // 检查是否开启时间分片
    await this.handleBeforeSetState(result.records || []);

    // list 每组的数量
    this.groupCount = this.state.list?.[0]?.length ?? this.pageParams.size;

    // 为虚拟列表开启监听
    this.isOpenVirtualList() && this.getDomInfo(this.addObserveForList);

    if (stayStricky && renderStickyHeader && this.state.isCeiled) {
      const topValue = this.stickyHeaderDistanceToTop + 50;
      this.setState((prevState) => ({
        scrollTopValue:
          prevState.scrollTopValue !== topValue
            ? topValue
            : prevState.scrollTopValue + 0.01,
      }));
    }
  };

  // 全量更新列表已有数据（不推荐） 可作为ref调用
  UNRECOMMEND_reFreshData = async () => {
    const { firstInitialLoaded } = this.state;
    if (!firstInitialLoaded) {
      // 组件mount直接调用该方法 非常规手段
      this.handleRequest();
    } else {
      const { current, size: currentSize } = this.pageParams;
      const size =
        currentSize > 0 && current > 0
          ? parseInt(current * currentSize, 10)
          : currentSize;
      const res = await this.requestWrapper({
        current: 1,
        size,
      });
      this.setOriginData(res.records ?? []);
      this.state.list = this.formatList(res.records ?? [], this.groupCount);
      this.forceUpdate();
    }
  };

  // 刷新任一页码数据 可作为ref调用
  refreshPageData = async (wrapperIndex, index) => {
    const { size } = this.pageParams;
    const currentCount = wrapperIndex * this.groupCount + Number(index) + 1;
    const currentPage = Math.ceil(currentCount / size);
    const res = await this.requestWrapper({
      current: currentPage,
      size,
    });
    const flatList =
      this.state.list?.flat?.(1) ?? this.covertFlat(this.state.list);
    flatList.splice((currentPage - 1) * size, size, ...(res.records ?? []));

    this.setOriginData(flatList);

    this.state.list = this.formatList(flatList, this.groupCount);
    this.forceUpdate();
  };

  // 更新list某一条数据 可作为ref调用
  updateItemData = (wrapperIndex, index, detail) => {
    this.state.list[wrapperIndex][index] = detail;

    this.setOriginData(this.state.list);

    this.forceUpdate();
  };

  // 删除某一条数据 可作为ref调用
  destoryItem = (wrapperIndex, index) => {
    const currentIndex = wrapperIndex * this.groupCount + Number(index);
    const flatList =
      this.state.list?.flat?.(1) ?? this.covertFlat(this.state.list);
    flatList.splice(currentIndex, 1);

    this.setOriginData(flatList);

    this.state.list = this.formatList(flatList, this.groupCount);
    if (this.isOpenVirtualList()) {
      this.observers = [];
      this.getDomInfo(this.addObserveForList);
    }
    this.forceUpdate();
  };

  // 设置 originData
  setOriginData = (data) => {
    this.originData = [...(data ?? [])];
    this.props.onGetList(this.originData, this.getPaginationParams());
  };

  getPaginationParams = () => ({
    ...this.pageParams,
    total: this.total,
  });

  // 抹平flat兼容 只支持二维数组
  covertFlat = (list) =>
    list.reduce(
      (prev, cur) => [...prev, ...(Array.isArray(cur) ? cur : [cur])],
      []
    );

  // setState之前 检查是否需要时间分片
  handleBeforeSetState = (data) =>
    new Promise((resolve) => {
      //! 时间分片
      if (this.needTimeSlice(data) && this.props.openTimeSlice) {
        this.tick(0, this.formatList(data), resolve);
      } else {
        this.setState(
          (prevState) => ({
            list:
              this.pageParams.current === 1
                ? [data]
                : prevState.list.concat([data]),
          }),
          resolve
        );
      }
    });

  tick = (current = 0, data, callback) => {
    this.rafId = raf(() => {
      this.setState(
        (prevState) => {
          const _data = data.slice(current, current + 1);
          return {
            list:
              this.pageParams.current === 1 && current === 0
                ? _data
                : prevState.list.concat(_data),
          };
        },
        () => {
          if (data.length - current === 1) {
            // 分片渲染完成
            callback?.();
          }
        }
      );
      current += 1;
      if (current < data.length) {
        this.tick(current, data, callback);
      }
    });
  };

  addObserveForList = () => {
    const { length } = this.state.list;
    for (let index = 0; index < length; index += 1) {
      // 为listWrapper添加监控
      this.observe(index);
    }
  };

  observe = (index) => {
    const scrollHeight = this.getScrollHeight();

    // 设定监听的范围，默认监听上下两个屏幕的高度
    if (!this.observers[index]) {
      this.observers[index] = Taro.createIntersectionObserver(
        Taro.getCurrentInstance().page
      )
        .relativeToViewport({
          top: 2 * scrollHeight,
          bottom: 2 * scrollHeight,
        })
        .observe(`#${this.wrapperIdPreFix}${index}`, (res) => {
          this.listWrapperHeights[index] = res?.boundingClientRect?.height;
          if (res?.intersectionRatio <= 0) {
            // 删除dom结构
            this.state.noVisibleList.push(index);
            this.setState({
              noVisibleList: Array.from(new Set(this.state.noVisibleList)),
            });
          } else if (res?.intersectionRatio > 0) {
            // 还原
            this.setState({
              noVisibleList: this.state.noVisibleList.filter(
                (i) => i !== index
              ),
            });
          }
        });
    }
  };

  needTimeSlice = (data) => sizeofByte(data) >= BYTE_COUNT_LIMIT;

  // 获取scrollView 的height
  getScrollHeight = () => {
    const { scrollViewDistanceToTop, scrollViewFooterHeight } = this.state;
    const { extraBottomDisTance = 0 } = this.props;
    return (
      this.windowHeight -
      scrollViewDistanceToTop -
      scrollViewFooterHeight -
      extraBottomDisTance
    );
  };

  taroLoading = (flag = true) => {
    const { showLoading } = this.props;
    if (showLoading) {
      flag
        ? Taro.showLoading({ title: "请稍后...", mask: true })
        : Taro.hideLoading();
    }
  };

  getSegmentSize = (list) => {
    const byteCount = sizeofByte(list);
    // segmentSize 分组数据量同时也为时间分片数据量
    const { segmentSize, size } = this.props;

    const numberTimes = segmentSize
      ? byteCount / segmentSize
      : byteCount / CATON_SAFE_LIMIT;

    // 官方: 每秒调用setData的次数不超过 20 次
    const officialLimit = 20;

    if (numberTimes > officialLimit) {
      return Math.ceil(size / officialLimit);
    }

    return Math.ceil(size / numberTimes);
  };

  formatList = (list, size) => {
    const segmentSize = size || this.getSegmentSize(list);
    // 可自定义二维数组每一个维度的数据量 - 按时间分片的原则对list进行划分

    let arr = [];
    const _list = []; // 二维数组副本
    list?.forEach((item, index) => {
      arr.push(item);
      if ((index + 1) % segmentSize === 0) {
        // 够一个维度的量就装进_list
        _list.push(arr);
        arr = [];
      }
    });
    // 将分段不足segmentSize的剩余数据装入_list
    const restList = list.slice(_list.length * segmentSize);
    if (restList.length) {
      _list.push(restList);
    }
    return _list;
  };

  onScrollToLower = () => {
    const { isScrolling, isLoaded } = this;
    if (isScrolling || isLoaded) {
      return;
    }
    this.pageParams.current += 1;
    this.handleRequest();
  };

  scroll = (e) => {
    const scrollTop = parseInt(e.detail.scrollTop, 10);
    this.scrollTop = scrollTop;
    const isFixed = scrollTop >= this.stickyHeaderDistanceToTop;
    if (isFixed === this.state.isCeiled || !this.props.renderStickyHeader) {
      return false;
    }
    this.setState({
      isCeiled: isFixed,
    });
  };

  onRefresh = () => {
    const { refreshTrigger } = this.state;

    if (refreshTrigger) {
      return;
    }

    this.setState({ refreshTrigger: true }, () => {
      this.handleRequest({}, { isReset: true });
    });
  };

  renderList = (item, index) => {
    const { renderList } = this.props;
    return renderList(item, this.originData, index);
  };

  renderContent = (item, index) => {
    const { noVisibleList } = this.state;
    const noVisibleCondition =
      noVisibleList.includes(index) && this.listWrapperHeights[index];
    return !noVisibleCondition ? (
      this.renderList(item, index)
    ) : (
      <View
        style={{
          height: `${this.listWrapperHeights[index]}px`,
        }}
      />
    );
  };

  renderListContent = () => {
    const { list } = this.state;
    const { openVirtualList, renderList } = this.props;
    if (typeof renderList === "function") {
      return list?.map((item, index) =>
        openVirtualList ? (
          <View key={index} id={`${this.wrapperIdPreFix}${index}`}>
            {this.renderContent(item, index)}
          </View>
        ) : (
          <Fragment key={index}>{this.renderList(item, index)}</Fragment>
        )
      );
    }
    return renderList;
  };

  renderBottomTxt = () => {
    const { firstInitialLoaded } = this.state;
    const { renderLoadingStyle } = this.props;
    const { isLoaded } = this;
    if (firstInitialLoaded) {
      if (isLoaded) {
        return bottomLoadedText;
      }
      return renderLoadingStyle || bottomLoadText;
    }
    return "";
  };

  renderEmptyContent = () => {
    const { renderEmpty, emptyImage, emptyText } = this.props;
    return (
      renderEmpty || (
        <View className="ammo-empty">
          <Image className="ammo-empty-image" src={emptyImage} />
          <View className="ammo-empty-text">{emptyText}</View>
        </View>
      )
    );
  };

  render() {
    const {
      renderHeader,
      renderStickyHeader,
      renderFooter,
      refresherEnabled,
      containerStyle,
      scrollViewStyle = {},
      contentStyle = {},
      scrollViewProps,
    } = this.props;
    const {
      refreshTrigger,
      scrollTopValue,
      isCeiled,
      firstInitialLoaded,
    } = this.state;
    const { total } = this;
    return (
      <View
        className={`ammo-page-scroll-view-container ${
          firstInitialLoaded ? "ammo-calcLayout" : ""
        }`}
        style={containerStyle}
      >
        <ScrollView
          className="ammo-scroll-container"
          id={this.scrollViewId}
          scrollY
          style={{
            height: `${this.getScrollHeight()}px`,
            ...scrollViewStyle,
          }}
          onScrollToLower={this.onScrollToLower}
          onScroll={this.scroll}
          scrollTop={scrollTopValue}
          refresherEnabled={refresherEnabled}
          refresherTriggered={refreshTrigger}
          onRefresherRefresh={this.onRefresh}
          lowerThreshold={80}
          {...scrollViewProps}
        >
          <View style={contentStyle}>
            {/* 头部 跟随滚动 */}
            <View className="ammo-scroll-header" id={this.headerId}>
              {renderHeader}
            </View>

            {/* 吸顶区域 */}
            <View
              className={`ammo-sticky-header ${isCeiled ? "ammo-ceiled" : ""}`}
              id={this.stickyHeaderId}
            >
              {renderStickyHeader}
            </View>

            {this.props.children}
            {/* 列表部分 */}
            {firstInitialLoaded && total <= 0 ? (
              this.renderEmptyContent()
            ) : (
              <View
                style={{
                  height: isCeiled ? "100%" : "auto",
                }}
                className="ammo-scroll-list-content"
              >
                {this.renderListContent()}
                <View className="ammo-scroll-list-bottom">
                  {this.renderBottomTxt()}
                </View>
              </View>
            )}
          </View>
        </ScrollView>
        <View id={this.footerId}>{renderFooter}</View>
      </View>
    );
  }
}

PageSrcollView.propTypes = {
  initialLoad: PropTypes.bool,
  asyncRequest: PropTypes.func,
  extraAsyncRequestParams: PropTypes.object,
  onGetList: PropTypes.func,
  extraBottomDisTance: PropTypes.number,
  showLoading: PropTypes.bool,
  segmentSize: PropTypes.number,
  renderStickyHeader: PropTypes.element,
  renderList: PropTypes.oneOfType([PropTypes.element, PropTypes.func]),
  renderHeader: PropTypes.element,
  renderFooter: PropTypes.element,
  emptyImage: PropTypes.string,
  emptyText: PropTypes.string,
  refresherEnabled: PropTypes.bool,
  containerStyle: PropTypes.object,
  contentStyle: PropTypes.object,
  scrollViewStyle: PropTypes.object,
  children: PropTypes.element,
  size: PropTypes.number,
  autoReload: PropTypes.bool,
  openVirtualList: PropTypes.bool,
  scrollViewProps: PropTypes.object,
  renderEmpty: PropTypes.element,
  renderLoadingStyle: PropTypes.element,
  openTimeSlice: PropTypes.bool,
};

PageSrcollView.defaultProps = {
  initialLoad: true,
  asyncRequest: noop,
  extraAsyncRequestParams: {},
  onGetList: noop,
  extraBottomDisTance: 0,
  showLoading: false,
  renderList: noop,
  emptyImage:
    "http://static.biaoguoworks.com/miniprogram/peach/empty_placeholder.png",
  emptyText: "暂无数据",
  refresherEnabled: false,
  containerStyle: {},
  contentStyle: {},
  scrollViewStyle: {},
  size: 10,
  autoReload: true,
  openVirtualList: false,
  scrollViewProps: {},
  openTimeSlice: false,
};

export default PageSrcollView;
