/* eslint-disable no-control-regex */
export function ployfillRaf() {
  const prevTime = Date.now();
  return function(fn) {
    const nowTime = Date.now();
    const time = Math.max(0, 16 - (nowTime - prevTime));
    const id = setTimeout(fn, time);
    return id;
  };
}

export function raf(fn) {
  const fragmentation = requestAnimationFrame || ployfillRaf();
  return fragmentation(fn);
}

export function cancelRaf(id) {
  const cancelFragmentation = cancelAnimationFrame || clearTimeout;
  cancelFragmentation(id);
}

export function sizeofByte(data) {
  if (data !== null && data !== undefined) {
    return JSON.stringify(data).replace(/[^\x00-\xff]/g, "**").length;
  }
  return 0;
}

// 函数防抖
export function debounce(method, wait) {
  let timeout;
  return function(...args) {
    const context = this;
    if (timeout) {
      clearTimeout(timeout);
    }

    timeout = setTimeout(() => {
      method.apply(context, args);
    }, wait);
  };
}

export const noop = () => {};
