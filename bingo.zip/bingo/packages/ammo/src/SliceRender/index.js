import React, { Fragment, useEffect, useState, useRef } from 'react';

export default function (props) {
  const { children, sliceRange = 10, interval = 300 } = props;
  const childrenRef = useRef(Array.isArray(children) ? [...children] : [children]);
  const [renderChild, setRenderChild] = useState(childrenRef.current.slice(0, sliceRange));

  useEffect(() => {
    const renderLength = renderChild.length;
    if (renderLength < childrenRef.current.length) {
      setTimeout(() => {
        setRenderChild([...renderChild, ...childrenRef.current.slice(renderLength, renderLength + sliceRange)]);
      }, interval);
    }
  }, [renderChild]);

  return <Fragment>{renderChild}</Fragment>;
}
