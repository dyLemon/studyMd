# `auto-deploy`

> TODO: description

## Usage

```
const autoDeploy = require('auto-deploy');

// TODO: DEMONSTRATE API
```
