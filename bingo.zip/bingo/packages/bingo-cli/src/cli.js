const path = require("path");
const minimist = require("minimist");
const { getPkgVersion } = require("./utils");
const Project = require("./create/project");

class CLI {
  appPath = "";
  constructor(appPath) {
    this.appPath = appPath || process.cwd();
  }

  run() {
    this.parseArgs();
  }

  parseArgs() {
    const args = minimist(process.argv.slice(2), {
      alias: {
        version: ["v"],
        help: ["h"],
      },
      boolean: ["version", "help"],
    });
    const _ = args._;
    const command = _[0];
    if (command) {
      switch (command) {
        case "init": {
          const projectName = _[1] || args.name;
          const project = new Project({ projectName });
          project.init();
          break;
        }
      }
    } else {
      if (args.h) {
        console.log("Usage: @bingo/cli <command> [options]");
        console.log();
        console.log("Options:");
        console.log("  -v, --version       output the version number");
        console.log("  -h, --help          output usage information");
        console.log();
        console.log("Commands:");
        console.log(
          "  init [projectName]  Init a project with default templete"
        );
      } else if (args.v) {
        console.log(getPkgVersion());
      }
    }
  }
}

module.exports = CLI;
