const DEFAULT_TEMPLATE_WEB =
  "direct:https://gitee.com/o2team/taro-project-templates.git#v3.1";
const DEFAULT_TEMPLATE_MINIPROGRAM =
  "direct:https://gitee.com/o2team/taro-project-templates.git#v3.1";
const DEFAULT_TEMPLATE_H5 =
  "direct:https://gitee.com/o2team/taro-project-templates.git#v3.1";

const GIT_SROUCE =
  "direct:git@git.biaoguoworks.com:front/bingo-template.git#master";

const OUTPUT_DIR = "dist";
const SOURCE_DIR = "src";
const TEMPLATE_CREATOR = "template_creator.js";

module.exports = {
  DEFAULT_TEMPLATE_WEB,
  DEFAULT_TEMPLATE_MINIPROGRAM,
  DEFAULT_TEMPLATE_H5,
  OUTPUT_DIR,
  SOURCE_DIR,
  TEMPLATE_CREATOR,
  GIT_SROUCE,
};
