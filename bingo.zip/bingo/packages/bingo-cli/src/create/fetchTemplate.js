const { TEMPLATE_CREATOR } = require("./constants");
const chalk = require("chalk");
const fs = require("fs-extra");
const path = require("path");
const ora = require("ora");
const download = require("download-git-repo");

const TEMP_DOWNLOAD_FLODER = "cli-temp";

function fetchTemplate(templateSource, templateRootPath) {
  const tempPath = path.join(templateRootPath, TEMP_DOWNLOAD_FLODER);

  return new Promise(async (resolve) => {
    // 下载文件的缓存目录
    if (fs.existsSync(tempPath)) await fs.remove(tempPath);
    await fs.mkdir(tempPath);

    const spinner = ora(`正在从 ${templateSource} 拉取远程模板...`).start();

    download(
      templateSource,
      path.join(tempPath),
      { clone: true },
      async (error) => {
        if (error) {
          console.log(error);
          spinner.color = "red";
          spinner.fail(chalk.red("拉取远程模板仓库失败！"));
          await fs.remove(tempPath);
          return resolve();
        }
        spinner.color = "green";
        spinner.succeed(`${chalk.grey("拉取远程模板仓库成功！")}`);
        resolve();
      }
    );
  });
}

module.exports = {
  fetchTemplate,
  TEMP_DOWNLOAD_FLODER,
};
