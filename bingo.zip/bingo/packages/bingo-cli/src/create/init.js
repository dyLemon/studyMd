const fs = require("fs-extra");
const path = require("path");
const { exec } = require("child_process");
const ora = require("ora");
const chalk = require("chalk");
const { TEMP_DOWNLOAD_FLODER } = require("./fetchTemplate");
const {
  getAllFilesInFloder,
  shouldUseCnpm,
  getPkgVersion,
  shouldUseYarn,
} = require("../utils");

const TEMPLATE_CREATOR = "template_creator.js";

const doNotCopyFiles = [".DS_Store", ".npmrc", TEMPLATE_CREATOR];

const styleExtMap = [".scss", ".less"];

function createFiles(creater, files, handler, options) {
  const {
    description,
    projectName,
    version,
    css,
    date,
    typescript,
    template,
    templatePath,
    projectPath,
    pageName,
    framework,
  } = options;
  const logs = [];

  files.forEach((file) => {
    // fileRePath startsWith '/'
    const fileRePath = file
      .replace(templatePath, "")
      .replace(new RegExp(`\\${path.sep}`, "g"), "/");
    let externalConfig = null;

    // 跑自定义逻辑，确定是否创建此文件
    if (handler && typeof handler[fileRePath] === "function") {
      externalConfig = handler[fileRePath](options);
      if (!externalConfig) return;
    }

    // 如果选择语言为js 前序工作已经进行了ts转译 因此此时需要将ts、tsx文件在循环中剔除
    if (!typescript && path.extname(fileRePath).includes(".ts")) {
      return;
    }

    // 合并自定义 config
    const config = Object.assign(
      {},
      {
        description,
        projectName,
        version,
        css,
        date,
        typescript,
        template,
        pageName,
        framework,
      },
      externalConfig
    );

    let destRePath = fileRePath.replace(/^\//, "");

    const styleExtName = path.extname(destRePath);

    if (styleExtMap.includes(styleExtName)) {
      destRePath = destRePath.replace(styleExtName, `.${css}`);
    }

    // 创建
    creater.template(
      template,
      fileRePath,
      path.join(projectPath, destRePath),
      config
    );

    const destinationPath = creater.destinationPath(
      path.join(projectPath, destRePath)
    );
    logs.push(
      `${chalk.green("✔ ")}${chalk.grey(`创建文件: ${destinationPath}`)}`
    );
  });
  return logs;
}

async function createApp(creater, params, cb) {
  const {
    projectName,
    projectDir,
    template, // 选择的模板
    autoInstall = false,
  } = params;
  const logs = [];
  // path
  const templatePath = creater.templatePath(template);

  const projectPath = path.join(projectDir, projectName);

  const version = getPkgVersion();

  // 遍历出!选择的模板中所有文件
  const files = await getAllFilesInFloder(templatePath, doNotCopyFiles);

  // 引入模板编写者的自定义逻辑
  const handlerPath = path.join(templatePath, TEMPLATE_CREATOR);
  const handler = fs.existsSync(handlerPath)
    ? require(handlerPath).handler
    : null;

  // 为所有文件进行创建
  logs.push(
    ...createFiles(creater, files, handler, {
      ...params,
      version,
      templatePath,
      projectPath,
      pageName: "index",
      period: "createApp",
    })
  );

  // fs commit
  creater.fs.commit(async () => {
    // logs
    console.log();
    console.log(
      `${chalk.green("✔ ")}${chalk.grey(
        `创建项目: ${chalk.grey.bold(projectName)}`
      )}`
    );
    logs.forEach((log) => console.log(log));
    console.log();

    // git init
    const gitInitSpinner = ora(
      `cd ${chalk.cyan.bold(projectName)}, 执行 ${chalk.cyan.bold("git init")}`
    ).start();
    process.chdir(projectPath);
    const gitInit = exec("git init");
    gitInit.on("close", (code) => {
      if (code === 0) {
        gitInitSpinner.color = "green";
        gitInitSpinner.succeed(gitInit.stdout.read());
      } else {
        gitInitSpinner.color = "red";
        gitInitSpinner.fail(gitInit.stderr.read());
      }
    });

    // 删除本地模板
    await Promise.all([
      fs.remove(creater.templatePath(TEMP_DOWNLOAD_FLODER)),
      fs.remove(templatePath),
    ]);

    const callSuccess = () => {
      console.log(
        chalk.green(`创建项目 ${chalk.green.bold(projectName)} 成功！`)
      );
      console.log(
        chalk.green(
          `请进入项目目录 ${chalk.green.bold(projectName)} 开始工作吧！😝`
        )
      );
      if (typeof cb === "function") {
        cb();
      }
    };

    if (autoInstall) {
      // packages install
      let command;
      if (shouldUseYarn()) {
        command = "yarn install";
      } else if (shouldUseCnpm()) {
        command = "cnpm install";
      } else {
        command = "npm install";
      }
      const installSpinner = ora(
        `执行安装项目依赖 ${chalk.cyan.bold(command)}, 需要一会儿...`
      ).start();
      exec(command, (error, stdout, stderr) => {
        if (error) {
          installSpinner.color = "red";
          installSpinner.fail(chalk.red("安装项目依赖失败，请自行重新安装！"));
          console.log(error);
        } else {
          installSpinner.color = "green";
          installSpinner.succeed("安装成功");
          console.log(`${stderr}${stdout}`);
        }
        callSuccess();
      });
    } else {
      callSuccess();
    }
  });
}

module.exports = {
  createApp,
  TEMPLATE_CREATOR,
};
