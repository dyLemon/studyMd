const fs = require("fs-extra");
const path = require("path");
const util = require("util");
const inquirer = require("inquirer");
const semver = require("semver");
const chalk = require("chalk");
const ora = require("ora");
const { exec } = require("child_process");
const _ = require("lodash");
const Creator = require("./creator");
const { shouldUseTs, getAllFilesInFloder } = require("../utils");
const { SOURCE_DIR, GIT_SROUCE } = require("./constants");

const { createApp } = require("./init");
const { fetchTemplate, TEMP_DOWNLOAD_FLODER } = require("./fetchTemplate");

const execPromise = util.promisify(exec);

class Project extends Creator {
  rootPath;
  conf = {};
  constructor(options) {
    super(options.sourceRoot);

    const unSupportedVer = semver.lt(process.version, "v7.6.0");
    if (unSupportedVer) {
      throw new Error("Node.js 版本过低，推荐升级 Node.js 至 v8.0.0+");
    }

    this.rootPath = this._rootPath;

    this.conf = Object.assign(
      {
        projectName: "",
        projectDir: "",
        template: "",
        description: "",
      },
      options
    );
  }

  init() {
    console.log(chalk.green("@bingo/cli 即将创建一个新项目!"));
    console.log();
    this.create();
  }

  async create() {
    try {
      const answers = await this.ask();
      const date = new Date();
      this.conf = Object.assign(this.conf, answers);
      this.conf.date = `${date.getFullYear()}-${date.getMonth() +
        1}-${date.getDate()}`;
      this.write();
    } catch (error) {
      console.log(chalk.red("创建项目失败: ", error));
    }
  }

  async ask() {
    let prompts = [];
    const conf = this.conf;
    this.askProjectName(conf, prompts);
    this.askDescription(conf, prompts);
    this.askTemplateSource(conf, prompts);
    this.askTypescript(conf, prompts);
    this.askCSS(conf, prompts);

    const answers = await inquirer.prompt(prompts);

    await this.fetchTemplates(answers);

    // 转译ejs
    await this.transformEjs(answers);

    // 转译ts
    await this.transformTs(answers);

    return answers;
  }

  askProjectName(conf, prompts) {
    prompts.push({
      type: "input",
      name: "projectName",
      message: "请输入项目名称！",
      validate(input) {
        if (!input) {
          return "项目名不能为空！";
        }
        if (fs.existsSync(input)) {
          return "当前目录已经存在同名项目，请换一个项目名！";
        }
        return true;
      },
    });
  }

  askDescription(conf, prompts) {
    if (typeof conf.description !== "string") {
      prompts.push({
        type: "input",
        name: "description",
        message: "请输入项目介绍！",
      });
    }
  }

  askTemplateSource(conf, prompts) {
    const templates = [
      {
        name: "web",
        value: "web",
      },
      {
        name: "小程序",
        value: "miniprogram",
      },
      {
        name: "h5",
        value: "h5",
      },
    ];
    prompts.push({
      type: "list",
      name: "template",
      message: "请选择开发端",
      choices: templates,
    });
  }

  askTypescript(conf, prompts) {
    if (typeof conf.typescript !== "boolean") {
      prompts.push({
        type: "confirm",
        name: "typescript",
        message: "是否需要使用 TypeScript ？",
      });
    }
  }

  askCSS(conf, prompts) {
    const cssChoices = [
      {
        name: "Sass",
        value: "scss",
      },
      {
        name: "Less",
        value: "less",
      },
    ];

    if (typeof conf.css !== "string") {
      prompts.push({
        type: "list",
        name: "css",
        message: "请选择 CSS 预处理器（Sass/Less）",
        choices: cssChoices,
      });
    }
  }

  async fetchTemplates(answers) {
    // 使用默认模版
    if (answers.template === "default") return Promise.resolve([]);

    // 从模板源下载模板
    return await fetchTemplate(GIT_SROUCE, this.templatePath(""));
  }

  // 解析ejs
  async transformEjs(answers) {
    const srcPath = this.templatePath(TEMP_DOWNLOAD_FLODER, answers.template);
    // 遍历出!选择的模板中所有文件
    const files = await getAllFilesInFloder(srcPath, []);
    return new Promise((resolve) => {
      const ejsSpinner = ora("转译ejs").start();
      files.forEach((file) => {
        const fileRePath = file
          .replace(srcPath, "")
          .replace(new RegExp(`\\${path.sep}`, "g"), "/");
        const dest = this.templatePath(answers.template, fileRePath);
        this.fs.copyTpl(file, dest, Object.assign({ _ }, this, answers));
      });
      this.fs.commit(() => {
        ejsSpinner.color = "green";
        ejsSpinner.succeed("转译ejs 成功");
        resolve();
      });
    });
  }

  // 转译ts
  async transformTs(answers) {
    if (answers.typescript) return Promise.resolve();
    await this.installTs();
    const { template } = answers;
    // 使用js语法时 需ts转js
    const tscSpinner = ora(`转译ts, 执行 ${chalk.cyan.bold("tsc")}`).start();
    // 切换工作目录
    const nowPath = process.cwd();
    process.chdir(this.templatePath(template));
    // 转译ts
    const tscCommander = exec("tsc", {
      stdio: "ignore",
    });
    return new Promise((resolve) => {
      tscCommander.on("close", (code, stderr) => {
        if (code === 2) {
          tscSpinner.color = "green";
          tscSpinner.succeed(tscCommander.stdout.read());
          // 切换工作目录 还原回去
          process.chdir(nowPath);
          resolve();
        } else {
          tscSpinner.fail(tscCommander.stderr.read());
          process.exit(1);
        }
      });
    });
  }

  async installTs() {
    if (shouldUseTs()) {
      return Promise.resolve();
    }
    const tsSpinner = ora("未安装ts, 正在安装").start();
    try {
      const { stdout } = await execPromise(
        "npm install -g typescript --registry=https://registry.npm.taobao.org"
      );
      tsSpinner.color = "green";
      tsSpinner.succeed("typescript 安装成功");
      return stdout;
    } catch (error) {
      tsSpinner.fail("typescript 安装失败");
      process.exit(1);
    }
  }

  write(cb) {
    this.conf.src = SOURCE_DIR;
    createApp(this, this.conf, cb).catch((err) => console.log(err));
  }
}

module.exports = Project;
