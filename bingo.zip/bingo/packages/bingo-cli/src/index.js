#!/usr/bin/env node

const CLI = require("./cli");

const cli = new CLI();

cli.run();
