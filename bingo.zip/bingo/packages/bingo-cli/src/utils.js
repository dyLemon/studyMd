const path = require("path");
const os = require("os");
const { execSync } = require("child_process");
const fs = require("fs-extra");

function getRootPath() {
  return path.resolve(__dirname, "../");
}

function getPkgVersion() {
  return require(path.join(getRootPath(), "package.json")).version;
}

function getUserHomeDir() {
  function homedir() {
    const env = process.env;
    const home = env.HOME;
    const user = env.LOGNAME || env.USER || env.LNAME || env.USERNAME;

    if (process.platform === "win32") {
      return env.USERPROFILE || "" + env.HOMEDRIVE + env.HOMEPATH || home || "";
    }

    if (process.platform === "darwin") {
      return home || (user ? "/Users/" + user : "");
    }

    if (process.platform === "linux") {
      return (
        home || (process.getuid() === 0 ? "/root" : user ? "/home/" + user : "")
      );
    }

    return home || "";
  }
  return typeof os.homedir === "function" ? os.homedir() : homedir();
}

function readDirWithFileTypes(floder) {
  const list = fs.readdirSync(floder);
  const res = list.map((name) => {
    const stat = fs.statSync(path.join(floder, name));
    return {
      name,
      isDirectory: stat.isDirectory(),
      isFile: stat.isFile(),
    };
  });
  return res;
}

const getAllFilesInFloder = async (floder, filter = []) => {
  let files = [];
  const list = readDirWithFileTypes(floder);

  await Promise.all(
    list.map(async (item) => {
      const itemPath = path.join(floder, item.name);
      if (item.isDirectory) {
        const _files = await getAllFilesInFloder(itemPath, filter);
        files = [...files, ..._files];
      } else if (item.isFile) {
        if (!filter.find((rule) => rule === item.name)) files.push(itemPath);
      }
    })
  );

  return files;
};

function shouldUseYarn() {
  try {
    execSync("yarn --version", { stdio: "ignore" });
    return true;
  } catch (e) {
    return false;
  }
}

function shouldUseCnpm() {
  try {
    execSync("cnpm --version", { stdio: "ignore" });
    return true;
  } catch (e) {
    return false;
  }
}

function shouldUseTs() {
  try {
    execSync("tsc --version");
    return true;
  } catch (e) {
    return false;
  }
}

module.exports = {
  getRootPath,
  getPkgVersion,
  getUserHomeDir,
  readDirWithFileTypes,
  getAllFilesInFloder,
  shouldUseYarn,
  shouldUseCnpm,
  shouldUseTs,
};
