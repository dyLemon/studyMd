const copyPlugin = require('rollup-plugin-copy');

module.exports = {
  entry: [
    './src/index.js',
    './src/react.js',
    './src/vue.js',
    './src/rcGenerate.js',
  ],
  cjs: true,
  umd: false,
  esm: false,
  extraRollupPlugins: [
    copyPlugin({
      targets: [{ src: 'src/rules', dest: 'dist' }],
    }),
  ],
};
