# `eslint-config-bingo-prettier`

> TODO: description

## 安装

```
npm install eslint-config-bingo-prettier -D
或
yarn add eslint-config-bingo-prettier -D
```

## 使用

```
// .eslintrc文件中添加
extends: [
  'bingo-prettier/dist/react' 或 'bingo-prettier/dist/vue'
]
```
