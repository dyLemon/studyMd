'use strict';

const eslintConfigBingoBase = require('..');

describe('eslint-config-bingo-base', () => {
    it('needs tests');
});
