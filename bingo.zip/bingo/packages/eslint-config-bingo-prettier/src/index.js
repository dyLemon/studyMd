module.exports = {
  rules: {
    'prettier/prettier': ['error', require('./rules/prettier.js')]
  }
}