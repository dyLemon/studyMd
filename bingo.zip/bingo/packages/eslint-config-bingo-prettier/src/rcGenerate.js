const path = require('path');
const fs = require('fs');
const prettierConfig = require('./rules/prettier');

// '../..为了写到项目根目录'
fs.writeFile(
  path.join(process.cwd(), '../..', '.prettierrc.js'),
  Buffer.from('module.exports = ' + JSON.stringify(prettierConfig, null, 2)),
  (err) => {
    if (err) {
      console.log(err);
      console.log('.prettierrc.js 文件生成失败，请重新安装此包');
    }
  }
);
