module.exports = Object.assign({}, require('./index'), {
  extends: [
    'prettier',
  ],
  plugins: [
    'prettier'
  ]
});