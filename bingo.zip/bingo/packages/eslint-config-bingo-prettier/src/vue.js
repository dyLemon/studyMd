module.exports = Object.assign({}, require('./index'), {
  extends: [
    '@vue/prettier'
  ],
});