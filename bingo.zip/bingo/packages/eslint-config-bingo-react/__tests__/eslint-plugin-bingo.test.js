'use strict';

const eslintPluginBingo = require('..');

describe('eslint-plugin-bingo', () => {
    it('needs tests');
});
