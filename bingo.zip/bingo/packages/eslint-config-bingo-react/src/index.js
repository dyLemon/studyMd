module.exports = {
  root: true,
  extends: [
    './rules/airbnb.js',
    './rules/react.js',
    './rules/jsx.js'
  ].map(require.resolve),
  parser: require.resolve('babel-eslint'),
  parserOptions: {
    ecmaVersion: 2020,
    ecmaFeatures: {
      jsx: true,
      legacyDecorators: true
    }
  },
  settings: {
    pragma: 'React',
    version: 'detect',
    'import/resolver': {
      node: {
        extensions: ['.js', '.jsx', 'ts', 'tsx']
      }
    },
  }
}