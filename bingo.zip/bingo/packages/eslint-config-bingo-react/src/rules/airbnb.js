module.exports = {
  extends: [
    'airbnb-base'
  ],
  rules: {
    'no-unused-vars': ['warn'], // 生产环境拦截未使用变量
    'no-unused-expressions': ['off'],
    'class-methods-use-this': ['off'], // 关闭类方法中没使用this必须将方法静态化
    'no-underscore-dangle': ['off'], // 可以使用 `_名称` 命名
    'import/extensions': ['error', 'always', { js: 'never', jsx: 'never', ts: 'never', tsx: 'never' }], // 强制import .js / .jsx / .ts / .tsx 不加后缀
  }
}
