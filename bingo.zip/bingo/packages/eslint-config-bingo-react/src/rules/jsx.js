module.exports = {
  extends: [
    'plugin:jsx-a11y/recommended'
  ],
  rules: {
    'jsx-a11y/no-static-element-interactions': ['off'], // 关闭强制事件必须有role属性
    'jsx-a11y/click-events-have-key-events': ['off'], // 关闭onClick等必须带有onKeyUp, onKeyDown, onKeyPress事件名
    'jsx-a11y/no-noninteractive-element-interactions': ['off'], // 关闭onClick等必须带有role属性
  }
}