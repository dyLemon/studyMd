module.exports = {
  extends: [
    'plugin:react/recommended'
  ],
  rules: {
    'react/jsx-filename-extension': [1, { extensions: ['.js', '.jsx', '.ts', '.tsx'] }], // 允许.js, .jsx使用jsx写法
    'react/boolean-prop-naming': ['error'], // bool类型变量命名必须使用is | has开头
    'react/no-array-index-key': ['error'], // 禁止使用数组下标做为key值
    'react/no-did-update-set-state': ['error'], // 禁止在componentDidUpdate中使用setState
    'react/no-this-in-sfc': ['error'], // 无状态组件禁止使用this
    'react/no-typos': ['warn'], // 常见react生命周期错别字警告
    'react/prop-types': ['warn'], // props无类型警告
    'react/no-unsafe': ['error'], // 禁止使用不安全生命周期
    'react/no-unused-state': ['warn'], // 未使用的state警告
    'react/self-closing-comp': ['warn'], // 无子node需要自闭合警告
    'react/sort-comp': ['error'], // 生命周期必须按顺书写
    'react/jsx-boolean-value': ['error'], // props bool类型true不需要写xx={true}
    'react/jsx-closing-bracket-location': ['error'], // 强制jsx元素右括号对齐
    'react/jsx-indent': ['error', 2, { indentLogicalExpressions: true }], // jsx缩进检查 2 space
    'react/jsx-curly-newline': ['off'], // 关闭括弧变量样式统一，有prettier配置
    'react/display-name': ['off'], // 关闭react com必须要方法名
    'react/react-in-jsx-scope': ['off'], // 写jsx可以不用import React
  }
}
