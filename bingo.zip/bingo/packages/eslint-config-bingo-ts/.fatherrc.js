module.exports = {
  cjs: true,
  umd: false,
  esm: false,
};
