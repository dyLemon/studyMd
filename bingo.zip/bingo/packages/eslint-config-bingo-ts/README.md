# `eslint-config-bingo-ts`

> TODO: description

## Usage

```
const eslintConfigBingoTs = require('eslint-config-bingo-ts');

// TODO: DEMONSTRATE API
```
