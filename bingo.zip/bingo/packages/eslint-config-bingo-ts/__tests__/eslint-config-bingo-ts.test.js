'use strict';

const eslintConfigBingoTs = require('..');

describe('eslint-config-bingo-ts', () => {
    it('needs tests');
});
