const path = require('path');
const copyPlugin = require('rollup-plugin-copy');

module.exports = {
  cjs: true,
  umd: false,
  esm: false,
  extraRollupPlugins: [
    copyPlugin({
      targets: [{ src: 'src/rules', dest: 'dist' }],
    }),
  ],
};
