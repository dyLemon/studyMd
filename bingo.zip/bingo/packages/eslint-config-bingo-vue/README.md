# `eslint-config-bingo-vue`

标果团队 vue eslint 规范（适用于vue2.x）

## 安装

```
npm install eslint-config-bingo-vue -D
或
yarn add eslint-config-bingo-vue -D
```

## 使用

```
// .eslintrc文件中添加
extends: [
  'bingo-vue'
]
```
