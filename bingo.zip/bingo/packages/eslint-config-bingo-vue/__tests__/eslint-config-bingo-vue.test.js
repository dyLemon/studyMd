'use strict';

const eslintConfigBingoVue = require('..');

describe('eslint-config-bingo-vue', () => {
    it('needs tests');
});
