module.exports = {
  root: true,
  extends: [
    './rules/airbnb.js',
    './rules/vue.js'
  ].map(require.resolve),
  parser: require.resolve('vue-eslint-parser'),
  parserOptions: {
    ecmaVersion: 2019,
    ecmaFeatures: {
      legacyDecorators: true
    },
    parser: require.resolve('babel-eslint')
  },
  settings: {
    'import/resolver': {
      node: {
        extensions: ['.js', '.vue'],
      },
    },
  }
}