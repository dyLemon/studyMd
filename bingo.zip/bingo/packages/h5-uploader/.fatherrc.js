const path = require('path');
const { preserveShebangs } = require('rollup-plugin-preserve-shebangs');

module.exports = {
  target: 'node',
  entry: './src/index',
  // 使用rollup打包成commonjs标准模块输出
  cjs: {
    type: 'rollup',
    minify: true,
    file: 'cjs/h5-uploader.min',
  },
  umd: false,
  esm: false,
  extraRollupPlugins: [
    preserveShebangs(),
  ],
}
