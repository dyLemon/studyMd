# `h5-uploader`

> TODO: description

## Usage

```
const h5Uploader = require('h5-uploader');

// TODO: DEMONSTRATE API
```
