#!/usr/bin/env node
'use strict';


const fs = require('fs');
const path = require('path');
const { Commander } = require('commander');
const qiniu = require('qiniu');
const colors = require('colors');
const ROOT_PATH = process.cwd();

const program = new Commander();
program
  .version('0.0.1')
  .option('-s, --source <source>', 'files source dir path, who will uplaod to qiniu')
  .option('-t, --target <target>', 'qiniu target path')
  .option('-b, --bucket [bucket]', 'qiniu bucket default value: h5')
  .parse(process.argv);

if (!program.source || !program.target) {
  console.log('source参数，target参不能为空'.red);
  process.exit(1);
}

const uploadSource = program.source || './dist';

// 授权秘钥
const accessKey = 'wOUMofgLLU7O-wFC0mZT2DU20ZZMY6cmUBGyQCmJ';
const secretKey = '9CD4IeLNrM31SEEUXvGwU3jFST0Fc1hgPalNVxdY';

// 存储空间名称
const bucket = program.bucket || 'h5';

// 创建鉴权对象
const mac = new qiniu.auth.digest.Mac(accessKey, secretKey);

// 创建并修改配置对象(Zone_z0=华东 Zone_z1=华北 Zone_z2=华南 Zone_na0=北美)
const config = new qiniu.conf.Config();
config.zone = qiniu.zone.Zone_z2;

// 文件上传方法
function uploadFile(localFilePath, remotePath) {
  const putPolicy = new qiniu.rs.PutPolicy({
    scope: `${bucket}:${remotePath}`,
  });
  // 生成上传凭证
  const uploadToken = putPolicy.uploadToken(mac)
  // 配置上传到七牛云的完整路径
  // 创建额外内容对象
  const putExtra = new qiniu.form_up.PutExtra();  
  // 创建表单上传对象
  const formUploader = new qiniu.form_up.FormUploader(config);
  return new Promise((rsv) => {
    formUploader.putStream(
      uploadToken,
      remotePath,
      fs.createReadStream(localFilePath),
      putExtra,
      (respErr, respBody) => {
        if (respErr) throw respErr;
        console.log('已上传: ', respBody);
        rsv();
      },
    );
  });
}

function uploadIterator(arr = [], dirPath) {
  return new Promise(async (resolve) => {
    if (arr.length) {
      const fileName = arr.shift();
      try {
        const filePath = path.join(ROOT_PATH, dirPath, fileName);
        const stats = fs.statSync(filePath);
        if (stats.isDirectory()) {
          // eslint-disable-next-line no-use-before-define
          uploadDirectory(`${dirPath}/${fileName}`);
          resolve(uploadIterator(arr, dirPath));
        } else {
          const sourcePath = program.source.replace(/^\W+/, '');
          const flatDirPath = dirPath.replace(sourcePath, '');
          const remotePath = path.join(program.target, flatDirPath, fileName);
          const qiniuFormatPath = remotePath.replace(/\\/g, '/'); // win路径转换;

          await uploadFile(filePath, qiniuFormatPath);
          resolve(uploadIterator(arr, dirPath));
        }
      } catch (e) {
        console.log(e);
        console.log('文件传输失败，请重新运行命令'.red);
        process.exit(1);
      }
    } else {
      resolve();
    }
  });
}

// 目录上传方法
async function uploadDirectory(dirPath) {
  const files = fs.readdirSync(path.join(ROOT_PATH, dirPath));
  await uploadIterator(files, dirPath);
  if (path.join(dirPath) === path.join(uploadSource)) {
    console.log('所有文件上传完毕'.green);
  }
}

fs.exists(uploadSource, (exists) => {
  if (!exists) {
    console.log('目录不存在！'.red);
  } else {
    console.log('开始上传...'.green);
    uploadDirectory(uploadSource);
  }
});
