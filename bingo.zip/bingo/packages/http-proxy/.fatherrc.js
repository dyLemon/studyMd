// const { preserveShebangs } = require('rollup-plugin-preserve-shebangs');

module.exports = {
  target: 'node',
  entry: ['src/index.js'],
  cjs: {
    type: 'babel',
    minify: true,
  },
  umd: false,
  esm: false,
  extraRollupPlugins: [
    // preserveShebangs(),
  ],
}
