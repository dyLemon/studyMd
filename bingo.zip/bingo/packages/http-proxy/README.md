# `http-proxy`

> TODO: description

## Usage

```
const httpProxy = require('http-proxy');

// TODO: DEMONSTRATE API
```
