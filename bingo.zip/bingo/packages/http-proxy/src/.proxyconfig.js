module.exports = {
  port: 3031,
  proxy: [
    {
      context: '/web/ep/order/list',
      mock: {
        content: {
          current: {
            $type: '@int',
            $range: [1, 10]
          },
          pages: {
            $type: '@int',
            $range: [1, 10]
          },
          orders: [],
          searchCount: '@boolean',
          size: 10,
          total: '@int',
          records: {
            $type: [],
            $range: [1, 10],
            $value: [{
              address: '@region',
              cityId: '@id',
              cityName: '@area',
              companyId: 2,
              consigneeRealname: '@cname',
              consigneeTelphone: {
                $type: '@int',
                $range: [11, 11]
              },
              countyName: '@area',
              createTime: {
                $type: '@datetime',
                $value: 'YYYY-MM-DD HH:mm:ss'
              },
              customerId: '@id',
              customerMobile: {
                $type: '@int',
                $range: [11, 11]
              },
              customerName: '@cname',
              customerStoreId: '@id',
              customerStoreLinkMan: "@cword",
              customerStoreLinkPhone: {
                $type: '@int',
                $range: [11, 11]
              },
              districtId: '@id',
              estimateDeliverDate: {
                $type: '@date',
                $value: 'yy-MM-dd'
              },
              id: '@id',
              inviteUserId: '@id',
              inviteUserName: '@cname',
              loadingAddress: null,
              orderCustomerType: {
                $type: '@enum',
                $value: ['COMMONLY', 'BIG_CUSTOMER']
              },
              orderMoney: {
                $type: '@float',
                $dRange: [2, 2]
              },
              orderNo: '@id', 
              orderSourceType: {
                $type: '@enum',
                $value: ['MANAGE', 'COMMON']
              },
              orderUserCoupons: [],
              payChannel:  {
                $type: '@enum',
                $value: ['PREPAID', 'CASH_ON_DELIVERY', 'OFFINE_PAYMENT']
              },
              payStatus: {
                $type: '@enum',
                $value: ['UNCONFIRMED', 'CONFIRMED', 'SUCCESS', 'USER_CONFIRMED', 'SUCCESS_ARREARS_PAY', 'SUCCESS_PLATFORM_PAY', 'SUCCESS_ORDER_END_OVERCHARGE_AUTO', 'FAILED']
              },
              payTime: '@datetime',
              payType: {
                $type: '@enum',
                $value: ['PREPAID', 'CASH_ON_DELIVERY', 'OFFINE_PAYMENT']
              },
              payableAmount: {
                $type: '@float',
                $dRange: [2, 2]
              },
              paymentAmount: {
                $type: '@float',
                $dRange: [2, 2]
              },
              provinceId: '@id',
              provinceName: '@area',
              remark: '@string',
              shippingMoney: {
                $type: '@float',
                $dRange: [2, 2]
              },
              statementDate: '@datetime',
              status: {
                $type: '@enum',
                $value: ['WAIT_RETURN', 'ALREADY_RETURN', 'COMPLETE']
              },
              stockId: '@id',
              stockName: '@cname',
              storeCityName: '@region',
              storeCountyName: '@region',
              storeName: '@ctitle',
              storeStreetName: '@region',
              streetId: '@id',
              streetName: '@region',
              timeLimit: 0,
              orderItems: {
                $type: [],
                $range: [1, 5],
                $value: [{
                  activityPrice: {
                    $type: '@float',
                    $dRange: [2, 2]
                  },
                  afterSaleOrderId: null,
                  afterSaleOrderStatus: null,
                  attachUrl: '@image',
                  attachUrlWithoutHost: "@image",
                  babyName: '@cname',
                  companyId: '@id',
                  customerRemarks: null,
                  discountRate: null,
                  estimateAmount: {
                    $type: '@float',
                    $dRange: [2, 2]
                  },
                  estimateDeliverDate: '@datetime',
                  estimateWeight: 2,
                  feeMoney: null,
                  fileHost: '@url',
                  goodsCount: 1,
                  goodsId: '@id',
                  goodsName: '@ctitle',
                  grossWeight: 2,
                  hostAttachUrl: '@image',
                  id: '@id',
                  netWeight: 2,
                  orderDeliverId: '@id',
                  orderId: '@id',
                  orderItemNo: '@id',
                  orderNo: '@id',
                  payableAmount: {
                    $type: '@float',
                    $dRange: [2, 2]
                  },
                  paymentAmount: {
                    $type: '@float',
                    $dRange: [2, 2]
                  },
                  realAmount: {
                    $type: '@float',
                    $dRange: [2, 2]
                  },
                  realCount: 1,
                  realUnitPrice: {
                    $type: '@float',
                    $dRange: [2, 2]
                  },
                  realWeight: 2,
                  sellerId: '@id',
                  sellerName: '@ctitle',
                  sellerType: {
                    $type: '@enum',
                    $value: ['BUSINESS', 'BUYER']
                  },
                  settlementType: {
                    $type: '@enum',
                    $value: ['STANDER', 'CATTY']
                  },
                  skuCode: '@id',
                  snapshotVersion: '@string',
                  specification: '@ctitle',
                  statementDate: '@datetime',
                  status: {
                    $type: '@enum',
                    $value: ['WAIT_CONFIRM', 'SORTED', 'WAIT_TAKE_DELIVERY', 'CANCEL', 'COMPLETE']
                  },
                  supplierId: null,
                  unit: {
                    $type: '@enum',
                    $value: ['PIECE', 'BOX', 'BAG', 'CATTY', 'SINGLE', 'BUNCH', 'BOX_CASE', 'BATCH', 'BRANCH']
                  },
                  unitPriceCatty: {
                    $type: '@float',
                    $dRange: [2, 2]
                  }
                }]
              }
            }]
          },
        },
        errorCode: null,
        errorMsg: null,
        status: 'SUCCESS'
      }
    },
    {
      context: '/web/ep/suppliers',
      target: 'https://dev.biaoguoworks.com/demeter/api',
      changeOrigin: true,
      pathRewrite: {
        '/web/ep/suppliers': '/api/web/ep/suppliers'
      }
    },
    {
      context: '/web/chain/order/list',
      target: 'https://dev.biaoguoworks.com/demeter/api',
      changeOrigin: true,
      secure: false
    },
    {
      context: [
        '/comm',
        '/web',
        '/data',
        '/h5'],
      target: 'https://dev.biaoguoworks.com/demeter/api',
      changeOrigin: true,
      secure: false
    },
    {
      context: '/web/ep',
      target: 'https://dev.biaoguoworks.com/demeter/api',
      changeOrigin: true,
      pathRewrite: {
      }
    }
  ]
}
