#!/usr/bin/env node
'use strict';

const fs = require('fs');
const path = require('path');
const { Command } = require('commander');
const express = require('express');
const cors = require('cors');
const { createProxyMiddleware } = require('http-proxy-middleware');
const mockGenerate = require('./mock-gen');

// commander命令
const program = new Command();
program
  .version('0.0.1')
  .option('-c, --config, <filePath>', 'the json/js file path of the proxy config file, default pwd() + proxyconfig.js')
  .parse(process.argv);

// 解析地址
function parsingRouter(configArr, app) {
  if (Array.isArray(configArr)) {
    configArr.forEach((proxyconfig) => {
      const { context, target, source = false, changeOrigin = false, pathRewrite, mock } = proxyconfig;
      if (mock) {
        let contextWrap = context;
        if (!Array.isArray(contextWrap)) {
          contextWrap = [contextWrap];
        }
        contextWrap.forEach((urlCtx) => {
          app.get(urlCtx, function(req, res) {
            res.send(mockGenerate(mock));
          });
          app.post(urlCtx, function(req, res) {
            res.send(mockGenerate(mock));
          })
        });
      } else {
        app.use(createProxyMiddleware(context, { target, source, changeOrigin, pathRewrite }));
      }
    });
  }
}

function getConfigContent() {
  const isJs = path.extname(program.config) === '.js';
  let content = isJs ? require(program.config) : JSON.parse(fs.readFileSync(program.config, { encoding: 'utf8' }));
  return content;
}

function main() {
  try {
    const app = express();
    const content = getConfigContent();
    app.use(cors())
    // setCrose(app);
    parsingRouter(content.proxy, app);
    app.listen(content.port || 3031);
  } catch(e) {
    console.error(e);
    const errMsg = '未找到代理配置文件或配置文件解析失败';
    console.log(errMsg);
  }
}

function setCrose(app) {
  //设置跨域访问
  app.all('*', function(req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "X-Requested-With,Content-Type");
    res.header("Access-Control-Allow-Methods", "PUT,POST,GET,DELETE,OPTIONS");
    res.header("Content-Type", "application/json;charset=utf-8");
    next();
  });
}

main();
