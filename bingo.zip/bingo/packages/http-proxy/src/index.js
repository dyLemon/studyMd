#!/usr/bin/env node
'use strict';

const fs = require('fs');
const path = require('path');
const { execFile } = require('child_process');
const { Command } = require('commander');
const pkg = require('../package.json');

let serverProcess;

// commander命令
const program = new Command();
program
  .version(pkg.version)
  .option('-c, --config, <filePath>', 'the json/js file path of the proxy config file, default pwd() + proxyconfig.js')
  .parse(process.argv);

const configPath = path.join(process.cwd(), program.config || '.proxyconfig');

function proxyServerStart() {
  return execFile('node', [`${__dirname}/http-proxy.js`, '--config', configPath], {
    cwd: __dirname,
    stdio: 'inherit',
    shell: process.platform === 'win32', // win兼容
  }, (error, stdout, stderr) => {
    stderr && console.log(stderr);
    stdout && console.log(stdout);
  });
}

function serverStart() {
  serverProcess && serverProcess.kill();
  serverProcess = proxyServerStart();
  serverProcess.stdout.on('data', (data) => {
    console.log(data);
  });
}

serverStart();
console.log('代理服务已启动');

fs.watch(configPath, () => {
  serverStart();
  console.log('代理服务已重启');
});
