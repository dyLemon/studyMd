#!/usr/bin/env node
'use strict';
const Mockjs = require('mockjs');
const allTypes = require('./utils/type');
const injectRandomExtend = require('./utils/mock-random-extend');
const Random = Mockjs.Random;
const numberType = [allTypes.INTEGER, allTypes.FLOAT, allTypes.NATURAL];

const stringCall = (target) => Object.prototype.toString.call(target);

const isArrayType = (type) => {
  const arrayType = ['array', '@array'];
  return arrayType.includes(type) || stringCall([]) === stringCall(type);
};

const isObjectType = (type) => {
  const objectType = ['object', '@object'];
  return objectType.includes(type) || stringCall({}) === stringCall(type);
};

injectRandomExtend(Random);

const NUMBER_RANGE = [-1e10, 1e10]; // 默认整数范围
const DOT_RANGE = [1, 10]; // 默认小数位数

module.exports = function mockGenerate(mock) {
  const mockObj = {};
  compriseMock(mock, mockObj);
  return Mockjs.mock(mockObj);
}

// 组合mock
function compriseMock(mockData, barrel) {
  Object.entries(mockData.$value || mockData).forEach(([mockKey, mockVal]) => {
    if (mockVal === null) {
      return barrel[mockKey] = null;
    }
    const { $type } = mockVal || '';
    // 非对象 / 非配置数组 / 非配置对象
    if ((!$type && typeof mockVal !== 'object') || ($type && !isArrayType($type) && !isObjectType($type))) {
      barrel[compriseKey(mockKey, mockVal)] = compriseValue(mockVal);
    } else {
      const realKey = compriseKey(mockKey, mockVal);
      let valueType;

      // 顺序不要换
      (isObjectType($type) || isObjectType(mockVal)) && (valueType = {}); // 对象类型
      (isArrayType($type) || isArrayType(mockVal)) && (valueType = []); // 数组类型
    
      barrel[realKey] = valueType;

      compriseMock(mockVal.$value || mockVal, barrel[realKey]);
    }
  })
}

// 组装键值
function compriseKey(key, options) {
  const { $type, $range, $dRange } = options || {};
  const lowType = String($type).toLowerCase();
  const randomType = lowType.substring(1);

  let range;
  let dRange;
  let nextStr = '';

  if (lowType === 'number' || numberType.includes(randomType)) {
    range = isArrayType($range) ? $range : NUMBER_RANGE;
    dRange = isArrayType($dRange)
      ? $dRange
      : lowType === allTypes.FLOAT
        ? DOT_RANGE
        : [];

    range && range.length && (nextStr += range.join('-'));  
    dRange && dRange.length && (nextStr += `.${dRange.join('-')}`);
  } else {
    isArrayType($range) && (nextStr += $range.join('-'));  
  }

  nextStr && (nextStr = `|${nextStr}`);

  return `${key}${nextStr}`;
}

// 组装值
function compriseValue(options) {
  let type;
  let value;

  if (!isObjectType(options)) {
    value = options;
  } else {
    type = options.$type;
    value = options.$value;
  }

  const isRandomType = String(type).includes('@');
  const randomType = isRandomType ? type.substring(1) : '';

  if (isRandomType && Object.values(allTypes).includes(randomType)) {
    return Random[randomType](value);
  }

  return value;
}
