const allType = require('./type');

module.exports = function inject(random) {
  random.extend({
    [allType.ENUM](data) {
      return function() {
        if (Array.isArray(data)) {
          return data[Math.floor(Math.random() * data.length)];
        }
        return data;
      }
    }
  })
}
