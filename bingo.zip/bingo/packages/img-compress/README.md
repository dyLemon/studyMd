# `img-compress`

> TODO: description

## Usage

```
const imgCompress = require('img-compress');

// TODO: DEMONSTRATE API
```
