import 'jest-canvas-mock';
import { imgCompress } from '../src';

let imgFile = null;
const defaultSettingCompress = imgCompress();
const base64SettingCompress = imgCompress({ returnType: 'base64' });

beforeAll(async () => {
  // jest.setTimeout(30000);
  const res = await axios.get('https://ugc-dev.biaoguoworks.com/watermelon/1618073399341/1616054886201.jpg');
  imgFile = new Blob([res.data], { type: 'image/jpg' });
  window.URL.createObjectURL = jest.fn(() => imgFile);
  window.URL.revokeObjectURL = jest.fn();

  // 改变 img 的实现，使其可以执行 onload
  global.Image = class extends global.Image {
    constructor() {
      super();
      setTimeout(() => {
        this.onload();
      }, 100);
    }
  };
})

describe('imgCompress can use', () => {
  
  it('imgCompress is a function', () => {
    expect(typeof imgCompress).toBe('function');
  })

  it('should imgCompress function return a function', () => {
    const result = imgCompress();
    expect(result).toBeTruthy();
  })

  it('should return a blob object', async () => {
    const data = await defaultSettingCompress(imgFile);

    expect(data).toBeInstanceOf(Blob);
    expect(data.type).toEqual('image/jpeg');
  })

  it('should return a base64 string', async () => {
    const data = await base64SettingCompress(imgFile);

    expect(typeof data).toBe('string');
    expect(data.indexOf('base64')).toBeGreaterThanOrEqual(0);
  })

  it('should multiply return when more then one images', async () => {
    const data = await defaultSettingCompress([imgFile, imgFile]);
    expect(data.length).toEqual(2);
  })
})

describe('when img param is not right', () => {

  it('should return err remind when not image param', async () => {
    try {
      await defaultSettingCompress();
    } catch(e) {
      expect(e.name).toBe('emptyErr');
      expect(e.content).toBe('没有任何图片'); 
    }
  })
  
  it('should return err remind when it is not image type', async () => {
    try {
      await defaultSettingCompress({});
    } catch(e) {
      expect(e.name).toBe('typeErr');
      expect(e.content).toBe('图片类型无效'); 
    }
  })

  it('should return err remind when image over config max size', async () => {
    try {
      await defaultSettingCompress(new Blob(['abcdefg'.repeat(10000)], { type: 'image/jpeg' }));
    } catch(e) {
      expect(e.name).toBe('maxSizeErr');
      expect(e.content).toBe('图片超过最大尺寸'); 
    }
  })
})
