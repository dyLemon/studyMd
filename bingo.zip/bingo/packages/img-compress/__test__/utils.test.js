import { categoreyIdentify, overSize, errorMsg } from '../src/utils';

describe('file export is right type', () => {
  it('export function type', () => {
    expect(typeof categoreyIdentify).toBe('function');
    expect(typeof overSize).toBe('function');
    expect(typeof errorMsg).toBe('function');
  })
});

describe('export functions can use', () => {
  it('categoreyIdentify can return right string', () => {
    const isArray = categoreyIdentify([], 'array');
    const isObject = categoreyIdentify({}, 'object');
    const isString = categoreyIdentify('', 'string');

    const maybeArray = categoreyIdentify([], 'object');

    expect(isArray).toBeTruthy();
    expect(isObject).toBeTruthy();
    expect(isString).toBeTruthy();
    expect(maybeArray).toBeFalsy();
  })

  it('overSize can return right value', () => {
    const over = overSize(10, 9);
    const notOver = overSize(1, 10);

    expect(over).toBeTruthy();
    expect(notOver).toBeFalsy();
  })

  it('errorMsg can return right object', () => {
    const errTitle = '这个错误';
    const errContent = '是什么是什么';
    const errMsg = errorMsg(errTitle, errContent);
    
    expect(errMsg.name).toBe(errTitle);
    expect(errMsg.content).toBe(errContent);
  })
});