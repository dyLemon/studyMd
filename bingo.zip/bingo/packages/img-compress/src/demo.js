import React, { useState } from 'react';
import { imgCompress } from './index';

export default function ImgCompressDemo() {
  const [imgs, setImgs] = useState([]);
  const [originImgs, setOriginImgs] = useState([]);

  const compress = (e) => {
    const files = [...e.target.files];
    if (files.length) {
      setOriginImgs(files);
      imgCompress()(files)
        .then(res => {
          setImgs(res);
        });
    }
  };

  const errDemo = () => {
    imgCompress()([1, 23, 32])
      .catch(err => {
        alert(`${err.name} - ${err.content}`);
      });
  }

  return (
    <>
      <button onClick={errDemo}>错误捕获</button>
      <input
        multiple
        type="file"
        onChange={compress}
      />
      {
        imgs.map((img, index) => {
          const originSize = originImgs[index] ? originImgs[index].size : 0;
          const compressSize = img.size;
          return (
            <div>
              <img src={window.URL.createObjectURL(img)} />
              <p>原图：{(originSize / 1024).toFixed(2)}kb</p>
              <p>压缩后：{(compressSize / 1024).toFixed(2)}kb</p>
              <p>压缩比：{((originSize - compressSize) / originSize).toFixed(2)}</p>
            </div>
          )
        })
      }
    </>
  )
}
