import EXIF from 'exif-js';
import { overSize, categoreyIdentify, errorMsg } from './utils';

const TYPE = {
  base64: 'base64',
  blob: 'blob',
  file: 'file',
};
const JPG_MIMETYPE = 'image/jpeg';
const DEFAULT_CONFIG = {
  maxWidth: 1080,
  maxHeight: 1080,
  quality: .7,
  maxSize: 10 * 1024 * 1024,
  iosRotateFix: false,
  returnType: TYPE.blob
};

// 获取图片方向
function getImgOrientation(file) {
  return new Promise((resolve, reject) => {
    EXIF.getData(file, () => {
      resolve(EXIF.getTag(file, "Orientation"));
    });
  });
}

function canvasCompress(imgArr, config, result = []) {
  return new Promise(async (resolve, reject) => {
    if (!imgArr.length) {
      return resolve(result);
    }
    const target = imgArr.shift();
    const canvas = document.createElement('canvas');
    const context = canvas.getContext('2d');
    const img = new Image();
    // 获取图片旋转方向
    const ori = await getImgOrientation(target);

    img.src = window.URL.createObjectURL(target);
    img.onload = () => {
      const { width, height } = img;
      const whRelative = width / height;
      let degree = 0;
      let drawWidth = width;
      let drawHeight = height;
      // 宽 >= 高，宽度超标
      if (whRelative >= 1 && width > config.maxWidth) {
        drawWidth = config.maxHeight;
        drawHeight = drawWidth / whRelative;
      }
      // 宽 < 高，高度超标
      if (whRelative < 1 && height > config.maxHeight) {
        drawHeight = config.maxHeight;
        drawWidth = drawHeight * whRelative;
      }
      canvas.width = drawWidth;
      canvas.height = drawHeight;
      
      // 解决ios拍摄角度问题
      if (config.iosRotateFix) {
        switch(ori) {
          case 3:
            degree = 180;
            drawWidth = -1 * drawWidth;
            drawHeight = -1 * drawHeight;
            break;
          case 6:
            degree = 90;
            canvas.width = drawHeight;
            canvas.height = drawWidth;
            drawHeight = -1 * drawHeight;
            break;
          case 8:
            degree = 270;
            canvas.width = drawHeight;
            canvas.height = drawWidth;
            drawWidth = -1 * drawWidth;
            break;
          default:
        }
      }
      
      // 填充白底
      context.fillStyle = "#fff";
      context.rotate(degree * Math.PI / 180);
      context.fillRect(0, 0, drawWidth, drawHeight);
      context.drawImage(img, 0, 0, width, height, 0, 0, drawWidth, drawHeight);

      // 导出blob
      if (config.returnType === TYPE.blob) {
        canvas.toBlob((blob) => {
          window.URL.revokeObjectURL(target);
          resolve(canvasCompress(imgArr, config, [...result, blob]));
        }, JPG_MIMETYPE, config.quality);
      }
      // 导出base64
      if (config.returnType === TYPE.base64) {
        const imgBase64 = canvas.toDataURL(JPG_MIMETYPE, config.quality);
        window.URL.revokeObjectURL(target);
        resolve(canvasCompress(imgArr, config, [...result, imgBase64]));
      }
    }
  });
}

function compress(targets, config) {
  const isArrayTargets = categoreyIdentify(targets, 'filelist') || categoreyIdentify(targets, 'array');
  return new Promise(async (resolve, reject) => {
    if (!targets) {
      return reject(errorMsg('emptyErr', '没有任何图片'));
    }
    let useImgs = [];
    if (isArrayTargets) {
      useImgs = [...targets];
    } else {
      useImgs = [targets];
    }
    for (let img of useImgs) {
      if (!categoreyIdentify(img, TYPE.file) && !categoreyIdentify(img, TYPE.blob)) {
        return reject(errorMsg('typeErr', '图片类型无效'));
      }
      if (overSize(img.size, config.maxSize)) {
        return reject(errorMsg('maxSizeErr', '图片超过最大尺寸'));
      }
    }
    const result = await canvasCompress(useImgs, config);
    resolve(isArrayTargets ? result : result[0]);
  });
}

export function imgCompress(params) {
  const finConfig = { ...DEFAULT_CONFIG, ...params };
  return (targets) => compress(targets, finConfig);
}
