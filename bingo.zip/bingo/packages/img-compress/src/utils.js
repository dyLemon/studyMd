export function categoreyIdentify(type, targetType) {
  const typeStr = Object.prototype.toString.call(type);
  return typeStr.substring(8, typeStr.length - 1).toLowerCase() === targetType;
}

export function overSize(size, maxSize) {
  return size > maxSize;
}

export function errorMsg(name, content) {
  return { name, content };
};
