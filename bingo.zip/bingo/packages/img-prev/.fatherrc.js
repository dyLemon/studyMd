import base from '../../build.base';
export default base;
