# `img-prev`

> TODO: description

## Usage

```
const imgPrev = require('img-prev');

// TODO: DEMONSTRATE API
```
