import { shallow, mount } from 'enzyme'
import ImgsPreview from '../src'

describe('component should render success', () => {

  it('should have "div" node when render success', () => {
    const dom = mount(<ImgsPreview />)
    expect(dom.find('div')).toHaveLength(1);
  })  
})

describe('component should render img preview module', () => {
  let dom = null;

  beforeEach(() => {
    dom = mount(
      <ImgsPreview>
        <div>
          <img src="https://ugc-dev.biaoguoworks.com/watermelon/1618073399341/1616054886201.jpg" />
          <p>123</p>
          <img src="https://ugc-dev.biaoguoworks.com/watermelon/1618073399341/1616054886201.jpg" />
          <p>123</p>
          <img src="https://ugc-dev.biaoguoworks.com/watermelon/1618073399341/1616054886201.jpg" />
        </div>
      </ImgsPreview>
    );
  })

  it('should preview img when click img dom', (done) => {
    expect(dom.state('imgs')).toHaveLength(3);
    // 模拟点击
    dom.state('imgs')[2].click();
    expect(dom.state('index')).toEqual(2);
    expect(dom.state('previewOpen')).toEqual('open');
    dom.update();
    expect(dom.find('.bingo-closed')).toHaveLength(1);
    dom.find('.bingo-closed').invoke('onClick')({ target: 1, currentTarget: 1 });
    setTimeout(() => {
      dom.update();
      expect(dom.find('.bingo-closed')).toHaveLength(0);
      done();
    }, 500);
  })

  it('should preview img controller can use', (done) => {
    dom.state('imgs')[0].click();
    dom.update();
    expect(dom.find('.bingo-closed')).toHaveLength(1);
    // 左右切换
    dom.find('.bingo-right-arrow').invoke('onClick')();
    expect(dom.state('index')).toEqual(1);
    dom.find('.bingo-left-arrow').invoke('onClick')();
    dom.find('.bingo-left-arrow').invoke('onClick')();
    expect(dom.state('index')).toEqual(0);
    // 放大缩小
    dom.find('.bingo-minus').invoke('onClick')();
    expect(dom.state('mouseWheelValue')).toEqual(-100)
    dom.find('.bingo-add').invoke('onClick')();
    dom.find('.bingo-add').invoke('onClick')();
    expect(dom.state('mouseWheelValue')).toEqual(100);
    // 左右旋转
    dom.find('.bingo-refresh').invoke('onClick')();
    setTimeout(() => {
      expect(dom.state('imgRotate')).toEqual(90);
      done();
    }, 500);
  })

  it('should control by keybord', (done) => {
    dom.state('imgs')[0].click();
    // 键盘切图
    const event37 = new KeyboardEvent('keydown', { keyCode: 37 }); // 右
    const event39 = new KeyboardEvent('keydown', { keyCode: 39 }); // 左
    const event38 = new KeyboardEvent('keydown', { keyCode: 38 }); // 上
    const event40 = new KeyboardEvent('keydown', { keyCode: 40 }); // 下
    const event32 = new KeyboardEvent('keydown', { keyCode: 32 }); // 空
    const event27 = new KeyboardEvent('keydown', { keyCode: 27 }); // esc

    document.dispatchEvent(event39);
    expect(dom.state('index')).toEqual(1);
    document.dispatchEvent(event37);
    expect(dom.state('index')).toEqual(0);
    document.dispatchEvent(event38);
    expect(dom.state('mouseWheelValue')).toEqual(100);
    document.dispatchEvent(event40);
    expect(dom.state('mouseWheelValue')).toEqual(0);
    document.dispatchEvent(event32);
    document.dispatchEvent(event32); // 覆盖连续旋转 if 判断
    document.dispatchEvent(event27);
    setTimeout(() => {
      expect(dom.state('imgRotate')).toEqual(90);
      dom.update();
      expect(dom.find('.bingo-closed')).toHaveLength(0);
      done();
    }, 500);
  })
})
