const glob = require('glob');
const { preserveShebangs } = require('rollup-plugin-preserve-shebangs');
const files = glob.sync('./src/**/*.js');
const outputFiles = {};

files.forEach((file) => {
  outputFiles[file] = {
    file: file.replace(/\/src|\.js/g, ''),
  };
});

module.exports = {
  target: 'node',
  entry: files,
  overridesByEntry: outputFiles,
  // 使用rollup打包成commonjs标准模块输出
  cjs: {
    type: 'rollup',
    minify: true,
  },
  umd: false,
  esm: false,
  extraRollupPlugins: [
    preserveShebangs(),
  ],
};
