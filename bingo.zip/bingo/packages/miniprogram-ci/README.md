# `miniprogram-ci`

> TODO: description

## Usage

```
const miniprogramCi = require('miniprogram-ci');

// TODO: DEMONSTRATE API
```
