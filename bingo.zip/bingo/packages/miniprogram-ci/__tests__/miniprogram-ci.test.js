'use strict';

const miniprogramCi = require('..');

describe('miniprogram-ci', () => {
    it('needs tests');
});
