const { Command } = require('commander');
const wx = require('./utils/wx');
const fsRbt  = require('./utils/fs-rbt');
const { loginQrCodeName, imgKeyFileName } = require('./utils/fields');

const program = new Command();
program.parse(process.argv);

(async function() {
  const page = await wx.wxPageOpen();
  const [access, password] = program.args;
  if (!access || !password) {
    console.log('请输入账号密码');
    process.exit(1);
  }
  try {
    const loginSuccess = await wx.wxLogin(page, access, password);
    const key = await fsRbt.sendQrCode(loginQrCodeName);
    await fsRbt.saveImgKeyFile(imgKeyFileName, key);
    await loginSuccess();
    await wx.wxPostAudit(page);
    await wx.wxPageClose(page);
    process.exit(0);
  } catch(e) {
    console.log(e);
    process.exit(1);
  }
})();
