#!/usr/bin/env node
const { Command } = require('commander');

const program = new Command();

program
  .command('upload', '小程序上传', { isDefault: true, executableFile: 'upload' })
  .command('recall <account> <password>', '撤销审核', { executableFile: 'recall' })
  .command('audit <account> <password>', '提交审核', { executableFile: 'audit' })
  .command('release <account> <password>', '发布上线', { executableFile: 'release' })
  .parse(process.argv);
