const { Command } = require('commander');
const { getRegisterMiniProgram, projectUpload, previewUpload, exitWithError, getPreivewRobotNum, getSourceMap } = require('./utils');
const robot = require('./utils/robot');

const defaultSetting = {
  minify: true,
};

const program = new Command();

program
  .option('-t --type <type>', '发布模式，preview(预览)，experience(体验)，release(发布)')
  .option('-s --source <source>', '小程序项目路径')
  .option('-k --keyPath <keyPath>', '小程序上传私钥地址')
  .option('-n --numVersion <version>', '小程序版本号')
  .option('-d --desc [desc]', '预览/上传描述')
  .option('--robotUrl [robotUrl]', '预览发布机器人号url')
  .option('--sourceMapPath [sourceMapPath]', '小程序sourceMap生成地址')
  .parse(process.argv);

(async function() {
  const options = program.opts();
  const robotType = robot[options.type];
  if (Number.isNaN(robotType)) {
    return console.log('小程序发布模式参数错误，运行 --help 可看到 type 枚举')
  }
  const project = getRegisterMiniProgram(options.source, options.keyPath);
  const isRelease = robotType === 1;

  console.log('文件上传中...\n'.green);

  switch (robotType) {
    case 1:
    case 2:
      try {
        await projectUpload({
          project,
          desc: isRelease ? '线上发布版本  ' : '体验发布  ' + (options.desc || ''), // 此备注将显示在“小程序助手”开发版列表中
          version: options.numVersion,
          robot: robotType,
          setting: {
            ...defaultSetting,
          },
        });
        options.sourceMapPath && isRelease && await getSourceMap(project, robotType, options.sourceMapPath);
      } catch(e) {
        console.log('上传失败'.red, e);
        exitWithError();
      }
      break;
    case 3:
      try {
        const robotNum = await getPreivewRobotNum(options.robotUrl);
        await previewUpload({
          project,
          desc: options.desc, // 此备注将显示在“小程序助手”开发版列表中
          robot: robotNum,
          setting: {
            ...defaultSetting,
          },
          // onProgressUpdate: console.log,
        });
      } catch(e) {
        console.log('预览上传失败'.red, e);
        exitWithError();
      }
      break;
    default:
  }

  console.log('上传成功，请在小程序开发助手查看\n'.green);

  process.exit(0);
})();
