exports.loginQrCodeName = 'wxlogin.png';
exports.releaseQrCodeName = 'wxrelease.png';
exports.imgKeyFileName = 'key';