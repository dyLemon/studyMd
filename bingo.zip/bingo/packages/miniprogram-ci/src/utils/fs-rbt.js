const https = require('https');
const fs = require('fs');
const FormData = require('form-data');

const appId = 'cli_a1fcfa6baa385013';
const secret = 'j6GKpR4HLMsohPVX4VHD7Ncd8SNMnG2p';

function getFSAccess() {
  return new Promise((resolve, reject) => {
    const req = https.request('https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal', {
      headers: {
        'Content-Type': 'application/json; charset=utf-8'
      },
      method: 'POST',
    }, (res) => {
      res.on('data', (chunk) => {
        const jsonStr = Buffer.from(chunk).toString();
        const data = JSON.parse(jsonStr);
        if (data.code !== 0) {
          return reject(data.msg);
        }
        return resolve(data.tenant_access_token);
      });
    });
    const body = { app_id: appId, app_secret: secret };
    req.write(JSON.stringify(body));
    req.end();
  })
}

exports.sendQrCode = function(qrPath) {
  return new Promise(async (resolve, reject) => {
    const token = await getFSAccess();
    const boundary = '----WebKitFormBoundary7MA4YWxkTrZu0gW';
    const req = https.request('https://open.feishu.cn/open-apis/im/v1/images', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': `multipart/form-data; boundary=${boundary}`
      }
    }, (res) => {
      res.on('data', (chunk) => {
        const jsonStr = Buffer.from(chunk);
        const data = JSON.parse(jsonStr);
        if (data.code !== 0) {
          return reject(data.msg);
        }
        return resolve(data.data.image_key);
      })
    });
    const formData = new FormData();
    formData.setBoundary(boundary);
    formData.append('image_type', 'message');
    formData.setBoundary(boundary);
    formData.append('image', fs.readFileSync(qrPath));
    formData.setBoundary(boundary);
    req.write(formData.getBuffer());
    req.end();
  })
}

exports.saveImgKeyFile = function(fileName, fileContent) {
  fs.writeFileSync(fileName, fileContent);
}
