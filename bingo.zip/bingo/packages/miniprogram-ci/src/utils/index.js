const http = require('http')
const path = require('path');
const colors = require('colors');
const ci = require('miniprogram-ci');
const robot = require('./robot');

const configFileName = 'project.config.json';

function exitWithError() {
  process.exit(1);
}

exports.getRegisterMiniProgram = function(filePath, keyGenPath) {
  try {
    const configFile = require(path.resolve(filePath, configFileName));
    const keyPath = path.resolve(keyGenPath);
    const { appid } = configFile;
    return new ci.Project({
      appid,
      type: 'miniProgram', // 暂时写死，目前没有小程序插件开发等需求
      projectPath: filePath,
      privateKeyPath: keyPath,
    })
  } catch(e) {
    console.log(`无法找到 ${configFileName} 或 key文件，请确认配置路径是否正确`.red, e);
    exitWithError();
  }
}

exports.projectUpload = function(config) {
  return ci.upload(config);
}

exports.previewUpload = function(config) {
  return ci.preview(config);
}

exports.getPreivewRobotNum = function(url) {
  if (!url) {
    return robot.preview;
  }
  const urlObj = new URL(url);
  const auth = [urlObj.username, urlObj.password].filter(value => !!value);
  return new Promise((resolve, reject) => {
    const request = http.request({
      hostname: urlObj.hostname,
      port: urlObj.port,
      path: urlObj.pathname,
      method: 'GET',
      auth: auth.join(':'),
    }, (res) => {
      res.on('data', chunk => {
        const serviceNum = chunk.toString();
        resolve((serviceNum % 28) + robot.preview);
      })
    });
    
    request.end();

    request.on('error', (err) => {
      console.log(err);
      resolve(robot.preview);
    });
  });
}

exports.getSourceMap = function(project, robot, savePath) {
  return ci.getDevSourceMap({
    project,
    robot,
    sourceMapSavePath: savePath
  });
}

exports.exitWithError = exitWithError;
