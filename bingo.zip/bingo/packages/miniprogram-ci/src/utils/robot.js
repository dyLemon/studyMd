// 机器人编号

module.exports = {
  preview: 3,       // 预览用
  experience: 2,    // 体验用
  release: 1,       // 发布用
};
