const os = require('os');
const puppeteer = require('puppeteer');
const { loginQrCodeName, releaseQrCodeName } = require('./fields');

const RELEASE_USER = 'ci机器人1';
const versionReg = /\d+.\d+.\d+/;

async function wxPageOpen(debug = false) {
  const isLinuxEnv = os.type() === 'Linux';
  const browser = await puppeteer.launch({
    headless: !debug,
    args: isLinuxEnv ? ['--no-sandbox'] : []
  });
  const page = await browser.newPage();
  await page.goto('https://mp.weixin.qq.com');
  return page;
}

async function wxPageClose(page) {
  await page.browser().close();
}

async function wxLogin(page, access, password) {
  await page.click('a[class=login__type__container__select-type]');
  await page.type('input[name=account]', access, { delay: (Math.random * 10) + 1000 });
  await page.type('input[name=password]', password, { delay: (Math.random * 10) + 1000 });
  await page.click('a[class=btn_login]');
  await page.waitForSelector('.js_qrcode', {}).then(async (e) => {
    return new Promise((resolve, reject) => {
      setTimeout(async () => {
        const clientRect = await page.$$eval('.js_qrcode', img => {
          const rect = img[0].getBoundingClientRect();
          return {
            x: rect.x,
            y: rect.y,
            width: rect.width,
            height: rect.height,
          };
        });
        await page.screenshot({
          clip: {
            x: clientRect.x,
            y: clientRect.y,
            width: clientRect.width,
            height: clientRect.height,
          },
          path: loginQrCodeName,
        });
        resolve();
      }, 2000)
    })
  });
  const isLoginSuccess = async () => {
    return await page.waitForNavigation({ waitUntil: 'networkidle0', timeout: 60 * 5 * 1000  });
  }
  return isLoginSuccess;
}

async function wxTurnAuditPage(page) {
  await page.click('a[href^="/wxamp/wacodepage/getcodepage"]');
  await page.waitForNavigation({ waitUntil: 'networkidle0' });
}

async function wxGetAuditVersion(page) {
  await wxTurnAuditPage(page);
  const auditVersion = await page.$eval('.code_version_test .simple_preview_value', (el) => el ? el.textContent : null);
  return auditVersion;
}

async function wxGetReleseVersion(page) {
  await wxTurnAuditPage(page);
  const devEles = await page.$$('.code_version_dev .code_version_log');
  for ( const handleEle of devEles ) {
    const user = await handleEle.$eval('.code_version_log_bd .simple_preview_value', (el) => el.textContent);
    if (user === RELEASE_USER) {
      const versionStr = await handleEle.$eval('.code_version_log_hd .simple_preview_value', (el) => el.textContent);
      const releseVersion = versionStr.match(versionReg);
      if (releseVersion) {
        return releseVersion[0];
      }
      return null;
    }
  }
  return null;
}

async function wxGetOnlineVersion(page) {
  await wxTurnAuditPage(page);
  const onlineVersion = await page.$eval('.code_version_online .simple_preview_value', (el) => el ? el.textContent : null);
  return onlineVersion;
}

async function wxGetReleseEle(page) {
  await wxTurnAuditPage(page);
  const devEles = await page.$$('.code_version_dev .code_version_log');
  for (const handleEl of devEles) {
    const user = await handleEl.$eval('.code_version_log_bd .simple_preview_value', (el) => el.textContent)
    if (user === RELEASE_USER) {
      return handleEl;
    }
  }
  return null;
}

async function wxGetAuditEle(page) {
  await wxTurnAuditPage(page);
  const auditVersionEle = await page.$('.code_version_test');
  return auditVersionEle;
}

async function throughRemindModal(page, clickCancel = false, times = 100) {
  if (times <= 0) {
    return Promise.resolve();
  }
  try {
    const btnSelectClassName = clickCancel ? '.weui-desktop-btn_default' : '.weui-desktop-btn_primary'
    const modalEle = await page.waitForSelector('div.weui-desktop-dialog__wrp.self-weui-modal:not([style*="display: none;"])', { visible: true, timeout: 5000 });
    const selectEle = await modalEle.$('.weui-desktop-dialog .weui-desktop-form__check-label');
    selectEle && await selectEle.click()
    const nextBtnEle = await modalEle.$(`.weui-desktop-dialog ${btnSelectClassName}`);
    nextBtnEle && await nextBtnEle.click();
    await page.waitFor(2000);
    return await throughRemindModal(page, clickCancel, times - 1);
  } catch(e) {
    return Promise.resolve();
  }
}

async function wxPostAudit(page) {
  return new Promise(async (resolve, reject) => {
    const releaseVersion = await wxGetReleseVersion(page);
    const onlineVersion = await wxGetOnlineVersion(page);

    if (!releaseVersion) {
      reject('没有找到发布版本，请重试或检查脚本');
    }
    if (onlineVersion) {
      const onlineNum = onlineVersion.split('.').reduce((cur, next) => `${cur}${Number(next)}`, '');
      const releaseNum = releaseVersion.split('.').reduce((cur, next) => `${cur}${Number(next)}`, '');
      if (releaseNum <= onlineNum) {
        reject('提审版本号错误，不能小于等于线上版号');
      }
    }
    const releaseEle = await wxGetReleseEle(page);
    if (releaseEle) {
      const auditBtn = await releaseEle.$('button');
      auditBtn.click({ delay: 200 });
      page.browser().once('targetcreated', async (target) => {
        const targetPage = await target.page();
        const auditBtnEle = await targetPage.waitForSelector('.btn.btn_primary');
        await auditBtnEle.click();
        await targetPage.waitFor(2000);
        resolve();
      });
      throughRemindModal(page);
    } else {
      reject('未找到需要审核版本');
    }
  });
}

async function wxPostRelease(page) {
  const auditEle = await wxGetAuditEle(page);
  if (auditEle) {
    const submitBtn = await auditEle.$('button');
    await submitBtn.click();
    await throughRemindModal(page, false, 1);
    await page.$eval('img[class="weui-desktop-qrcheck__img"]', (img) => {
      const imgClone = img.cloneNode();
      imgClone.style.position = 'absolute';
      imgClone.style.left = 0;
      imgClone.style.top = 0;
      imgClone.style.zIndex = 999999;
      imgClone.id = 'bg-release-img';
      document.body.appendChild(imgClone);
    });
    await page.waitFor(1000);
    // const imgEle = await page.$(`#${canvas.id}`);
    await page.screenshot({
      clip: {
        x: 0,
        y: 0,
        width: 220,
        height: 220,
      },
      path: releaseQrCodeName,
    });
  } else {
    throw Error('未找到审核通过版本');
  }
}

async function wxPostRecall(page) {
  await wxTurnAuditPage();
  await page.click('.code_version_test .weui-desktop-dropdown__list-ele__text');
  await throughRemindModal(page, true);
}

exports.wxPageOpen = wxPageOpen;
exports.wxPageClose = wxPageClose;
exports.wxLogin = wxLogin;
exports.wxPostAudit = wxPostAudit;
exports.wxPostRelease = wxPostRelease;
exports.wxPostRecall = wxPostRecall;
