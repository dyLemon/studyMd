const path = require("path");
const cssnano = require("cssnano");
const rollupCopy = require("rollup-plugin-copy");

module.exports = {
  entry: "./src/index",
  // 使用rollup打包成ES6标准模块输出
  esm: {
    type: "rollup",
    importLibToEs: true,
    minify: false,
    file: "index.esm",
  },
  extraExternals: [
    "@tarojs/components",
    "@tarojs/taro",
    "@tarojs/react",
    "prop-types",
  ],
  // 使用rollup打包成commonjs标准模块输出
  // cjs: {
  //   type: "rollup",
  //   // minify: true,
  //   file: "index",
  // },
  umd: {
    minFile: false,
    file: "index.umd",
    globals: {
      react: "React",
      vue: "Vue",
      "@tarojs/components": "components",
      "@tarojs/taro": "Taro",
      "prop-types": "PropTypes",
      "lodash/isEqual": "isEqual",
    },
  },
  cssModules: {
    generateScopedName: "bingo__[name][hash:base64:5]",
    camelCase: true,
  },
  extraPostCSSPlugins: [
    cssnano(), // css压缩
  ],
  extraRollupPlugins: [
    rollupCopy({
      targets: [
        {
          src: path.resolve(__dirname, "src/style"),
          dest: path.resolve(__dirname, "dist"),
        },
      ],
    }),
  ],
  autoprefixer: {
    overrideBrowserslist: ["> 1%", "last 2 versions", "not ie <= 8"],
  },
};
