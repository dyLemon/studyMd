'use strict';

const pageScrollView = require('..');

describe('page-scroll-view', () => {
    it('needs tests');
});
