const path = require('path');
const { preserveShebangs } = require('rollup-plugin-preserve-shebangs');
const copyPlugin = require('rollup-plugin-copy');

module.exports = {
  target: 'node',
  
  entry: [
    './src/qc-menber.js',
    './src/qc-menber-fix.js',
    './src/qc-menber-init.js',
    './src/qc-menber-commit-check.js',
    './src/qc-menber-husky-init.js',
    './src/utils/index.js',
    './src/script/husky-install.js',
  ],
  overridesByEntry: {
    './src/utils/index.js': {
      file: 'utils/index'
    },
    './src/script/husky-install.js': {
      file: 'script/husky-install'
    }
  },
  // 使用rollup打包成commonjs标准模块输出
  cjs: {
    type: 'rollup',
    minify: true,
  },
  umd: false,
  esm: false,
  extraRollupPlugins: [
    preserveShebangs(),
  ],
};
