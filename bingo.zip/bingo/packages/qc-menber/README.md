# `qc-menber`

> 团队规范生成器（质检员）

## 使用

详见 [组件库](https://h5.biaoguoworks.com/frontend-doc/index.html) CLI -> qc-menber
