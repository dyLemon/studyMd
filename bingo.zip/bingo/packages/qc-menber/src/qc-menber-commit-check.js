const path = require('path');
const fs = require('fs');
const program = require('commander');
const validateCommitMsg = require('validate-commit-msg');

const commitCheck = function () {
  program
    .option(
      '--HUSKY_GIT_PARAMS [gitCommitPath]', 'git提交commit路径'
    )
    .parse(process.argv);
  // husky6.x获取方式 || husky4.x获取方式
  const commitPath = program.HUSKY_GIT_PARAMS || process.env.HUSKY_GIT_PARAMS;
  const gitPath = path.join(process.cwd(), commitPath);
  const commitMsg = fs.readFileSync(gitPath, 'utf-8');
  const result = validateCommitMsg(commitMsg);

  process.exit(Number(!result));
};

module.exports = commitCheck();
