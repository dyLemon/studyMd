const lintStaged = require('lint-staged');

const eslintFixAndCheck = async () => {
  try {
    const success = await lintStaged({
      allowEmpty: false,
      concurrent: true,
      configPath: './',
      config: {
        '*{.js,.jsx,.ts,.tsx,.vue}': 'eslint --fix',
      },
      cwd: process.cwd(),
      debug: false,
      maxArgLength: null,
      quiet: false,
      relative: false,
      shell: false,
      stash: true,
      verbose: false,
    });
    process.exit(Number(!success));
  } catch (e) {
    console.error('脚本运行错误: ', e);
    process.exit(1);
  }
};

eslintFixAndCheck();
