const ora = require('ora');
const emoji = require('node-emoji');
const chalk = require('chalk');
const { addPackages, execCmd } = require('./utils');

(async () => {
  await addPackages('husky');
  const spinner = ora(chalk.green('初始化 husky ...')).start();
  try {
    await execCmd('yarn husky install');
    spinner.text = chalk.green('husky 初始化完成');

    await execCmd('yarn husky set .husky/pre-commit "yarn qc-menber fix"');
    await execCmd('yarn husky set .husky/commit-msg "yarn qc-menber commit-check --HUSKY_GIT_PARAMS= && git add"');

    spinner.prefixText = emoji.get(':tada:');
    spinner.text = chalk.green(`
      默认 git hooks 注册完成，
      ${chalk.bgRed(chalk.white('由于限制，请手动在 .husky/commit-msg 文件 HUSKY_GIT_PARAMS= 后面添加 "$1"'))}
    `);
    spinner.stopAndPersist();
  } catch(e) {
    console.log(e);
    process.exit(1);
  }
})()
