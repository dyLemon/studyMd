const inquirer = require('inquirer');
const path = require('path');
const fs = require('fs');
const { spawn } = require('child_process');
const chalk = require('chalk');
const ora = require('ora');
const emoji = require('node-emoji');
const { addPackages } = require('./utils');

const ROOT_PATH = process.cwd();
const React = 'react';
const Vue = 'vue';
const Prettier = 'prettier';
const TS = 'typescript';
const Packages = {
  [React]: ['eslint-config-bingo-react'],
  [Vue]: ['eslint-config-bingo-vue'],
  [Prettier]: ['eslint-config-bingo-prettier'],
  [TS]: ['eslint-config-bingo-ts']
}


let eslintRulesObj = Object.create(null);
eslintRulesObj.parserOptions = {};
eslintRulesObj.extends = [];
eslintRulesObj.plugins = [];
eslintRulesObj.rules = {};
eslintRulesObj.settings = {};

let answer = {};

// 初始化eslint
const qcInit = function() {
  inquirer
    .prompt([
      {
        type: 'confirm',
        name: 'tsUse',
        default: 'n',
        message: `是否使用${TS}(vue项目暂不支持)`,
      },
      {
        type: 'rawlist',
        name: 'frameType',
        default: 'js',
        message: '选择你想要的eslint规则',
        choices: [React, Vue],
      },
      {
        type: 'confirm',
        name: 'usePrettier',
        default: 'y',
        message: '是否启用prettier',
      },
      {
        type: 'confirm',
        name: 'useHuskyCheck',
        default: 'y',
        message: '是否启用husky提交校验',
      }
    ])
    .then((res) => {
      answer = res;
      createRules();
    });
};

// 开始创建规则
const createRules = async function() {
  try {
    switch(answer.frameType) {
      case React:
        await createReactRule();
        break;
      case Vue:
        await createVueRule();
        break;
      default:
    }
  
    answer.tsUse && await createTsRule();
    answer.usePrettier && await createPrettierRule();
    answer.useHuskyCheck && await createHusky();
  
    writeEslintFile();
    process.exit(0);
  } catch(e) {
    console.log(chalk.bgRed('发生意外错误，请重试运行或联系 zhanghaoran@biaoguoworks.com'), e);
    process.exit(1);
  }
};

// ts配置
const createTsRule = async function() {
  await addPackages(Packages[TS]);
  eslintRulesObj.extends.push('bingo-ts');
}

// 创建react规则
const createReactRule = async function() {
  await addPackages(Packages[React]);
  eslintRulesObj.extends.push('bingo-react');
};

// 创建vue规则
const createVueRule = async function() {
  await addPackages(Packages[Vue]);
  eslintRulesObj.extends.push('bingo-vue');
};

// 创建prettier
const createPrettierRule = async function() {
  await addPackages(Packages[Prettier]);
  const requireFileName = `bingo-prettier/dist/${answer.frameType}`;
  eslintRulesObj.extends.push(requireFileName);
}

// 创建husky
const createHusky = function() {
  return new Promise((resolve, reject) => {
    const childSpawn = spawn('yarn', ['qc-menber', 'husky-init'], {
      cwd: process.cwd(),
      shell: process.platform === 'win32', // win兼容
      stdio: 'inherit',
    });
    childSpawn.on('error', (err) => {
      console.log(err)
      reject();
    });
    childSpawn.on('close', resolve);
  });
}

// 写入eslint文件
const writeEslintFile = function() {
  const spinner = ora('开始创建规则...').start();
  try {
    fs.writeFileSync(
      path.join(ROOT_PATH, '.eslintrc.js'),
      Buffer.from(`module.exports=${JSON.stringify(eslintRulesObj, null, 2)}`)
    );
    spinner.prefixText = emoji.get(':tada:');
    spinner.text = chalk.green('eslintrc 文件创建完毕');
  } catch (e) {
    console.log(e);
    spinner.prefixText = emoji.get(':x:');
    spinner.text = chalk.red('生成失败, 请从新运行命令');
  } finally {
    spinner.stopAndPersist();
  }
};

qcInit();
