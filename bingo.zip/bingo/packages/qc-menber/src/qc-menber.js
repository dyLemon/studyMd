#!/usr/bin/env node
'use strict';

const program = require('commander');
const pkg = require('../package.json');

// 主函数
async function main() {
  program
    .version(pkg.version)
    .command('init', '初始化eslint规则')
    .command('husky-init', '初始化husky钩子')
    .command('fix', '启用eslint修复并验证代码是否规范')
    .command('commit-check', 'commit规范检查')
    .parse(process.argv);
}

main();
