const path = require('path');
const { execSync } = require('child_process');
const chalk = require('chalk');

try {
  const pkj = require(path.join(process.cwd(), '../../..', 'package.json'));
  if (pkj.dependencies.husky || pkj.devDependencies.husky) {
    execSync('yarn husky install', {
      cwd: path.join(process.cwd(), '../../..'),
      shell: process.platform === 'win32',
      stdio: 'inherit',
    });
  }
} catch (e) {
  console.log(chalk.red('husy初始化失败，请手动运行 husky install'));
  throw new Error(e);
}
