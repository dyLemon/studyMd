const child_process = require('child_process');
const { promisify } = require('util');
const ora = require('ora');
const emoji = require('node-emoji');
const chalk = require('chalk');
const pkg = require('../../package.json');
const exec = promisify(child_process.exec);

const DEFAULT_EXEC_OPTIONS = {
  cwd: process.cwd(),
  shell: process.platform === 'win32', // win兼容
};

// cmd执行
function execCmd(cmd, options = {}) {
  return exec(cmd, { ...DEFAULT_EXEC_OPTIONS, ...options });
}

// 安装包
function addPackages(packageName) {
  const spinner = ora(chalk.green(`${packageName} 安装中...`));
  spinner.start();
  return execCmd(`yarn add ${packageName} -D --registry=${pkg.publishConfig.registry}`)
    .then(() => {
      spinner.prefixText = emoji.get(':white_check_mark:');
      spinner.text = chalk.green(`${packageName} 安装完成`);
      spinner.stopAndPersist();
    }, (e) => {
      spinner.prefixText = emoji.get(':x:');
      spinner.text = chalk.red('依赖安装失败，请重试');
      console.log(e);
    });
}

exports.execCmd = execCmd;
exports.addPackages = addPackages;
