# `no-repeat-btn`

> TODO: description

## Usage

```
const noRepeatBtn = require('no-repeat-btn');

// TODO: DEMONSTRATE API
```
