import { contentType, toFormUrlencoded, toFormData, toQueryString } from './utils';

const [[json], [form], [formData]] = contentType;

const formUrlencodeType = contentType.get(form);
const formDataType = contentType.get(formData);
const jsonType = contentType.get(json);

class Request {

  // 请求参数格式化，依据content-type
  static requestParamsFomrat = (type, data = {}) => {
    switch(type) {
      case formUrlencodeType:
        return toFormUrlencoded(data);
      case formDataType:
        return toFormData(data);
      default:
        return data;
    }
  }

  constructor(requestCore) {
    if (!(requestCore instanceof Function)) {
      throw Error('requestCore must be a function!');
    }
    // 核心请求方法
    this.requestCore = requestCore;
    // request中间件
    this.reqMiddleware = [];
    // response中间件
    this.resMiddleware = [];
    // 错误捕获中间件
    this.catchMiddleware = [];
    // 请求头
    this.requestHeaders = {
      Accept: '*/*',
      'content-type': jsonType,
    };
    // 正在发起请求的数量
    this.requestNumber = 0;
    // 是否暂停请求
    this.requestPause = Promise.resolve();
  }

  // 获取当前请求数量
  getRequestNum = () => {
    return this.requestNumber;
  };

  /**
   * 暂停请求
   * @param {Function} playCallback 继续请求回调函数，会向该函数传递resolve方法，执行resolve后请求结束暂停
   */
  setRequestPause = (playCallback) => {
    this.requestPause = new Promise((resolve) => {
      playCallback(resolve);
    });
  };

  /**
   * 添加request中间件
   * @param {Array[Function] | Function} 中间件
   * @param {Array} target 添加目标
   */
  middlewareAdd = (middlewareFunc, target) => {
    if (middlewareFunc instanceof Function) {
      target.push(middlewareFunc);
    } else if (middlewareFunc instanceof Array) {
      for (let i = 0; i < middlewareFunc.length; i++) {
        const middleware = middlewareFunc[i];
        if (middleware instanceof Function) {
          target.push(middleware);
        } else {
          throw Error('must be a array function');
        }
      }
    } else {
      throw Error('middleware must be a function or a array function');
    }
  };

  // 添加resquest中间件
  useRequestMiddleware = (middlewareFunc) => {
    this.middlewareAdd(middlewareFunc, this.reqMiddleware);
  };

  // 添加response中间件
  useResponseMiddleware = (middlewareFunc) => {
    this.middlewareAdd(middlewareFunc, this.resMiddleware);
  };

  // 添加错误捕获中间件
  useCatchMiddleware = (middlewareFunc) => {
    this.middlewareAdd(middlewareFunc, this.catchMiddleware);
  };

  /**
   * 设置公共headers
   * @param {Objects} headers
   */
  setRequestHeaders = (headers) => {
    this.requestHeaders = { ...this.requestHeaders, ...headers };
  };

  /**
   * 执行中间件
   */
  execRequestMiddleware = (middlewareArray, requestParams) => {
    const copyArray = [...middlewareArray];
    const middlewareDeal = (newRequestParams) => {
      return new Promise((resolve, reject) => {
        if (copyArray.length) {
          const currentMiddleware = copyArray.shift();
          const next = (nextRequestParams) =>
            resolve(middlewareDeal(nextRequestParams));
          if (currentMiddleware instanceof Function) {
            try {
              currentMiddleware(newRequestParams, next);
            } catch (e) {
              throw Error(
                `request middleware ${currentMiddleware.name} exec error, place check your middleware, ${e}`
              );
            }
          } else {
            resolve(newRequestParams);
          }
        } else {
          resolve(newRequestParams);
        }
      });
    };
    return middlewareDeal(requestParams);
  };

  /**
   * 主请求
   */
  request = async (requestParams, middleware, options) => {
    const hasOnceMiddleware = middleware instanceof Function;
    const realOptions = (hasOnceMiddleware ? options : middleware) || {};
    const {
      noUseRequestMiddleware,
      noUseResponseMiddleware,
      noUseCatchMiddleware,
      contentType: requestContentType,
    } = realOptions;

    this.requestNumber += 1;
    await this.requestPause;
    let newRequestParams = requestParams;
    newRequestParams.headers['content-type'] = contentType.get(requestContentType) || jsonType;

    if (!noUseRequestMiddleware) {
      newRequestParams = await this.execRequestMiddleware(this.reqMiddleware, requestParams);
    }

    if (hasOnceMiddleware) {
      newRequestParams = middleware(newRequestParams);
    }

    // 请求参数处理
    newRequestParams.data = Request.requestParamsFomrat(newRequestParams.headers['content-type'], newRequestParams.data || {});

    return this.requestCore(newRequestParams).then(
      async (res) => {
        this.requestNumber -= 1;
        let newResponse = res;

        if (!noUseResponseMiddleware) {
          newResponse = await this.execRequestMiddleware(this.resMiddleware, res);
        }

        return newResponse;
      },
      async (e) => {
        this.requestNumber -= 1;
        let err = e;

        if (!noUseCatchMiddleware) {
          err = await this.execRequestMiddleware(this.catchMiddleware, e);
        }
        // 抛出错误
        return Promise.reject(err);
      }
    );
  };

  /**
   * 请求模板
   * @param {String} url 请求地址
   * @param {String} method 请求方式
   * @param {Object} data 请求体参数
   * @param {Function} middleware 一次性中间件
   */
  requestTemplate = (url, method, data, middleware, options) => {
    return this.request(
      {
        url,
        method,
        data,
        headers: { ...this.requestHeaders },
      },
      middleware,
      options
    );
  };

  /**
   * get requset
   * @param {String} url 请求地址
   * @param {Object} dataParam 请求参数
   * @param {Function} middleware 一次性中间件
   * @param {Object} options 其他设置
   *  @param {Boolean} noUseRequestMiddleware // 禁止使用request中间件
   *  @param {Boolean} noUseRequestMiddleware // 禁止使用request中间件
   *  @param {Boolean} noUseRequestMiddleware // 禁止使用request中间件
   */
  get = (url, data = {}, middleware, options) => {
    const fullUrl = toQueryString(url, data);
    return this.requestTemplate(fullUrl, 'GET', {}, middleware, options);
  };

  /**
   * post requset
   * @param {String} url 请求地址
   * @param {Object} dataParam 请求参数
   * @param {Function} middleware 一次性中间件
   * @param {Object} options 其他设置
   *  @param {Boolean} noUseRequestMiddleware // 禁止使用request中间件
   *  @param {Boolean} noUseRequestMiddleware // 禁止使用request中间件
   *  @param {Boolean} noUseRequestMiddleware // 禁止使用request中间件
   */
  post = (url, data = {}, middleware, options) => {
    return this.requestTemplate(url, 'POST', data, middleware, options);
  };

  /**
   * put requset
   * @param {String} url 请求地址
   * @param {Object} dataParam 请求参数
   * @param {Function} middleware 一次性中间件
   * @param {Object} options 其他设置
   *  @param {Boolean} noUseRequestMiddleware // 禁止使用request中间件
   *  @param {Boolean} noUseRequestMiddleware // 禁止使用request中间件
   *  @param {Boolean} noUseRequestMiddleware // 禁止使用request中间件
   */
  put = (url, data = {}, middleware, options) => {
    return this.requestTemplate(url, 'PUT', data, middleware, options);
  };

  /**
   * delete requset
   * @param {String} url 请求地址
   * @param {Object} dataParam 请求参数
   * @param {Function} middleware 一次性中间件
   * @param {Object} options 其他设置
   *  @param {Boolean} noUseRequestMiddleware // 禁止使用request中间件
   *  @param {Boolean} noUseRequestMiddleware // 禁止使用request中间件
   *  @param {Boolean} noUseRequestMiddleware // 禁止使用request中间件
   */
  delete = (url, data = {}, middleware, options) => {
    return this.requestTemplate(url, 'DELETE', data, middleware, options);
  };
}

export {
  Request,
  json,
  form,
  formData,
};
