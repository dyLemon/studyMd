import qs from 'qs';

export const contentType = new Map([
  ['json', 'application/json;charset=utf-8'],
  ['form', 'application/x-www-form-urlencoded;charset=UTF-8'],
  ['formData', 'formData'],
]);

// 转 application/x-www-form-urlencoded 请求传参
export function toFormUrlencoded(obj) {
  return qs.stringify(obj);
}

// 转 form-data 请求参数
export function toFormData(originData) {
  const formData = new FormData();
  const isObject = (obj) => typeof obj === 'object' && obj !== null && !(obj instanceof Date) && !(obj instanceof File);

  const tarnsferToFormData = (data, keyName) => {
    if (isObject(data)) {
      Object.entries(data).map(([key, val]) => {
        let newKeyName = key;
        if (Array.isArray(data)) {
          newKeyName = keyName ? `${keyName}[${key}]` : key;
        } else {
          newKeyName = keyName ? `${keyName}.${key}` : key;
        }
        tarnsferToFormData(val, newKeyName);
      });
    } else {
      formData.append(keyName, data);
    }
  };
  tarnsferToFormData(originData, '');

  return formData;
}

// 转 query-string 请求参数
export function toQueryString(url = '', obj = {}) {
  const paramsStr = qs.stringify(obj);
  const fullUrl = paramsStr ? `${url}?${paramsStr}` : url;
  return fullUrl;
}
