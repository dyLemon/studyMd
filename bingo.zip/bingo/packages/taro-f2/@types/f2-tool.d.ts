export function fixF2(F2:any): any
