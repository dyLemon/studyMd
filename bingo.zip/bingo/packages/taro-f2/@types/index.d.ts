export { default as F2Canvas } from './f2-canvas'
export { fixF2 } from './f2-tool'
