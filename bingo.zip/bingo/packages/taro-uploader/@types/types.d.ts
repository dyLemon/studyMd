interface taroUploader {
    getFiles: getFiles
    startUpload: startUpload
    upload: upload
}

type UploadImageParams = {
    /**
     * 上传的文件类型
     */
    uploadType: 'image'
    /**
     * 上传图片张数
     */
    count?: 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9
    /**
     * 文件来源
     * album 相册
     * camera 摄像头
     */
    sourceType?: ['album', 'camera'] | ['album'] | ['camera'] | String[]
}

type UploadVideoParams = {
    /**
     * 上传的文件类型
     */
    uploadType: 'video'
    /**
     * 文件来源
     * album 相册
     * camera 摄像头
     */
    sourceType?: ['album', 'camera'] | ['album'] | ['camera'] | String[]
    /**
     * 是否压缩所选择的视频文件
     */
    compressed?: boolean
    /**
     * 拍摄视频最长拍摄时间，单位秒
     * 默认60秒
     */
    maxDuration?: number
    /**
     * 默认拉起的是前置或者后置摄像头。部分 Android 手机下由于系统 ROM 不支持无法生效
     * 默认 back
     */
    camera?: 'back' | 'front'
}

type UploadMessageFileParams = {
    uploadType: 'messageFile',
    /**
     * 最多可以选择的文件个数 0 - 100
     */
    count: number
    /**
     * all 从所有文件选择
     * video 只能选择视频文件
     * image 只能选择图片文件
     * file 可以选择除了图片和视频之外的其它的文件
     */
    type: 'all' | 'video' | 'image' | 'file'
    /**
     * 根据文件拓展名过滤，仅 type==file 时有效。每一项都不能是空字符串。默认不过滤。
     */
    extension?: String[]
}

type uploadParams = UploadImageParams | UploadVideoParams | UploadMessageFileParams
type uploadReturn = {
    path: string
    url: string
    urlFilePath: string
    [str: string]: string | number
}[]

type upload = (uploadParams: uploadParams) => Promise<uploadReturn>;

type ImageFile = {
    /**
     * 本地文件临时路径
     */
    path: string
    /**
     * 本地临时文件大小,单位B
     */
    size: number
}

export type GetImageFilesReturn = {
    tempFilePaths: string[]
    tempFiles: ImageFile[]
}

export type GetVideoFilesReturn = {
    /**
     * 选定视频的时间长度
     */
    duration: number
    /**
     * 选定视频的高度
     */
    height: number
    /**
     * 返回选定视频的宽度
     */
    width: number
    /**
     * 选定视频的数据量大小
     */
    size: number
    /**
     * 选定视频的临时文件路径
     */
    tempFilePath: string
    /**
     * 调用结果
     */
    errMsg: string
}

export type ChooseFile = {
    /**
     * 选择的文件名
     */
    name: string
    /**
     * 临时文件路径
     */
    path: string
    /**
     * 本地临时文件大小，单位B
     */
    size: number
    /**
     * 选择的文件的会话发送时间，Unix时间戳，工具暂不支持此属性
     */
    time: number
    type: 'video' | 'image' | 'file'
}
export type GetMessageFileReturn = {
    tempFiles: ChooseFile[]
    errMsg: string
}

export type GetFilesReturn = GetImageFilesReturn | GetVideoFilesReturn | GetMessageFileReturn
export type getFiles = (uploadParams: uploadParams) => Promise<GetFilesReturn>

export type startUpload = (tempFilePaths: /* 临时文件路径数组 */Array<string>) => Promise<uploadReturn>

export default interface BingoTaroUploader {
    createUploader(): taroUploader
}