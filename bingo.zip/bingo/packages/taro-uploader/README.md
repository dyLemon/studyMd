# `taro-uploader`

安装
    ```javascript
    yarn add @bingo/taroUploader 或者 npm install @bingo/taroUploader --save
    ```

### 微信小程序taro框架 上传图片 库

#### 方法

    选择文件后立即开始上传
    uploader.upload(params)
    @params {Object} params
    @params @required {Taro} params.Taro
    @params @required {string || function} params.token 如果token是方法，则host字段取该方法返回的字段
    @params {string} params.host 七牛云配置的访问资源域名
    @params {string} params.action 七牛云上传文件地址，默认华南区域
    @params {stirng} params.prefix 文件路径前缀，例如：${client}/${prefix}/12346/abc.jpg
    @params {callback} params.onProgress 文件上传进度回调，基于Taro的progress回调方法
    @params {callback} params.onChoose 文件选择后的回调，返回例如 {type, res} res为微信相关api返回的数据
    @params {callabck} params.onUploadSequence 上传完成一次调用一次
    @return {Array<Object>} response [{ url, urlFilePath, path, ...rest }]


    获取设备上文件的临时文件路径
    @param {String} type image | video | messageFile
    @param {Object} params chooseImage, chooseVideo, chooseMessageFile 对应参数
    @return 微信相关api返回数据
    uploader.getFiles


    开始上传
    @param {Array<String>} tempFilePaths 临时文件数组
    @return {Array<Object>} response [{ url, urlFilePath, path, ...rest }]
    uploader.startUpload

#### 使用

    ```javascript
    import { createUploader } from '@bingo/taroUploader';
    const onProgress = (info) => {
        const { index, total, progress, totalBytesSent, totalBytesExpectedToSend } = info;
        // Taro.showLoading({ title: `已上传${parseInt((progress / totalProgress) * 100)}%` });
        // index 当前上传文件的索引 0 起始
        // progress 当前文件上传进度 0 - 100
        // total 总文件数
        // totalBytesSent 已上传的数据长度
        // totalBytesExpectedToSend 预期需要上传的数据长度
    }

    const checkFileSize = (fileInfo) => {
        const maxSize = 1024 * 1024 * 5;
        const { size = 0 } = fileInfo.res.tempFiles[0] || {};
        if (size > maxSize) {
            Taro.showToast({ icon: 'none', title: '文件过大,请重新选择上传！', duration: 1000 });
            return Promise.reject();
        }
        return Promise.resolve();
    };

    const checkCropper = (fileInfo) => {
        return new Promise((resolve, reject) => {
            this.setState({
                cropperUrl: fileInfo.res.tempFilePaths[0],
                cropperVisible: true,
                cropperResolve: resolve,
                cropperReject: reject,
            });
        });
    };

    // 选中文件的回调，promise返回处理后的文件本地路径
    const onChoose = async (choosed) => {
        // ---------------检查文件大小
        await checkFileSize(choosed);
        // ---------------裁剪图片大小
        return checkCropper(choosed);
    };

    const onUploadSequence = (currentFile, index, uploadStatus, uploadFiles) => {
        console.log(currentFile) // currentFile 当前已上传的文件 { path, urlFilePath, url, ...others };
        console.log(index) // index 当前文件在数组中的索引 index === uploadFiles.length - 1
        console.log(uploadStatus) // uploadStatus 'done'所有文件已上传完毕 'next'还有未上传完成的图片
        console.log(uploadFiles) // uploadFiles 已上传完成的数组 [{ path, urlFilePath, url, ...others }]
    }

    const getToken = async () => ({token: 123, host: 'http://localhost:123'});
    // 可全局创建一个实例
    const uploader = createUploader({ Taro, token: getToken, onChoose, onProgress, onUploadSequence, });

    /**
      uploadType // 必须 image | video | messageFile
      ...rest // 选择图片、视频、会话文件相关参数 @see https://developers.weixin.qq.com/miniprogram/dev/api/media/image/wx.chooseImage.html
    */
    try {
        const params = {}
        const response  = await uploader.upload({ uploadType, params })
        console.log(response) // [{ url, urlFilePath, path, ...rest }] 
    } catch(error) {
        // 取消图片、视频、会话选择时会走catch块
        console.log(error)
    }

    // 手动上传
    try {
        const params = {} // @see https://developers.weixin.qq.com/miniprogram/dev/api/media/image/wx.chooseImage.html
        const handleResponse = (p) => {};
        
        const response = await upload.getFiles({ type: 'image', ...params });
        const tempFilePaths = handleResponse(response);
        const res = await upload.startUpload(tempFilePaths);
    } catch (error) {
        console.log(error)
    }
    ```
