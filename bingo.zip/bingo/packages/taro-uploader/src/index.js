'use strict';

const loop = () => {}

/**
 * 七牛云的token校验是在文件上传完成之后才返回, onProgress会执行到上传完毕。
 */
const taroUploader = ({
    Taro,
    action = 'https://upload-z2.qiniup.com', // 七牛云的华南区域上传接口, 需要配置在小程序后台配置服务器域名
    token,
    host = '', // 如果token 是方法，则host取 该方法返回的host字段
    client = 'miniprogram',// 图片命名空间
    prefix = 'default', // 生成图片路径前缀
    onProgress = loop,
    onChoose = loop, 
    onUploadSequence = loop,
    onStart = loop
  }) => {
  
    const __handleFileName = ({
      prefix = 'default',
      suffix,
      identify // 文件名
    }) => {
      identify = identify ? identify : Math.random().toString().substr(2);
      prefix = prefix ? `/${prefix}` : '';
      // 文件名后缀
      suffix = (suffix && suffix !== 'unknow') ? `.${suffix}` : '';
      const timeStamp = new Date().getTime();
      return `${client}${prefix}/${timeStamp}/${identify}${suffix}`;
    }
  
    const __handleResponse = (dataString) => {
      try {
        return JSON.parse(dataString)
      } catch (error) {
        return { error: `__handleResponse method JSON parse error`, data: dataString }
      }
    }
  
    // 微信api
    /**
     * 获取设备上文件的临时文件路径
     * @param {String} type image | video | messageFile
     * @param {Object} params chooseImage, chooseVideo, chooseMessageFile 对应参数
     */
    const getFiles = async (type, params) => {
      switch (type) {
        case 'image':
          return await Taro.chooseImage(params);
        case 'video':
          return await Taro.chooseVideo(params);
        case 'messageFile':
          return await Taro.chooseMessageFile(params);
        default:
          console.error(`getFiles type参数有误:${type}`);
          break;
      }
    }
  
    const __uploadSequence = async (tempFilePaths) => {
      const filePaths = tempFilePaths.slice();
      const total = filePaths.length;
      const uploadFiles = [] // [{ url: '', urlFilePath: '', path: '' }]
      if (typeof token === 'function') {
        const { token: t, host: h } = await token();
        token = t;
        host = h;
      }
  
      const uploadInnerPromise = async () => {
        const uploadInner = async (resolve, reject) => {
          const path = filePaths.shift();
          if (!path) {
            return resolve(uploadFiles);
          };
          const pathArr = path.split('.');
          const suffix = pathArr[pathArr.length - 1];
          const response = await Taro.uploadFile({
            url: action,
            filePath: path,
            name: 'file',
            formData: { token, key: __handleFileName({ prefix, suffix }) }
          }).progress((res) => {
            // console.log(`第${uploadFiles.length + 1}/${total}个文件的上传进度`, res);
            // console.log('上传进度', res.progress)
            // console.log('已经上传的数据长度', res.totalBytesSent)
            // console.log('预期需要上传的数据总长度', res.totalBytesExpectedToSend)
            const { progress, totalBytesSent, totalBytesExpectedToSend } = res;
            onProgress({ index: uploadFiles.length, total, progress, totalBytesSent, totalBytesExpectedToSend });
          });
          const { errMsg } = response;
          if (errMsg === 'uploadFile:ok') {
            const { error, key, ...others } = __handleResponse(response.data);
            // 七牛云返回报错
            if (error || response.statusCode !== 200) {
              reject({ errMsg: error, statusCode: response.statusCode, ...others });
            }
            const urlFilePath = `/${key}`;
            const currentFile = { path, urlFilePath, url: `${host}${urlFilePath}`, ...others };
            uploadFiles.push(currentFile);
            const uploadStatus = uploadFiles.length < total ? 'next' : 'done';
            onUploadSequence && onUploadSequence(currentFile, uploadFiles.length - 1, uploadStatus, uploadFiles);
            uploadInner(resolve, reject);
          } else {
            // 微信上传接口报错
            reject({ errMsg: errMsg });
          }
        }
        return new Promise((resolve, reject) => uploadInner(resolve, reject))
      }
      return await uploadInnerPromise();
    }
  
    const __uploadConcurrent = (tempFilePaths) => {
      // 并发上传
    }
  
    /**
     * 开始上传
     * @param {Array<String>} tempFilePaths 临时文件数组
     */
    const startUpload = async (tempFilePaths) => {
      // 后期根据 是否是 依次上传 还是 批量同时上传
      onStart(tempFilePaths);
      if (tempFilePaths && Array.isArray(tempFilePaths)) {
        return await __uploadSequence(tempFilePaths);
      }
      console.log('临时文件数组为空');
    }
  
    /**
     * 上传图片
     * @param {Object} param0 参数集合
     * @param {Number} count  1 - 9
     * @param {Array<String>} sizeType ['original', 'compressed']
     * @param {Array<String>} sourceType ['album', 'camera']
     * @return {Array<String>} [{ url: '', path: '', urlFilePath: '', [...]}]
     */
    const __uploadImage = async ({ count, sizeType, sourceType }) => {
      const res = await getFiles('image', { count, sizeType, sourceType });
      const chooseFile = await onChoose({ type: 'image', res });
      if (chooseFile) {
        res.tempFilePaths[0] = chooseFile;
        res.tempFiles[0].path = chooseFile;
      }

      const { tempFilePaths } = res;
      return await startUpload(tempFilePaths);
    }
  
    /**
     * 上传视频
     * @param {Object} param0 参数集合
     * @param {Array<String>} sourceType ['album', 'camera']
     * @param {Boolean} compressed 是否压缩所选择的视频文件
     * @param {Number} maxDuration 拍摄视频最长拍摄时间，单位秒
     * @param {String} camera back | front 选择摄像头，部分android机不支持
     * @return {Array<String>} [{ url: '', path: '', urlFilePath: '', [...]}]
     */
    const __uploadVideo = async ({ sourceType, compressed, maxDuration, camera }) => {
      const res = await getFiles('video', { sourceType, compressed, maxDuration, camera });
      onChoose({ type: 'video', res });
      const { tempFilePath, ...others  } = res;
      // 选择视频，一次只能选择一个， uploadFiles 只有单个元素.
      // 如果以后可以选择多个视频，则需要改写这部分逻辑。
      // 参考__uploadMessageFile方法
      const uploadFiles = await startUpload([tempFilePath]);
      return uploadFiles.map((file) => ({ ...file, ...others }));
    }
  
    /**
     * 从会话中选择文件上传
     * @param {Object} param0 参数集合
     * @param {Number} count  0 - 100
     * @param {String} type 从会话上传 所选的文件类型 all = 所有 | video | image | file = 选择除视频和图片之外的其他文件
     * @param {Array<String>} extension 根据文件拓展名过滤，仅 type==file 时有效。每一项都不能是空字符串。默认不过滤。
     * @return {Array<String>} [{ url: '', path: '', urlFilePath: '', [...]}]
     */
    const __uploadMessageFile = async ({ type, extension, count }) => {
      let params = { count, type };
      if (extension && extension.length) {
        params = { ...params, extension };
      }
      const res = await getFiles('messageFile', params);
      onChoose({ type: 'messageFile', res });
      const { tempFiles } = res;
      const tempFilePaths = tempFiles.map((file) => file.path);
      const uploadFiles = await startUpload(tempFilePaths);
      return uploadFiles.map((file, index) => ({ ...file, ...tempFiles[index] }));
    }
  
    /**
     * 上传方法
     * @param {Object} param0 参数集合
     * @param {String} uploadType image | video | other
     * @param {Number} count  选择图片 最多9个， 从会话选择文件，最多100个 0 - 100
     * @param {Array<String>} sizeType ['original', 'compressed']
     * @param {Array<String>} sourceType ['album', 'camera']
     * @param {Boolean} compressed 是否压缩所选择的视频文件
     * @param {Number} maxDuration 拍摄视频最长拍摄时间，单位秒
     * @param {String} camera back | front 选择摄像头，部分android机不支持
     * @param {String} type 从会话上传 所选的文件类型 all = 所有 | video | image | file = 选择除视频和图片之外的其他文件
     * @param {Array<String>} extension 根据文件拓展名过滤，仅 type==file 时有效。每一项都不能是空字符串。默认不过滤。
     */
    const upload = async ({
      uploadType = 'image',
      sourceType = 	['album', 'camera'],
      // image
      count = 1,
      sizeType = ['original', 'compressed'],
      // video
      compressed = true,
      camera = 'back',
      maxDuration = 60,
      // 从会话中选择文件
      type = 'all',
      extension = []
    } = {
      uploadType: 'image',
      count: 1,
      sizeType: ['original', 'compressed'],
      sourceType: ['album', 'camera'],
      compressed: true,
      camera: 'back',
      maxDuration: 60,
      tyep: 'all',
      extension: []
    }) => {
      if (uploadType === 'image') {
        return await __uploadImage({ count, sizeType, sourceType });
      } else if (uploadType === 'video') {
        return await __uploadVideo({ sourceType, compressed, maxDuration, camera });
      } else if (uploadType === 'messageFile') {
        if (Taro.chooseMessageFile) {
          return await __uploadMessageFile({ count, type, extension });
        }
        console.log('该用户的环境不支持chooseMessageFile方法');
        return []
      }
    }
    return {
      getFiles,
      startUpload,
      upload
    }
  }


export default {
  createUploader: taroUploader
}

