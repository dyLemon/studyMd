---
name: taro2.x 升级至 taro3.x 工具助手
menu: script
route: /taro2-to-taro3
---

# taro2-to-taro3

taro2.x 一键升级至 taro3

**目录：**
packages/taro2-to-taro3

<br/>

使用方式

```
yarn global add @bingo/taro2-to-taro3
或
npm install @bingo/taro2-to-taro3 -g
```

---
