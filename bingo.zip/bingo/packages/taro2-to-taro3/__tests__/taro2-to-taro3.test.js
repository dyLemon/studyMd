'use strict';

const taro2ToTaro3 = require('..');

describe('taro2-to-taro3', () => {
    it('needs tests');
});
