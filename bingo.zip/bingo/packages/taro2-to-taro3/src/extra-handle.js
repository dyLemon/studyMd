/**
 * 1. 生成babel.config.js 配置文件
 * 2. 更改config/index.js 文件
 *   -- 添加 framework: 'react',
 *   -- 删除 babel 配置相关,
 *   -- 删除 mini-postcss-autoprefixer 配置
 *   -- mini 属性下 添加 解除 编译警告 chunk common [mini-css-extract-plugin]
 *      enableExtract:true,
        miniCssExtractPluginOption: {
          //忽略css文件引入顺序
          ignoreOrder: true
        },
 */
const $ = require("gogocode");
const path = require("path");

const BABEL_TEMPLATE = `
module.exports = {
  presets: [
    ['taro', {
      framework: 'react',
      ts: true
    }]
  ]
}
`;

// 生成babel.config.js 配置文件
const generateBabelConfig = () => {
  $.writeFile(BABEL_TEMPLATE, path.join(process.cwd(), "babel.config.js"));
};

/**
 * 2. 更改config/index.js 文件
 *   -- 添加 framework: 'react',
 *   -- 删除 babel 配置相关,
 *   -- 删除 mini-postcss-autoprefixer 配置
 *   -- mini 属性下 添加 解除 编译警告 chunk common [mini-css-extract-plugin]
 *      enableExtract:true,
        miniCssExtractPluginOption: {
          //忽略css文件引入顺序
          ignoreOrder: true
        },
 */
const updateProjectConfig = () => {
  const sourcePath = path.join(process.cwd(), "config/index.js");
  const newCode = $.loadFile(sourcePath)
    .replace(
      `const config = {
          babel:$_$0,
          mini:{
            $$$2
          },
          $$$1
        }
        `,
      `const config = {
          framework: 'react',
          mini:{
            enableExtract: true,
            miniCssExtractPluginOption: {
              //忽略css文件引入顺序
              ignoreOrder: true
            },
            $$$2
          },
          $$$1
        }
      `
    )
    .root()
    .replace(
      `
      postcss:{
        autoprefixer:{$_$0},
        $$$
      }
    `,
      `
    postcss:{
      $$$
    }
  `
    )
    .root()
    .generate();

  $.writeFile(newCode, sourcePath);
};

const run = () => {
  generateBabelConfig();
  updateProjectConfig();
};

run();
