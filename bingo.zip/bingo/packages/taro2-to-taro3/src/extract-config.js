const glob = require("glob");
const path = require("path");
const $ = require("gogocode");
const { sourcePath, normalizePath } = require("./utils");

// 获取所有页面路径 包括子包页面
const getPages = () => {
  const [appFilePath] = glob.sync(`${sourcePath()}/app.{js,jsx}`);
  const appPath = path.join(process.cwd(), appFilePath);
  let pages = [];
  $.loadFile(appPath, {
    parseOption: { plugins: ["jsx"] },
  })
    .find(
      `class App extends Component {
    config = {
      pages: [$_$mainPage],
      subpackages: [{root:$_$root,pages:$_$subPages}],
    }
  }`
    )
    .each((item) => {
      // 主包页面
      const mainPages = item.match.mainPage.map((mainEle) =>
        normalizePath(mainEle.value)
      );
      // 分包页面
      const subPages = item.match.subPages.reduce((prev, cur, index) => {
        return prev.concat(
          cur.node.elements.map(
            (s) => `${normalizePath(item.match.root[index].value)}/${s.value}`
          )
        );
      }, []);

      pages = [...pages, ...mainPages, ...subPages];
    });
  return pages;
};

// 删除源文件的config 属性
const deleteSrouceConfig = (filePath) => {
  const newCode = $.loadFile(path.join(process.cwd(), filePath), {
    parseOption: { plugins: ["jsx"] },
  })
    .find("$_$0.config = $_$1")
    .remove()
    .root()
    .replace(
      `class $_$c extends $_$d {
    config=$_$2
    $$$
  }`,
      `class $_$c extends $_$d {
    $$$
  }`
    )
    .generate();
  $.writeFile(newCode, path.join(process.cwd(), filePath));
};

// 根据config配置生成文件
const generacConfigFile = (pathSource, code) => {
  const newCode = `export default ${code};
`;
  const pathArr = pathSource.split("/");
  const lastItem = pathArr.pop();
  $.writeFile(
    newCode,
    path.join(process.cwd(), `${pathArr.join("/")}/${lastItem}.config.js`)
  );
};

// 获取config 便于复制到***.config.js
const getPageConfig = (pathSource) => {
  const [filePath] = glob.sync(`${sourcePath()}/${pathSource}.{js,jsx}`);
  const formatPath = path.join(process.cwd(), filePath);
  const loadFile = $.loadFile(formatPath, {
    parseOption: { plugins: ["jsx"] },
  });
  if (typeof loadFile.find === "function") {
    loadFile
      .find("$_$0.config = $_$1")
      .each((item) => {
        generacConfigFile(
          `${sourcePath()}/${pathSource}`,
          item.match[1][0].value
        );
      })
      .root()
      .find(
        `class $_$c {
      config=$_$2
    }
    `
      )
      .each((item) => {
        generacConfigFile(
          `${sourcePath()}/${pathSource}`,
          item.match[2][0].value
        );
      });

    deleteSrouceConfig(filePath);
  }
};

const run = () => {
  const pages = [...getPages(), "app"];
  pages.forEach(getPageConfig);
};

run();
