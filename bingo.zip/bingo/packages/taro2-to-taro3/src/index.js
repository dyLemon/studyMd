#!/usr/bin/env node
"use strict";

const { Commander } = require("commander");
const path = require("path");
const fs = require("fs");
const childProcess = require("child_process");
const pkg = require("../package.json");

const commander = new Commander();
commander.version(pkg.version).parse(process.argv);

const runExtractConfig = () => {
  const n = childProcess.fork(`${__dirname}/extract-config.js`);
  n.on("message", () => {});
  n.on("exit", () => {
    console.log("\x1B[32m", "页面配置信息提取完毕");
    console.log("\x1B[0m");
  });
};

const runTransformReference = () => {
  const n = childProcess.fork(`${__dirname}/transform-reference.js`);
  n.on("message", () => {});
  n.on("exit", () => {
    console.log("\x1B[32m", "文件转换完毕");
    console.log("\x1B[0m");
    runExtractConfig();
  });
};

// 安装taro3.x相关依赖包package.json
const intallPackage = async () => {
  const packagePath = path.join(process.cwd(), "package.json");

  const templateJson = fs
    .readFileSync(path.resolve(__dirname, "./utils/template-package.json"))
    .toString();

  const data = fs.readFileSync(packagePath).toString();

  if (!data) throw Error("package.json not found");

  const packages = JSON.parse(data);

  const transformTemplateJson = JSON.parse(templateJson);

  const newPackage = {
    ...packages,
    ...transformTemplateJson,
    dependencies: {
      ...packages.dependencies,
      ...transformTemplateJson.dependencies,
    },
    devDependencies: {
      ...packages.devDependencies,
      ...transformTemplateJson.devDependencies,
    },
  };
  fs.writeFileSync(packagePath, JSON.stringify(newPackage, null, 2), "utf-8");
  console.log("\x1B[32m", "依赖包更新完成");
  console.log("\x1B[0m");
};

// 执行额外的操作
const runExtraHandle = () => {
  childProcess.execFile(
    "node",
    [`${__dirname}/extra-handle.js`],
    {
      cwd: process.cwd(),
      stdio: "inherit",
      shell: process.platform === "win32", // win兼容
    },
    (error, stdout, stderr) => {
      stderr && console.log(stderr);
      stdout && console.log(stdout);
    }
  );
};

// 删除node_modules 重新安装
// const refreshPackage = async () => {
//   await exec("rm -rf node_modules");
//   await exec("yarn install --registry=https://npm.biaoguoworks.com");
// };

/**
 * 一、提取 config文件的sourceRoot 找到项目源文件夹
 * 二、找到源文件夹中app.jsx 提取项目的所有页面 包括子包
 * 三、复制源文件config配置到新的配置文件中 并删除源文件中config属性
 * 四、替换引入 Component hooks PureComponent Taro.PureComponent Taro.Component
 * 五、替换this.$router 为 getCurrentInstance().router
 * 六、替换this.$scope 为 getCurrentInstance().page
 * 七、根据react规范，替换部分生命周期命名
 * 八、替换 @tarojs/mobx 为 mobx-react (refs: https://taro-docs.jd.com/taro/docs/migration#%E4%BD%BF%E7%94%A8%E7%AC%AC%E4%B8%89%E6%96%B9-react-%E5%BA%93)
 * 九、更新package.json 配置
 * 十、生成babel.config.js文件
 * 十一、更新config/index.js文件
 */
const main = () => {
  runTransformReference();
  intallPackage();
  runExtraHandle();
};

main();
