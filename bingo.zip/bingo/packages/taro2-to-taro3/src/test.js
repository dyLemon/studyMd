const glob = require("glob");
const fs = require("fs");
const path = require("path");
const $ = require("gogocode");

const { normalizePath, reactSourceMap } = require("./utils");

/**
 * ！！测试用
 * 一、提取 config文件的sourceRoot 找到项目源文件夹
 * 二、找到源文件夹中app.jsx 提取项目的所有页面 包括子包
 * 三、复制源文件config配置到新的配置文件中 并删除源文件中config属性
 * 四、替换引入 Component hooks PureComponent Taro.PureComponent Taro.Component
 * 五、替换this.$router 为 getCurrentInstance().router
 * 六、替换this.$scope 为 getCurrentInstance().page
 * 七、根据react规范，替换部分生命周期命名
 * 八、替换 @tarojs/mobx 为 mobx-react (refs: https://taro-docs.jd.com/taro/docs/migration#%E4%BD%BF%E7%94%A8%E7%AC%AC%E4%B8%89%E6%96%B9-react-%E5%BA%93)
 */
const getSourcePath = () => {
  const configPath = path.resolve(__dirname, "config/index.js");
  const sourceRoot = fs.readFileSync(configPath, "utf8").toString();

  // 方法一：
  // $(sourceRoot)
  //   .find(`{ sourceRoot: $_$ }`)
  //   .each((item) => {
  //     return item.match[0][0].node.value
  //   });

  // 方法二：
  return /sourceRoot: '(.*)',/.exec(sourceRoot)[1].trim();
};

const sourcePath = getSourcePath();

// 获取所有页面路径 包括子包页面
const getPages = () => {
  const [appFilePath] = glob.sync(`${sourcePath}/app.{js,jsx}`);
  const appPath = path.resolve(__dirname, appFilePath);
  let pages = [];
  $.loadFile(appPath, {
    parseOption: { plugins: ["jsx"] },
  })
    .find(
      `class App extends Component {
      config = {
        pages: [$_$mainPage],
        subpackages: [{root:$_$root,pages:$_$subPages}],
      }
    }`
    )
    .each((item) => {
      // 主包页面
      const mainPages = item.match.mainPage.map((mainEle) =>
        normalizePath(mainEle.value)
      );
      // 分包页面
      const subPages = item.match.subPages.reduce((prev, cur, index) => {
        return prev.concat(
          cur.node.elements.map(
            (s) => `${normalizePath(item.match.root[index].value)}/${s.value}`
          )
        );
      }, []);

      pages = [...pages, ...mainPages, ...subPages];
    });
  return pages;
};

// 删除源文件的config 属性
const deleteSrouceConfig = (filePath) => {
  const newCode = $.loadFile(path.resolve(__dirname, filePath), {
    parseOption: { plugins: ["jsx"] },
  })
    .find("$_$0.config = $_$1")
    .remove()
    .root()
    .replace(
      `class $_$c extends $_$d {
      config=$_$2
      $$$
    }`,
      `class $_$c extends $_$d {
      $$$
    }`
    )
    .generate();
  $.writeFile(newCode, path.resolve(__dirname, filePath));
};

// 根据config配置生成文件
const generacConfigFile = (pathSource, code, delFilePath) => {
  const newCode = `export default ${code};
`;
  const pathArr = pathSource.split("/");
  pathArr.pop();

  $.writeFile(
    newCode,
    path.resolve(__dirname, `${pathArr.join("/")}/index.config.js`)
  );
  deleteSrouceConfig(delFilePath);
};

// 获取config 便于复制到***.config.js
const getPageConfig = (pathSource) => {
  const [filePath] = glob.sync(`${sourcePath}/${pathSource}.{js,jsx}`);
  const formatPath = path.resolve(__dirname, filePath);
  $.loadFile(formatPath, {
    parseOption: { plugins: ["jsx"] },
  })
    .find("$_$0.config = $_$1")
    .each((item) => {
      generacConfigFile(
        `${sourcePath}/${pathSource}`,
        item.match[1][0].value,
        filePath
      );
    })
    .root()
    .find(
      `class $_$c {
        config=$_$2
      }
      `
    )
    .each((item) => {
      generacConfigFile(
        `${sourcePath}/${pathSource}`,
        item.match[2][0].value,
        filePath
      );
    });
};

// 模板中是否引入了react
const existReact = (file) => {
  return (
    file.has(`import $_$ from 'react'`) || file.has(`import {$_$} from 'react'`)
  );
};

/**
 * 替换解构的引用 形如 import Taro, { Component } from '@tarojs/taro';
 * 替换直接引用 class Index extends Taro.Component(PureComponent) {};
 * 五、替换this.$router 为 getCurrentInstance().router
 * 六、替换this.$scope 为 getCurrentInstance().page
 * 七、根据react规范，替换部分生命周期
 * 八、替换 @tarojs/mobx 为 mobx-react
 *  */
const doTransformReference = (pathSource) => {
  const formatPath = path.resolve(__dirname, pathSource);
  const loadFile = $.loadFile(formatPath, {
    parseOption: { plugins: ["jsx"] },
  });
  if (
    typeof loadFile.find === "function" &&
    typeof loadFile.has === "function"
  ) {
    const newCode = loadFile
      .root()
      .find(`import { $$$0 } from '@tarojs/taro'`)
      .each((item) => {
        const values = Array.from(
          new Set(item.match["$$$0"].map((i) => i.local.name))
        );
        const reactHooks = values.reduce(
          (prev, current) => {
            if (current === "Taro") {
              return prev;
            }
            if (reactSourceMap.includes(current)) {
              return { ...prev, react: [...prev.react, current] };
            }
            if (!reactSourceMap.includes(current)) {
              return { ...prev, taro: [...prev.taro, current] };
            }
            return prev;
          },
          { react: [], taro: [] }
        );

        !existReact(loadFile) &&
          item.after(`
    import React${
      reactHooks.react.length > 0
        ? `, { ${reactHooks.react.splice(", ")} }`
        : ""
    } from "react";`);

        item.replace(
          `import { $$$ } from "@tarojs/taro"`,
          `import Taro${
            reactHooks.taro.length > 0
              ? `, { ${reactHooks.taro.splice(", ")} }`
              : ""
          } from "@tarojs/taro";`
        );
      })
      .root()
      .replace(`Taro.Component`, `React.Component`)
      .root()
      .replace(`Taro.PureComponent`, `React.PureComponent`)
      .root()
      .replace(`this.$router`, `Taro.getCurrentInstance().router`)
      .replace(`this.$scope`, `Taro.getCurrentInstance().page`)
      .replace(`componentWillReceiveProps`, `UNSAFE_componentWillReceiveProps`)
      .replace(`componentWillMount`, `UNSAFE_componentWillMount`)
      .replace(`componentWillUpdate`, `UNSAFE_componentWillUpdate`)
      .root()
      .replace(
        `import {$$$} from "@tarojs/mobx"`,
        `
    import { $$$ } from "mobx-react";`
      );
    !existReact(loadFile) &&
      newCode.root().prepend(
        `import React from "react"
          `
      );
    // console.log(newCode.generate());

    $.writeFile(newCode.generate(), path.resolve(__dirname, formatPath));

    getPages().forEach(getPageConfig);
  }
};

// 匹配components pages文件夹下 所有js、jsx文件
const transformReference = () => {
  glob(`${sourcePath}/{pages,components}/**/*.{js,jsx}`, (err, files) => {
    files.forEach(doTransformReference);
  });
  doTransformReference("src/app.jsx");
};

transformReference();

// ["pages/index/index"].forEach(getPageConfig);

// const { transformReference } = require("./transform-reference");

// const { extractConfig } = require("./extract-config");

// transformReference.run();
