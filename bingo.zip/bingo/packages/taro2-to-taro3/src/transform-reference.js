const glob = require("glob");
const path = require("path");
const $ = require("gogocode");

const { sourcePath, reactSourceMap } = require("./utils");

// 模板中是否引入了react
const existReact = (file) => {
  return (
    file.has(`import $_$ from 'react'`) ||
    file.has(`import {$$$} from 'react'`) ||
    file.has(`import $_$0, {$$$} from 'react'`)
  );
};

/**
 * 替换解构的引用 形如 import Taro, { Component } from '@tarojs/taro';
 * 替换直接引用 class Index extends Taro.Component(PureComponent) {};
 * 五、替换this.$router 为 getCurrentInstance().router
 * 六、替换this.$scope 为 getCurrentInstance().page
 * 七、根据react规范，替换部分生命周期
 * 八、替换 @tarojs/mobx 为 mobx-react
 *  */
const doTransformReference = (pathSource) => {
  const formatPath = path.join(process.cwd(), pathSource);
  const loadFile = $.loadFile(formatPath, {
    parseOption: { plugins: ["jsx"] },
  });
  if (
    typeof loadFile.find === "function" &&
    typeof loadFile.has === "function"
  ) {
    const newCode = loadFile
      .root()
      .find(`import { $$$0 } from '@tarojs/taro'`)
      .each((item) => {
        const values = Array.from(
          new Set(item.match["$$$0"].map((i) => i.local.name))
        );
        const reactHooks = values.reduce(
          (prev, current) => {
            if (current === "Taro") {
              return prev;
            }
            if (reactSourceMap.includes(current)) {
              return { ...prev, react: [...prev.react, current] };
            }
            if (!reactSourceMap.includes(current)) {
              return { ...prev, taro: [...prev.taro, current] };
            }
            return prev;
          },
          { react: [], taro: [] }
        );

        !existReact(item.root()) &&
          item.before(
            `import React${
              reactHooks.react.length > 0
                ? `, { ${reactHooks.react.splice(", ")} }`
                : ""
            } from "react";
          `
          );

        item.replace(
          `import { $$$ } from "@tarojs/taro"`,
          `import Taro${
            reactHooks.taro.length > 0
              ? `, { ${reactHooks.taro.splice(", ")} }`
              : ""
          } from "@tarojs/taro";`
        );
      })
      .root()
      .find(`return $_$0`)
      .each((item) => {
        const hasJSXElement = (item.match[0] || []).some(
          (i) => i.node.type === "JSXElement"
        );
        if (hasJSXElement && !existReact(item.root())) {
          item.root().prepend(
            `import React from "react";
          `
          );
        }
        // if (item.match[0].length > 0 && !existReact(item.root())) {
        //   item.root().prepend(
        //     `import React from "react";
        //   `
        //   );
        // }
      })
      .root()
      .replace(`Taro.Component`, `React.Component`)
      .replace(`Taro.PureComponent`, `React.PureComponent`)
      .replace(`this.$router`, `Taro.getCurrentInstance().router`)
      .replace(`this.$scope`, `Taro.getCurrentInstance().page`)
      .replace(`componentWillReceiveProps`, `UNSAFE_componentWillReceiveProps`)
      .replace(`componentWillMount`, `UNSAFE_componentWillMount`)
      .replace(`componentWillUpdate`, `UNSAFE_componentWillUpdate`)
      .replace(
        `import {$$$} from "@tarojs/mobx"`,
        `
  import { $$$ } from "mobx-react";`
      )
      .root();

    // console.log(
    //   ">>>>>>",
    //   newCode.has(`import { $_$0 } from '@tarojs/components'`) &&
    //     !existReact(newCode)
    // );

    if (
      newCode.has(`import { $_$0 } from '@tarojs/components'`) &&
      !existReact(newCode)
    ) {
      newCode.root().prepend(
        `import React from "react";
        `
      );
    }

    $.writeFile(newCode.generate(), path.join(process.cwd(), pathSource));
  }
};

// 匹配components pages文件夹下 所有js、jsx文件
const run = () => {
  glob(`${sourcePath()}/{components,pages}/**/*.{js,jsx}`, (err, files) => {
    files.forEach(doTransformReference);
  });
  doTransformReference(`${sourcePath()}/app.jsx`);
  // doTransformReference(`src/pages/provider/add/index.jsx`);
};

run();
