const path = require("path");
const fs = require("fs");

// 格式化path 去掉首尾'/'
const normalizePath = (filePath) =>
  filePath.replace(/^\/+/, "").replace(/\/+$/, "");

// react 相关
const reactSourceMap = [
  "PureComponent",
  "Component",
  "useState",
  "useEffect",
  "useCallback",
  "useMemo",
  "useRef",
  "useLayoutEffect",
  "useContext",
  "useImperativeHandle",
  "useLayoutEffect",
  "useReducer",
  "memo",
  "createRef",
];

// 获取入库
const sourcePath = () => {
  const configPath = path.join(process.cwd(), "config/index.js");
  const sourceRoot = fs.readFileSync(configPath, "utf8").toString();

  // 方法一：
  // $(sourceRoot)
  //   .find(`{ sourceRoot: $_$ }`)
  //   .each((item) => {
  //     return item.match[0][0].node.value
  //   });

  // 方法二：
  return /sourceRoot: '(.*)',/.exec(sourceRoot)[1].trim();
};

module.exports = {
  normalizePath,
  reactSourceMap,
  sourcePath,
};
