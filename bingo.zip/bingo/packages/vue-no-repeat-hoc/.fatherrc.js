module.exports = {
  entry: './src/index.vue',  
}
