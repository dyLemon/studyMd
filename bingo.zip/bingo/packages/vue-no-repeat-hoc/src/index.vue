<script>
  import Vue from 'vue';
  
  export default Vue.component('no-repeat-hoc', {
    props: {
      loadingSize: {
        type: Number,
        default: 20,
      },
      loadingColor: {
        type: String,
        default: '#FFF',
      }
    },
    data() {
      return {
        no_repeat_loading: false,
      } 
    },
    methods: {
      async _noRepeatClick(callback) {
        if (!this.no_repeat_loading) {
          this._createLoadingDom();
          this.no_repeat_loading = true;
          try {
            await callback();
          } catch(e) {
            console.error(e);
          } finally {
            this.no_repeat_loading = false;
          }
        }
      },

      _createLoadingDom() {
        if (this._noRepeatLoadingDom) {
          return this._noRepeatLoadingDom;
        }
        const { loadingSize, loadingColor } = this;
        this._noRepeatLoadingDom = document.createElement('i');
        this._noRepeatLoadingDom.style.cssText = `width=${loadingSize}px; height=${loadingSize}px; line-height: 0; position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%);`;
        this._noRepeatLoadingDom.innerHTML = `
          <svg viewBox="0 0 1024 1024" focusable="false" width=${loadingSize}px height=${loadingSize}px fill=${loadingColor}>
            <path d="M988 548c-19.9 0-36-16.1-36-36 0-59.4-11.6-117-34.6-171.3a440.45 440.45 0 0 0-94.3-139.9 437.71 437.71 0 0 0-139.9-94.3C629 83.6 571.4 72 512 72c-19.9 0-36-16.1-36-36s16.1-36 36-36c69.1 0 136.2 13.5 199.3 40.3C772.3 66 827 103 874 150c47 47 83.9 101.8 109.7 162.7 26.7 63.1 40.2 130.2 40.2 199.3.1 19.9-16 36-35.9 36z" />
          </svg>
        `;
        return this._noRepeatLoadingDom;
      }
    },

    watch: {
      no_repeat_loading(val) {
        if (val) {
          const { loadingSize } = this;
          let rotateDeg = 0;
          this.$el.style.position = 'relative';
          this.$el.style.opacity = '0.7';
          this.$el.appendChild(this._noRepeatLoadingDom);
          const rotateAnimate = () => {
            this._noRepeatLoadingDom.style.transform = `translate(-50%, -50%) translateZ(0) rotate(${rotateDeg}deg)`;
            rotateDeg += 6;
            this._noRepeatLoadingAnimation = requestAnimationFrame(rotateAnimate);
          };
          rotateAnimate();
        } else {
          this.$el.style.opacity = '1';
          this.$el.removeChild(this._noRepeatLoadingDom);
          cancelAnimationFrame(this._noRepeatLoadingAnimation);
        }
      },
    },

    render(createElement, context) {
      const children = this.$slots.default[0];
      const saveClickFunc = children.data.on.click;
      children.data.on.click = this._noRepeatClick.bind(this, saveClickFunc);
      return this.$slots.default
    },
  })
  </script>