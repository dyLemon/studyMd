<template>
  <div>
    <no-repeat-hoc>
      <button class="button" @click="handleClick">点击3s loading，当前数字{{count}}</button>
    </no-repeat-hoc>
  </div>
</template>

<script>
import NoRepeatHoc from './src/index.vue';

export default {
  data() {
    return {
      count: 0,
    }
  },
  components: {
    'no-repeat-hoc': NoRepeatHoc
  },
  methods: {
    handleClick() {
      // this._noRepeatClick(() => {
      //   return new Promise((resolve, rejcet) => {
      //     this.count += 1;
      //     setTimeout(() => {
      //       resolve();
      //     }, 3000);
      //   })
      // })
    }
  }
}
</script>

<style scope>
.button {
  border: none;
  background: #1890ff;
  color: #fff;
  padding: 10px 20px;
  border-radius: 4px;
}
</style>
