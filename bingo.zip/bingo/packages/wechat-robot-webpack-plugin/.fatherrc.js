module.exports = {
  target: 'node',
  entry: './src/index.js',
  // 使用rollup打包成commonjs标准模块输出
  cjs: {
    type: 'rollup',
    minify: true,
    file: 'index',
  },
  umd: false,
  esm: false,
};
