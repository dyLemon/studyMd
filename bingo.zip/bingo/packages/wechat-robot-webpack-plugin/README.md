# `wechat-robot-webpack-plugin`

> TODO: description

## Usage

```
const wechatRobotWebpackPlugin = require('wechat-robot-webpack-plugin');

// TODO: DEMONSTRATE API
```
