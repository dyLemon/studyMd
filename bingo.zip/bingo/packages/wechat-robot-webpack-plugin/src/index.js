const https = require('https');
const url = require('url');

// 机器人用法详见：https://work.weixin.qq.com/help?doc_id=13376#%E5%A6%82%E4%BD%95%E4%BD%BF%E7%94%A8%E7%BE%A4%E6%9C%BA%E5%99%A8%E4%BA%BA
module.exports = class WechatRobotWebpackPlugin {
  constructor(options) {
    this.options = options;
  }

  sendMsg(callback) {
    const {
      robotKey,
      msgType = 'text',
      content,
      remindAll = false,
      // remindUserIds = [],
      // remindUserMobiles = [],
    } = this.options;

    if (!robotKey) {
      return console.log('\x1B[31m%s\x1B[0m', '\n未配置群id号');
    }

    if (!content) {
      return console.log('\x1B[31m%s\x1B[0m', '\n未配置发送消息');
    }

    const requestBody = JSON.stringify({
      msgtype: msgType,
      text: {
        content,
        mentioned_list: [remindAll ? '@all' : ''].filter((res) => res),
      },
    });
    const req = https.request(
      {
        host: 'qyapi.weixin.qq.com',
        port: '443',
        path: `/cgi-bin/webhook/send?key=${robotKey}`,
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Content-Length': Buffer.byteLength(requestBody),
        },
      },
      (res) => {
        res.setEncoding('utf8');
      }
    );
    req.write(requestBody);
    req.end();

    req.on('error', (e) => {
      console.log(e);
      return console.log('\x1B[31m%s\x1B[0m', '\n消息发送失败');
    });
    req.on('end', callback);
  }

  apply(compiler) {
    compiler.hooks.done.tapAsync(
      'wechat-robot-plugin',
      (compilation, callback) => {
        this.sendMsg(callback);
      }
    );
  }
};
