// ! 实验用，对本项目没有任何意义（可删除）
const program = require('commander');
const { spawnSync } = require('child_process');
const colors = require('colors');
const ora = require('ora'); // 用于展示等待的动画效果
// const logSymbols = require('log-symbols'); // 用于展示小图标
const spinner = ora({
  hideCursor: false,
  Indent: 2,
  spinner: 'line2',
});


program
  .version('0.0.1')
  .option(
    '-p --packages <packages>', // <>为必填，[]为选填，不写会默认为boolean
    '需要打包的组件名称，多个请使用","分割',
    (value) => value.split(',')
  )
  .parse(process.argv);

console.log(program.packages);

const build = function(packages = []) {
  if (packages.length) {
    const [package, ...otherPackages] = packages;
    process.env.PACKAGE = package; // 指定father.js打包组件
    spinner.color = 'green';
    spinner.start(`开始打包${package}`);
    // 开新进程运行father build命令
    spawnSync('father', ['build'], {
      shell: process.platform === 'win32', // win兼容
      stdio: ['inherit', 'inherit', 'inherit'], // io，分别为：stdin，stdout，stderr，如果是inherit，子进程的输入/输出会同步到当前进程(显示到当前进程输入输出)
    });
    spinner.succeed(`${package}打包完成`);
    build(otherPackages);
  }
}

if (program.packages && program.packages.length) {
  build(program.packages);
}
