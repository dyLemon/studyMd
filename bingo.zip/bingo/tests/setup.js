const Enzyme = require('enzyme');
const Adapter = require('enzyme-adapter-react-16');
const nock = require('nock');
const axios = require('axios');
const React = require('react');

Enzyme.configure({ adapter: new Adapter() });

global.React = React;
global.nock = nock;
global.axios = axios;
