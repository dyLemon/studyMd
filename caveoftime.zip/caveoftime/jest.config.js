module.exports = {
    projects: ['<rootDir>/packages/*/src'],
    testURL: 'http://localhost/',
};
  