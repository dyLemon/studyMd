# @umi-material/@cot/core



## Usage

```sh
umi block https://github.com//tree/master/@cot/core
```

## LICENSE

MIT
