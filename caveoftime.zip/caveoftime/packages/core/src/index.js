/**
 * 默认只扔出util
 */
import * as Utils from './utils/';

export const utils = Utils.default;

export default Utils;
