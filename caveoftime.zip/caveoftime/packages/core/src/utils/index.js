import * as share from './share';
import * as obj from './object';
import table from './table/';

export default {
  ...share,
  ...obj,
  ...table
};
