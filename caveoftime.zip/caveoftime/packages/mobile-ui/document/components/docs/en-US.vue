<template>
  <viewport lang="en-US"></viewport>
</template>

<script>
  import Viewport from '../viewport/viewport.vue'

  export default {
    components: {
      Viewport
    }
  }
</script>

<style lang="stylus" rel="stylesheet/stylus">
</style>
