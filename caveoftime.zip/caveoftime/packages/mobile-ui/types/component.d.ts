import Vue from 'vue'

export declare class CubeUIComponent extends Vue {
  static install (vue: typeof Vue): void
}
