export * from './cube-ui'

import * as CubeUI from './cube-ui'

export default CubeUI
