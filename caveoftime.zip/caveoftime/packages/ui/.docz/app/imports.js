export const imports = {
  'src/index.mdx': () =>
    import(
      /* webpackPrefetch: true, webpackChunkName: "src-index" */ 'src/index.mdx'
    ),
  'src/core/index.mdx': () =>
    import(
      /* webpackPrefetch: true, webpackChunkName: "src-core-index" */ 'src/core/index.mdx'
    ),
  'src/page/index.mdx': () =>
    import(
      /* webpackPrefetch: true, webpackChunkName: "src-page-index" */ 'src/page/index.mdx'
    ),
  'src/searchForm/index.mdx': () =>
    import(
      /* webpackPrefetch: true, webpackChunkName: "src-search-form-index" */ 'src/searchForm/index.mdx'
    ),
  'src/tabLayout/index.mdx': () =>
    import(
      /* webpackPrefetch: true, webpackChunkName: "src-tab-layout-index" */ 'src/tabLayout/index.mdx'
    ),
  'src/picker/city/index.mdx': () =>
    import(
      /* webpackPrefetch: true, webpackChunkName: "src-picker-city-index" */ 'src/picker/city/index.mdx'
    ),
}
