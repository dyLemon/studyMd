# @umi-material/@cot/ui



## Usage

```sh
umi block https://github.com//tree/master/@cot/ui
```

## LICENSE

MIT
