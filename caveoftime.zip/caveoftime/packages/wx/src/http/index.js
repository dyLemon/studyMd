/* eslint-disable */
import BaseHttp from '@cot/core/lib/http/base';
import middlewares from './middlewares';
import { isNotEmpty } from '@cot/core/lib/utils/object';

const defaults = {
    middlewares: [
        middlewares.requestDomain(),
        middlewares.requestQuery(),
        middlewares.requestHeader(),
        middlewares.requestDataTransform(),
        middlewares.requestErrorHandler(),
        middlewares.responseStatus(),
        middlewares.responseJson(),
        middlewares.responseDataStatus(),
        middlewares.responseAuthorityValidator(),
        middlewares.responseErrorHandler(),
        //需要时打开
        middlewares.responseDataContent()
    ],
    config: {
        domain: '',
        json: false,
        servers: {},
        contentType: 'form',
        responseStatusResult(_){
          return Promise.reject(_);
        }
    }
  };

export default class WxRequest extends BaseHttp {
  constructor(config = {}, _middlewares = []) {
    super(config, [...defaults.middlewares, ..._middlewares]);
  }
  adapt(url, options) {
    return new Promise((resolve, reject) => {
      // console.log(options);
      // console.log(options);

      const params = { ...options};
      
      params.header = options.headers;
      params.data = options.body;
      
      wx.request({
        url,
        ...params,
        success: (res) => {
          resolve(res);
        }
      });

    });
  }
}

function parseArgs(_config = {}, _middlewares = []) {
    if (_config instanceof Array) {
        _middlewares = _config;
        _config = {};
    } else if (typeof _config === 'string') {
        _config = {
            domain: _config
        };
    }

    return {
        _config,
        _middlewares
    };
}
WxRequest.create = (...args)=>{
    let {
        _config,
        _middlewares
    } = parseArgs(...args);

    _config = {
        ...defaults.config,
        ..._config
    };
    // _middlewares = ..._middlewares];
    return new WxRequest(_config, _middlewares);
}