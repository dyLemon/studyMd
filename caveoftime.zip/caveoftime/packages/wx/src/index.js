/**
 * 微信公众平台API
 * 公众号
 * 企业微信
 * 小程序
 */

export default () => {
  console.log('welCome use Wx');
};

export function login(param) {
  //
  console.log(param);
}
