void main() {
  bool boolean = false;

  const bool boolean1 = true;

  // if判断和assert 中必须接收布尔值，所以必须要进行明确检查才能执行
}
