void main() {
  List<int> list = [1, 2, 3, 4, 5, 6, 7, 8];

  print(list.length); // 8

  print(list[0]); // 1
}
