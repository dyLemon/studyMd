void main() {
  /**
   * dart 支持以下内建类型
   * Number String Boolean List(也被称为Array)  Map Set Rune(用于在字符串中表示Unicode码) Symbol
   */
}
