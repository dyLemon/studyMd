void main() {
  final bool test = true;
  if (test) {
    print('hello world');
  } else {
    print('233333');
  }
}
