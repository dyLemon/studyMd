/// 普通构造函数
class ClassName {}

/// 命名构造函数
