/*
 * @Description: In User Settings Edit
 * @Author: your name
 * @Date: 2019-08-29 14:21:59
 * @LastEditTime: 2019-08-29 14:23:08
 * @LastEditors: Please set LastEditors
 */

function Obj(){
  this.name = 'aaa';
}