/*
 * @Description: In User Settings Edit
 * @Author: your name
 * @Date: 2019-08-28 17:19:50
 * @LastEditTime: 2019-08-28 17:26:44
 * @LastEditors: Please set LastEditors
 */


//  一旦setInterval的回调函数fn执行时间超过了延迟时间ms，那么就看不出来时间间隔了
