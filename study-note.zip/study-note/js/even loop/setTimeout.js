/*
 * @Description: In User Settings Edit
 * @Author: your name
 * @Date: 2019-08-28 17:10:20
 * @LastEditTime: 2019-08-28 17:17:51
 * @LastEditors: Please set LastEditors
 */
setTimeout(() => {
  console.log('延迟3秒执行')
}, 3000);

var a = [];
for (var i = 0; i < 10000000; i++) {
  a.push(i);
}
