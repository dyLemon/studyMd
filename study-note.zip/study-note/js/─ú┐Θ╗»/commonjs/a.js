const mode = require('./b');


console.log(mode.counter);

mode.incCounter();

console.log(mode.counter);