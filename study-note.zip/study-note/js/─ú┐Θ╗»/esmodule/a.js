import b from '../commonjs/b';

console.log(b)